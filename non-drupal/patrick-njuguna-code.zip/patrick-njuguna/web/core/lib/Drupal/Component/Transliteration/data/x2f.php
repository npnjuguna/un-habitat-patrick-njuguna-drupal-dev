<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yi', 'gun', 'zhu', 'pie', 'yi', 'jue', 'er', 'tou', 'ren', 'er', 'ru', 'ba', 'jiong', 'mi', 'bing', 'ji',
  0x10 => 'qian', 'dao', 'li', 'bao', 'bi', 'fang', 'xi', 'shi', 'bo', 'jie', 'chang', 'si', 'you', 'kou', 'wei', 'tu',
  0x20 => 'shi', 'zhi', 'sui', 'xi', 'da', 'nu', 'zi', 'mian', 'cun', 'xiao', 'you', 'shi', 'che', 'shan', 'chuan', 'gong',
  0x30 => 'ji', 'jin', 'gan', 'yao', 'guang', 'yin', 'gong', 'yi', 'gong', 'ji', 'shan', 'chi', 'xin', 'ge', 'hu', 'shou',
  0x40 => 'zhi', 'pu', 'wen', 'dou', 'jin', 'fang', 'wu', 'ri', 'yue', 'yue', 'mu', 'qian', 'zhi', 'dai', 'shu', 'wu',
  0x50 => 'bi', 'mao', 'shi', 'qi', 'shui', 'huo', 'zhao', 'fu', 'yao', 'pan', 'pian', 'ya', 'niu', 'quan', 'xuan', 'yu',
  0x60 => 'gua', 'wa', 'gan', 'sheng', 'yong', 'tian', 'pi', 'ne', 'bo', 'bai', 'pi', 'min', 'mu', 'mao', 'shi', 'shi',
  0x70 => 'shi', 'rou', 'he', 'xue', 'li', 'zhu', 'mi', 'mi', 'fou', 'wang', 'yang', 'yu', 'lao', 'er', 'lei', 'er',
  0x80 => 'yu', 'rou', 'chen', 'zi', 'zhi', 'jiu', 'she', 'chuan', 'zhou', 'gen', 'se', 'cao', 'hu', 'chong', 'xue', 'xing',
  0x90 => 'yi', 'ya', 'jian', 'jiao', 'yan', 'gu', 'dou', 'shi', 'zhi', 'bei', 'chi', 'zou', 'zu', 'shen', 'che', 'xin',
  0xA0 => 'chen', 'chuo', 'yi', 'you', 'bian', 'li', 'jin', 'zhang', 'men', 'fu', 'li', 'zhui', 'yu', 'qing', 'fei', 'mian',
  0xB0 => 'ge', 'wei', 'jiu', 'yin', 'ye', 'feng', 'fei', 'shi', 'shou', 'xiang', 'ma', 'gu', 'gao', 'biao', 'dou', 'chang',
  0xC0 => 'ge', 'gui', 'yu', 'niao', 'lu', 'lu', 'mai', 'ma', 'huang', 'shu', 'hei', 'zhi', 'mian', 'ding', 'gu', 'shu',
  0xD0 => 'bi', 'qi', 'chi', 'long', 'gui', 'yue', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xE0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
  0xF0 => NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
];
