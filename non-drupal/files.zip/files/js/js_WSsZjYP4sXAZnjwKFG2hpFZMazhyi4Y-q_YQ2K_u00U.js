/**
 * @file
 * Drupal Bootstrap object.
 */

/**
 * All Drupal Bootstrap JavaScript APIs are contained in this namespace.
 *
 * @namespace
 */
(function (_, $, Drupal, drupalSettings) {
  'use strict';

  var Bootstrap = {
    processedOnce: {},
    settings: drupalSettings.bootstrap || {}
  };

  /**
   * Wraps Drupal.checkPlain() to ensure value passed isn't empty.
   *
   * Encodes special characters in a plain-text string for display as HTML.
   *
   * @param {string} str
   *   The string to be encoded.
   *
   * @return {string}
   *   The encoded string.
   *
   * @ingroup sanitization
   */
  Bootstrap.checkPlain = function (str) {
    return str && Drupal.checkPlain(str) || '';
  };

  /**
   * Creates a jQuery plugin.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} plugin
   *   A constructor function used to initialize the for the jQuery plugin.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.createPlugin = function (id, plugin, noConflict) {
    // Immediately return if plugin doesn't exist.
    if ($.fn[id] !== void 0) {
      return this.fatal('Specified jQuery plugin identifier already exists: @id. Use Drupal.bootstrap.replacePlugin() instead.', {'@id': id});
    }

    // Immediately return if plugin isn't a function.
    if (typeof plugin !== 'function') {
      return this.fatal('You must provide a constructor function to create a jQuery plugin "@id": @plugin', {'@id': id, '@plugin':  plugin});
    }

    // Add a ".noConflict()" helper method.
    this.pluginNoConflict(id, plugin, noConflict);

    $.fn[id] = plugin;
  };

  /**
   * Diff object properties.
   *
   * @param {...Object} objects
   *   Two or more objects. The first object will be used to return properties
   *   values.
   *
   * @return {Object}
   *   Returns the properties of the first passed object that are not present
   *   in all other passed objects.
   */
  Bootstrap.diffObjects = function (objects) {
    var args = Array.prototype.slice.call(arguments);
    return _.pick(args[0], _.difference.apply(_, _.map(args, function (obj) {
      return Object.keys(obj);
    })));
  };

  /**
   * Map of supported events by regular expression.
   *
   * @type {Object<Event|MouseEvent|KeyboardEvent|TouchEvent,RegExp>}
   */
  Bootstrap.eventMap = {
    Event: /^(?:load|unload|abort|error|select|change|submit|reset|focus|blur|resize|scroll)$/,
    MouseEvent: /^(?:click|dblclick|mouse(?:down|enter|leave|up|over|move|out))$/,
    KeyboardEvent: /^(?:key(?:down|press|up))$/,
    TouchEvent: /^(?:touch(?:start|end|move|cancel))$/
  };

  /**
   * Extends a jQuery Plugin.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} callback
   *   A constructor function used to initialize the for the jQuery plugin.
   *
   * @return {Function|Boolean}
   *   The jQuery plugin constructor or FALSE if the plugin does not exist.
   */
  Bootstrap.extendPlugin = function (id, callback) {
    // Immediately return if plugin doesn't exist.
    if (typeof $.fn[id] !== 'function') {
      return this.fatal('Specified jQuery plugin identifier does not exist: @id', {'@id':  id});
    }

    // Immediately return if callback isn't a function.
    if (typeof callback !== 'function') {
      return this.fatal('You must provide a callback function to extend the jQuery plugin "@id": @callback', {'@id': id, '@callback':  callback});
    }

    // Determine existing plugin constructor.
    var constructor = $.fn[id] && $.fn[id].Constructor || $.fn[id];
    var proto = constructor.prototype;

    var obj = callback.apply(constructor, [this.settings]);
    if (!$.isPlainObject(obj)) {
      return this.fatal('Returned value from callback is not a plain object that can be used to extend the jQuery plugin "@id": @obj', {'@obj':  obj});
    }

    // Add a jQuery UI like option getter/setter method.
    var option = this.option;
    if (proto.option === void(0)) {
      proto.option = function () {
        return option.apply(this, arguments);
      };
    }

    // Handle prototype properties separately.
    if (obj.prototype !== void 0) {
      for (var key in obj.prototype) {
        if (!obj.prototype.hasOwnProperty(key)) continue;
        var value = obj.prototype[key];
        if (typeof value === 'function') {
          proto[key] = this.superWrapper(proto[key] || function () {}, value);
        }
        else {
          proto[key] = $.isPlainObject(value) ? $.extend(true, {}, proto[key], value) : value;
        }
      }
    }
    delete obj.prototype;

    // Handle static properties.
    for (key in obj) {
      if (!obj.hasOwnProperty(key)) continue;
      value = obj[key];
      if (typeof value === 'function') {
        constructor[key] = this.superWrapper(constructor[key] || function () {}, value);
      }
      else {
        constructor[key] = $.isPlainObject(value) ? $.extend(true, {}, constructor[key], value) : value;
      }
    }

    return $.fn[id];
  };

  Bootstrap.superWrapper = function (parent, fn) {
    return function () {
      var previousSuper = this.super;
      this.super = parent;
      var ret = fn.apply(this, arguments);
      if (previousSuper) {
        this.super = previousSuper;
      }
      else {
        delete this.super;
      }
      return ret;
    };
  };

  /**
   * Provide a helper method for displaying when something is went wrong.
   *
   * @param {String} message
   *   The message to display.
   * @param {Object} [args]
   *   An arguments to use in message.
   *
   * @return {Boolean}
   *   Always returns FALSE.
   */
  Bootstrap.fatal = function (message, args) {
    if (this.settings.dev && console.warn) {
      for (var name in args) {
        if (args.hasOwnProperty(name) && typeof args[name] === 'object') {
          args[name] = JSON.stringify(args[name]);
        }
      }
      Drupal.throwError(new Error(Drupal.formatString(message, args)));
    }
    return false;
  };

  /**
   * Intersects object properties.
   *
   * @param {...Object} objects
   *   Two or more objects. The first object will be used to return properties
   *   values.
   *
   * @return {Object}
   *   Returns the properties of first passed object that intersects with all
   *   other passed objects.
   */
  Bootstrap.intersectObjects = function (objects) {
    var args = Array.prototype.slice.call(arguments);
    return _.pick(args[0], _.intersection.apply(_, _.map(args, function (obj) {
      return Object.keys(obj);
    })));
  };

  /**
   * An object based once plugin (similar to jquery.once, but without the DOM).
   *
   * @param {String} id
   *   A unique identifier.
   * @param {Function} callback
   *   The callback to invoke if the identifier has not yet been seen.
   *
   * @return {Bootstrap}
   */
  Bootstrap.once = function (id, callback) {
    // Immediately return if identifier has already been processed.
    if (this.processedOnce[id]) {
      return this;
    }
    callback.call(this, this.settings);
    this.processedOnce[id] = true;
    return this;
  };

  /**
   * Provide jQuery UI like ability to get/set options for Bootstrap plugins.
   *
   * @param {string|object} key
   *   A string value of the option to set, can be dot like to a nested key.
   *   An object of key/value pairs.
   * @param {*} [value]
   *   (optional) A value to set for key.
   *
   * @returns {*}
   *   - Returns nothing if key is an object or both key and value parameters
   *   were provided to set an option.
   *   - Returns the a value for a specific setting if key was provided.
   *   - Returns an object of key/value pairs of all the options if no key or
   *   value parameter was provided.
   *
   * @see https://github.com/jquery/jquery-ui/blob/master/ui/widget.js
   */
  Bootstrap.option = function (key, value) {
    var options = $.isPlainObject(key) ? $.extend({}, key) : {};

    // Get all options (clone so it doesn't reference the internal object).
    if (arguments.length === 0) {
      return $.extend({}, this.options);
    }

    // Get/set single option.
    if (typeof key === "string") {
      // Handle nested keys in dot notation.
      // e.g., "foo.bar" => { foo: { bar: true } }
      var parts = key.split('.');
      key = parts.shift();
      var obj = options;
      if (parts.length) {
        for (var i = 0; i < parts.length - 1; i++) {
          obj[parts[i]] = obj[parts[i]] || {};
          obj = obj[parts[i]];
        }
        key = parts.pop();
      }

      // Get.
      if (arguments.length === 1) {
        return obj[key] === void 0 ? null : obj[key];
      }

      // Set.
      obj[key] = value;
    }

    // Set multiple options.
    $.extend(true, this.options, options);
  };

  /**
   * Adds a ".noConflict()" helper method if needed.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} plugin
   * @param {Function} plugin
   *   A constructor function used to initialize the for the jQuery plugin.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.pluginNoConflict = function (id, plugin, noConflict) {
    if (plugin.noConflict === void 0 && (noConflict === void 0 || noConflict)) {
      var old = $.fn[id];
      plugin.noConflict = function () {
        $.fn[id] = old;
        return this;
      };
    }
  };

  /**
   * Replaces a Bootstrap jQuery plugin definition.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} callback
   *   A callback function that is immediately invoked and must return a
   *   function that will be used as the plugin constructor.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.replacePlugin = function (id, callback, noConflict) {
    // Immediately return if plugin doesn't exist.
    if (typeof $.fn[id] !== 'function') {
      return this.fatal('Specified jQuery plugin identifier does not exist: @id', {'@id':  id});
    }

    // Immediately return if callback isn't a function.
    if (typeof callback !== 'function') {
      return this.fatal('You must provide a valid callback function to replace a jQuery plugin: @callback', {'@callback': callback});
    }

    // Determine existing plugin constructor.
    var constructor = $.fn[id] && $.fn[id].Constructor || $.fn[id];
    var plugin = callback.apply(constructor, [this.settings]);

    // Immediately return if plugin isn't a function.
    if (typeof plugin !== 'function') {
      return this.fatal('Returned value from callback is not a usable function to replace a jQuery plugin "@id": @plugin', {'@id': id, '@plugin': plugin});
    }

    // Add a ".noConflict()" helper method.
    this.pluginNoConflict(id, plugin, noConflict);

    $.fn[id] = plugin;
  };

  /**
   * Simulates a native event on an element in the browser.
   *
   * Note: This is a fairly complete modern implementation. If things aren't
   * working quite the way you intend (in older browsers), you may wish to use
   * the jQuery.simulate plugin. If it's available, this method will defer to
   * that plugin.
   *
   * @see https://github.com/jquery/jquery-simulate
   *
   * @param {HTMLElement|jQuery} element
   *   A DOM element to dispatch event on. Note: this may be a jQuery object,
   *   however be aware that this will trigger the same event for each element
   *   inside the jQuery collection; use with caution.
   * @param {String} type
   *   The type of event to simulate.
   * @param {Object} [options]
   *   An object of options to pass to the event constructor. Typically, if
   *   an event is being proxied, you should just pass the original event
   *   object here. This allows, if the browser supports it, to be a truly
   *   simulated event.
   *
   * @return {Boolean}
   *   The return value is false if event is cancelable and at least one of the
   *   event handlers which handled this event called Event.preventDefault().
   *   Otherwise it returns true.
   */
  Bootstrap.simulate = function (element, type, options) {
    // Handle jQuery object wrappers so it triggers on each element.
    if (element instanceof $) {
      var ret = true;
      element.each(function () {
        if (!Bootstrap.simulate(this, type, options)) {
          ret = false;
        }
      });
      return ret;
    }

    if (!(element instanceof HTMLElement)) {
      this.fatal('Passed element must be an instance of HTMLElement, got "@type" instead.', {
        '@type': typeof element,
      });
    }

    // Defer to the jQuery.simulate plugin, if it's available.
    if (typeof $.simulate === 'function') {
      new $.simulate(element, type, options);
      return true;
    }

    var event;
    var ctor;
    for (var name in this.eventMap) {
      if (this.eventMap[name].test(type)) {
        ctor = name;
        break;
      }
    }
    if (!ctor) {
      throw new SyntaxError('Only rudimentary HTMLEvents, KeyboardEvents and MouseEvents are supported: ' + type);
    }
    var opts = {bubbles: true, cancelable: true};
    if (ctor === 'KeyboardEvent' || ctor === 'MouseEvent') {
      $.extend(opts, {ctrlKey: !1, altKey: !1, shiftKey: !1, metaKey: !1});
    }
    if (ctor === 'MouseEvent') {
      $.extend(opts, {button: 0, pointerX: 0, pointerY: 0, view: window});
    }
    if (options) {
      $.extend(opts, options);
    }
    if (typeof window[ctor] === 'function') {
      event = new window[ctor](type, opts);
      return element.dispatchEvent(event);
    }
    else if (document.createEvent) {
      event = document.createEvent(ctor);
      event.initEvent(type, opts.bubbles, opts.cancelable);
      return element.dispatchEvent(event);
    }
    else if (typeof element.fireEvent === 'function') {
      event = $.extend(document.createEventObject(), opts);
      return element.fireEvent('on' + type, event);
    }
    else if (typeof element[type]) {
      element[type]();
      return true;
    }
  };

  /**
   * Strips HTML and returns just text.
   *
   * @param {String|Element|jQuery} html
   *   A string of HTML content, an Element DOM object or a jQuery object.
   *
   * @return {String}
   *   The text without HTML tags.
   *
   * @todo Replace with http://locutus.io/php/strings/strip_tags/
   */
  Bootstrap.stripHtml = function (html) {
    if (html instanceof $) {
      html = html.html();
    }
    else if (html instanceof Element) {
      html = html.innerHTML;
    }
    var tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return (tmp.textContent || tmp.innerText || '').replace(/^[\s\n\t]*|[\s\n\t]*$/g, '');
  };

  /**
   * Provide a helper method for displaying when something is unsupported.
   *
   * @param {String} type
   *   The type of unsupported object, e.g. method or option.
   * @param {String} name
   *   The name of the unsupported object.
   * @param {*} [value]
   *   The value of the unsupported object.
   */
  Bootstrap.unsupported = function (type, name, value) {
    Bootstrap.warn('Unsupported by Drupal Bootstrap: (@type) @name -> @value', {
      '@type': type,
      '@name': name,
      '@value': typeof value === 'object' ? JSON.stringify(value) : value
    });
  };

  /**
   * Provide a helper method to display a warning.
   *
   * @param {String} message
   *   The message to display.
   * @param {Object} [args]
   *   Arguments to use as replacements in Drupal.formatString.
   */
  Bootstrap.warn = function (message, args) {
    if (this.settings.dev && console.warn) {
      console.warn(Drupal.formatString(message, args));
    }
  };

  /**
   * Add Bootstrap to the global Drupal object.
   *
   * @type {Bootstrap}
   */
  Drupal.bootstrap = Drupal.bootstrap || Bootstrap;

})(window._, window.jQuery, window.Drupal, window.drupalSettings);
;
(function ($, _) {

  /**
   * @class Attributes
   *
   * Modifies attributes.
   *
   * @param {Object|Attributes} attributes
   *   An object to initialize attributes with.
   */
  var Attributes = function (attributes) {
    this.data = {};
    this.data['class'] = [];
    this.merge(attributes);
  };

  /**
   * Renders the attributes object as a string to inject into an HTML element.
   *
   * @return {String}
   *   A rendered string suitable for inclusion in HTML markup.
   */
  Attributes.prototype.toString = function () {
    var output = '';
    var name, value;
    var checkPlain = function (str) {
      return str && str.toString().replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;') || '';
    };
    var data = this.getData();
    for (name in data) {
      if (!data.hasOwnProperty(name)) continue;
      value = data[name];
      if (_.isFunction(value)) value = value();
      if (_.isObject(value)) value = _.values(value);
      if (_.isArray(value)) value = value.join(' ');
      output += ' ' + checkPlain(name) + '="' + checkPlain(value) + '"';
    }
    return output;
  };

  /**
   * Renders the Attributes object as a plain object.
   *
   * @return {Object}
   *   A plain object suitable for inclusion in DOM elements.
   */
  Attributes.prototype.toPlainObject = function () {
    var object = {};
    var name, value;
    var data = this.getData();
    for (name in data) {
      if (!data.hasOwnProperty(name)) continue;
      value = data[name];
      if (_.isFunction(value)) value = value();
      if (_.isObject(value)) value = _.values(value);
      if (_.isArray(value)) value = value.join(' ');
      object[name] = value;
    }
    return object;
  };

  /**
   * Add class(es) to the array.
   *
   * @param {string|Array} value
   *   An individual class or an array of classes to add.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.addClass = function (value) {
    var args = Array.prototype.slice.call(arguments);
    this.data['class'] = this.sanitizeClasses(this.data['class'].concat(args));
    return this;
  };

  /**
   * Returns whether the requested attribute exists.
   *
   * @param {string} name
   *   An attribute name to check.
   *
   * @return {boolean}
   *   TRUE or FALSE
   */
  Attributes.prototype.exists = function (name) {
    return this.data[name] !== void(0) && this.data[name] !== null;
  };

  /**
   * Retrieve a specific attribute from the array.
   *
   * @param {string} name
   *   The specific attribute to retrieve.
   * @param {*} defaultValue
   *   (optional) The default value to set if the attribute does not exist.
   *
   * @return {*}
   *   A specific attribute value, passed by reference.
   */
  Attributes.prototype.get = function (name, defaultValue) {
    if (!this.exists(name)) this.data[name] = defaultValue;
    return this.data[name];
  };

  /**
   * Retrieves a cloned copy of the internal attributes data object.
   *
   * @return {Object}
   */
  Attributes.prototype.getData = function () {
    return _.extend({}, this.data);
  };

  /**
   * Retrieves classes from the array.
   *
   * @return {Array}
   *   The classes array.
   */
  Attributes.prototype.getClasses = function () {
    return this.get('class', []);
  };

  /**
   * Indicates whether a class is present in the array.
   *
   * @param {string|Array} className
   *   The class(es) to search for.
   *
   * @return {boolean}
   *   TRUE or FALSE
   */
  Attributes.prototype.hasClass = function (className) {
    className = this.sanitizeClasses(Array.prototype.slice.call(arguments));
    var classes = this.getClasses();
    for (var i = 0, l = className.length; i < l; i++) {
      // If one of the classes fails, immediately return false.
      if (_.indexOf(classes, className[i]) === -1) {
        return false;
      }
    }
    return true;
  };

  /**
   * Merges multiple values into the array.
   *
   * @param {Attributes|Node|jQuery|Object} object
   *   An Attributes object with existing data, a Node DOM element, a jQuery
   *   instance or a plain object where the key is the attribute name and the
   *   value is the attribute value.
   * @param {boolean} [recursive]
   *   Flag determining whether or not to recursively merge key/value pairs.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.merge = function (object, recursive) {
    // Immediately return if there is nothing to merge.
    if (!object) {
      return this;
    }

    // Get attributes from a jQuery element.
    if (object instanceof $) {
      object = object[0];
    }

    // Get attributes from a DOM element.
    if (object instanceof Node) {
      object = Array.prototype.slice.call(object.attributes).reduce(function (attributes, attribute) {
        attributes[attribute.name] = attribute.value;
        return attributes;
      }, {});
    }
    // Get attributes from an Attributes instance.
    else if (object instanceof Attributes) {
      object = object.getData();
    }
    // Otherwise, clone the object.
    else {
      object = _.extend({}, object);
    }

    // By this point, there should be a valid plain object.
    if (!$.isPlainObject(object)) {
      setTimeout(function () {
        throw new Error('Passed object is not supported: ' + object);
      });
      return this;
    }

    // Handle classes separately.
    if (object && object['class'] !== void 0) {
      this.addClass(object['class']);
      delete object['class'];
    }

    if (recursive === void 0 || recursive) {
      this.data = $.extend(true, {}, this.data, object);
    }
    else {
      this.data = $.extend({}, this.data, object);
    }

    return this;
  };

  /**
   * Removes an attribute from the array.
   *
   * @param {string} name
   *   The name of the attribute to remove.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.remove = function (name) {
    if (this.exists(name)) delete this.data[name];
    return this;
  };

  /**
   * Removes a class from the attributes array.
   *
   * @param {...string|Array} className
   *   An individual class or an array of classes to remove.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.removeClass = function (className) {
    var remove = this.sanitizeClasses(Array.prototype.slice.apply(arguments));
    this.data['class'] = _.without(this.getClasses(), remove);
    return this;
  };

  /**
   * Replaces a class in the attributes array.
   *
   * @param {string} oldValue
   *   The old class to remove.
   * @param {string} newValue
   *   The new class. It will not be added if the old class does not exist.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.replaceClass = function (oldValue, newValue) {
    var classes = this.getClasses();
    var i = _.indexOf(this.sanitizeClasses(oldValue), classes);
    if (i >= 0) {
      classes[i] = newValue;
      this.set('class', classes);
    }
    return this;
  };

  /**
   * Ensures classes are flattened into a single is an array and sanitized.
   *
   * @param {...String|Array} classes
   *   The class or classes to sanitize.
   *
   * @return {Array}
   *   A sanitized array of classes.
   */
  Attributes.prototype.sanitizeClasses = function (classes) {
    return _.chain(Array.prototype.slice.call(arguments))
      // Flatten in case there's a mix of strings and arrays.
      .flatten()

      // Split classes that may have been added with a space as a separator.
      .map(function (string) {
        return string.split(' ');
      })

      // Flatten again since it was just split into arrays.
      .flatten()

      // Filter out empty items.
      .filter()

      // Clean the class to ensure it's a valid class name.
      .map(function (value) {
        return Attributes.cleanClass(value);
      })

      // Ensure classes are unique.
      .uniq()

      // Retrieve the final value.
      .value();
  };

  /**
   * Sets an attribute on the array.
   *
   * @param {string} name
   *   The name of the attribute to set.
   * @param {*} value
   *   The value of the attribute to set.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.set = function (name, value) {
    var obj = $.isPlainObject(name) ? name : {};
    if (typeof name === 'string') {
      obj[name] = value;
    }
    return this.merge(obj);
  };

  /**
   * Prepares a string for use as a CSS identifier (element, class, or ID name).
   *
   * Note: this is essentially a direct copy from
   * \Drupal\Component\Utility\Html::cleanCssIdentifier
   *
   * @param {string} identifier
   *   The identifier to clean.
   * @param {Object} [filter]
   *   An object of string replacements to use on the identifier.
   *
   * @return {string}
   *   The cleaned identifier.
   */
  Attributes.cleanClass = function (identifier, filter) {
    filter = filter || {
      ' ': '-',
      '_': '-',
      '/': '-',
      '[': '-',
      ']': ''
    };

    identifier = identifier.toLowerCase();

    if (filter['__'] === void 0) {
      identifier = identifier.replace('__', '#DOUBLE_UNDERSCORE#');
    }

    identifier = identifier.replace(Object.keys(filter), Object.keys(filter).map(function(key) { return filter[key]; }));

    if (filter['__'] === void 0) {
      identifier = identifier.replace('#DOUBLE_UNDERSCORE#', '__');
    }

    identifier = identifier.replace(/[^\u002D\u0030-\u0039\u0041-\u005A\u005F\u0061-\u007A\u00A1-\uFFFF]/g, '');
    identifier = identifier.replace(['/^[0-9]/', '/^(-[0-9])|^(--)/'], ['_', '__']);

    return identifier;
  };

  /**
   * Creates an Attributes instance.
   *
   * @param {object|Attributes} [attributes]
   *   An object to initialize attributes with.
   *
   * @return {Attributes}
   *   An Attributes instance.
   *
   * @constructor
   */
  Attributes.create = function (attributes) {
    return new Attributes(attributes);
  };

  window.Attributes = Attributes;

})(window.jQuery, window._);
;
/**
 * @file
 * Theme hooks for the Drupal Bootstrap base theme.
 */
(function ($, Drupal, Bootstrap, Attributes) {

  /**
   * Fallback for theming an icon if the Icon API module is not installed.
   */
  if (!Drupal.icon) Drupal.icon = { bundles: {} };
  if (!Drupal.theme.icon || Drupal.theme.prototype.icon) {
    $.extend(Drupal.theme, /** @lends Drupal.theme */ {
      /**
       * Renders an icon.
       *
       * @param {string} bundle
       *   The bundle which the icon belongs to.
       * @param {string} icon
       *   The name of the icon to render.
       * @param {object|Attributes} [attributes]
       *   An object of attributes to also apply to the icon.
       *
       * @returns {string}
       */
      icon: function (bundle, icon, attributes) {
        if (!Drupal.icon.bundles[bundle]) return '';
        attributes = Attributes.create(attributes).addClass('icon').set('aria-hidden', 'true');
        icon = Drupal.icon.bundles[bundle](icon, attributes);
        return '<span' + attributes + '></span>';
      }
    });
  }

  /**
   * Callback for modifying an icon in the "bootstrap" icon bundle.
   *
   * @param {string} icon
   *   The icon being rendered.
   * @param {Attributes} attributes
   *   Attributes object for the icon.
   */
  Drupal.icon.bundles.bootstrap = function (icon, attributes) {
    attributes.addClass(['glyphicon', 'glyphicon-' + icon]);
  };

  /**
   * Add necessary theming hooks.
   */
  $.extend(Drupal.theme, /** @lends Drupal.theme */ {

    /**
     * Renders a Bootstrap AJAX glyphicon throbber.
     *
     * @returns {string}
     */
    ajaxThrobber: function () {
      return Drupal.theme('bootstrapIcon', 'refresh', {'class': ['ajax-throbber', 'glyphicon-spin'] });
    },

    /**
     * Renders a button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button. If it contains one of:
     *   - value: The label of the button.
     *   - context: The context type of Bootstrap button, can be one of:
     *     - default
     *     - primary
     *     - success
     *     - info
     *     - warning
     *     - danger
     *     - link
     *
     * @returns {string}
     */
    button: function (attributes) {
      attributes = Attributes.create(attributes).addClass('btn');
      var context = attributes.get('context', 'default');
      var label = attributes.get('value', '');
      attributes.remove('context').remove('value');
      if (!attributes.hasClass(['btn-default', 'btn-primary', 'btn-success', 'btn-info', 'btn-warning', 'btn-danger', 'btn-link'])) {
        attributes.addClass('btn-' + Bootstrap.checkPlain(context));
      }

      // Attempt to, intelligently, provide a default button "type".
      if (!attributes.exists('type')) {
        attributes.set('type', attributes.hasClass('form-submit') ? 'submit' : 'button');
      }

      return '<button' + attributes + '>' + label + '</button>';
    },

    /**
     * Alias for "button" theme hook.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    btn: function (attributes) {
      return Drupal.theme('button', attributes);
    },

    /**
     * Renders a button block element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-block': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-block'));
    },

    /**
     * Renders a large button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-lg': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-lg'));
    },

    /**
     * Renders a small button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-sm': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-sm'));
    },

    /**
     * Renders an extra small button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-xs': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-xs'));
    },

    /**
     * Renders a glyphicon.
     *
     * @param {string} name
     *   The name of the glyphicon.
     * @param {object|Attributes} [attributes]
     *   An object of attributes to apply to the icon.
     *
     * @returns {string}
     */
    bootstrapIcon: function (name, attributes) {
      return Drupal.theme('icon', 'bootstrap', name, attributes);
    }

  });

})(window.jQuery, window.Drupal, window.Drupal.bootstrap, window.Attributes);
;
/**
 * @file
 * Bootstrap Popovers.
 */

var Drupal = Drupal || {};

(function ($, Drupal, Bootstrap) {
  "use strict";

  var $document = $(document);

  /**
   * Extend the Bootstrap Popover plugin constructor class.
   */
  Bootstrap.extendPlugin('popover', function (settings) {
    return {
      DEFAULTS: {
        animation: !!settings.popover_animation,
        autoClose: !!settings.popover_auto_close,
        enabled: settings.popover_enabled,
        html: !!settings.popover_html,
        placement: settings.popover_placement,
        selector: settings.popover_selector,
        trigger: settings.popover_trigger,
        title: settings.popover_title,
        content: settings.popover_content,
        delay: parseInt(settings.popover_delay, 10),
        container: settings.popover_container
      }
    };
  });

  /**
   * Bootstrap Popovers.
   *
   * @todo This should really be properly delegated if selector option is set.
   */
  Drupal.behaviors.bootstrapPopovers = {
    $activePopover: null,
    attach: function (context) {
      // Immediately return if popovers are not available.
      if (!$.fn.popover || !$.fn.popover.Constructor.DEFAULTS.enabled) {
        return;
      }

      var _this = this;

      $document
        .on('show.bs.popover', '[data-toggle=popover]', function () {
          var $trigger = $(this);
          var popover = $trigger.data('bs.popover');

          // Only keep track of clicked triggers that we're manually handling.
          if (popover.options.originalTrigger === 'click') {
            if (_this.$activePopover && _this.getOption('autoClose') && !_this.$activePopover.is($trigger)) {
              _this.$activePopover.popover('hide');
            }
            _this.$activePopover = $trigger;
          }
        })
        .on('focus.bs.popover', ':focusable', function (e) {
          var $target = $(e.target);
          if (_this.$activePopover && _this.getOption('autoClose') && !_this.$activePopover.is($target) && !$target.closest('.popover.in')[0]) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
        .on('click.bs.popover', function (e) {
          var $target = $(e.target);
          if (_this.$activePopover && _this.getOption('autoClose') && !$target.is('[data-toggle=popover]') && !$target.closest('.popover.in')[0]) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
        .on('keyup.bs.popover', function (e) {
          if (_this.$activePopover && _this.getOption('autoClose') && e.which === 27) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
      ;

      var elements = $(context).find('[data-toggle=popover]').toArray();
      for (var i = 0; i < elements.length; i++) {
        var $element = $(elements[i]);
        var options = $.extend({}, $.fn.popover.Constructor.DEFAULTS, $element.data());

        // Store the original trigger.
        options.originalTrigger = options.trigger;

        // If the trigger is "click", then we'll handle it manually here.
        if (options.trigger === 'click') {
          options.trigger = 'manual';
        }

        // Retrieve content from a target element.
        var target = options.target || $element.is('a[href^="#"]') && $element.attr('href');
        var $target = $document.find(target).clone();
        if (!options.content && $target[0]) {
          $target.removeClass('visually-hidden hidden').removeAttr('aria-hidden');
          options.content = $target.wrap('<div/>').parent()[options.html ? 'html' : 'text']() || '';
        }

        // Initialize the popover.
        $element.popover(options);

        // Handle clicks manually.
        if (options.originalTrigger === 'click') {
          // To ensure the element is bound multiple times, remove any
          // previously set event handler before adding another one.
          $element
            .off('click.drupal.bootstrap.popover')
            .on('click.drupal.bootstrap.popover', function (e) {
              $(this).popover('toggle');
              e.preventDefault();
              e.stopPropagation();
            })
          ;
        }
      }
    },
    detach: function (context) {
      // Immediately return if popovers are not available.
      if (!$.fn.popover || !$.fn.popover.Constructor.DEFAULTS.enabled) {
        return;
      }

      // Destroy all popovers.
      $(context).find('[data-toggle="popover"]')
        .off('click.drupal.bootstrap.popover')
        .popover('destroy')
      ;
    },
    getOption: function(name, defaultValue, element) {
      var $element = element ? $(element) : this.$activePopover;
      var options = $.extend(true, {}, $.fn.popover.Constructor.DEFAULTS, (($element && $element.data('bs.popover')).options || {}).options);
      if (options[name] !== void 0) {
        return options[name];
      }
      return defaultValue !== void 0 ? defaultValue : void 0;
    }
  };

})(window.jQuery, window.Drupal, window.Drupal.bootstrap);
;
/**
 * @file
 * Bootstrap Tooltips.
 */

var Drupal = Drupal || {};

(function ($, Drupal, Bootstrap) {
  "use strict";

  /**
   * Extend the Bootstrap Tooltip plugin constructor class.
   */
  Bootstrap.extendPlugin('tooltip', function (settings) {
    return {
      DEFAULTS: {
        animation: !!settings.tooltip_animation,
        html: !!settings.tooltip_html,
        placement: settings.tooltip_placement,
        selector: settings.tooltip_selector,
        trigger: settings.tooltip_trigger,
        delay: parseInt(settings.tooltip_delay, 10),
        container: settings.tooltip_container
      }
    };
  });

  /**
   * Bootstrap Tooltips.
   *
   * @todo This should really be properly delegated if selector option is set.
   */
  Drupal.behaviors.bootstrapTooltips = {
    attach: function (context) {
      var elements = $(context).find('[data-toggle="tooltip"]').toArray();
      for (var i = 0; i < elements.length; i++) {
        var $element = $(elements[i]);
        var options = $.extend({}, $.fn.tooltip.Constructor.DEFAULTS, $element.data());
        $element.tooltip(options);
      }
    },
    detach: function (context) {
      // Destroy all tooltips.
      $(context).find('[data-toggle="tooltip"]').tooltip('destroy');
    }
  };

})(window.jQuery, window.Drupal, window.Drupal.bootstrap);
;
/**
 * @file
 * JavaScript integration between Google and Drupal.
 */

(function ($) {
  'use strict';

  Drupal.googleCharts = Drupal.googleCharts || {charts: []};

  /**
   * Behavior to initialize Google Charts.
   *
   * @type {{attach: Drupal.behaviors.chartsGooglecharts.attach}}
   */
  Drupal.behaviors.chartsGooglecharts = {
    attach: function (context, settings) {
      // Load Google Charts API.
      google.charts.load('current', {packages: ['corechart', 'gauge']});

      $(context).find('body').once('load-google-charts').each(function () {
        // Re-draw charts if viewport size has been changed.
        $(window).on('resize', function () {
          Drupal.googleCharts.waitForFinalEvent(function () {
            // Re-draw Google Charts.
            Drupal.googleCharts.drawCharts(true);
          }, 200, 'reload-google-charts');
        });
      });

      // Draw Google Charts.
      Drupal.googleCharts.drawCharts();
    }
  };

  /**
   * Helper function to draw Google Charts.
   *
   * @param {boolean} reload - Reload.
   */
  Drupal.googleCharts.drawCharts = function (reload) {
    $('.charts-google').each(function () {
      var chartId = $(this).attr('id');
      var $charts;

      if (reload === true) {
        $charts = $('#' + chartId);
      }
      else {
        $charts = $('#' + chartId).once('draw-google-charts');
      }

      $charts.each(function () {
        var $chart = $(this);

        if ($chart.attr('data-chart')) {
          var data = $chart.attr('data-chart');
          var options = $chart.attr('google-options');
          var type = $chart.attr('google-chart-type');

          google.charts.setOnLoadCallback(Drupal.googleCharts.drawChart(chartId, type, data, options));
        }
      });
    });
  };

  /**
   * Helper function to draw a Google Chart.
   *
   * @param {string} chartId - Chart Id.
   * @param {string} chartType - Chart Type.
   * @param {string} dataTable - Data.
   * @param {string} googleChartOptions - Options.
   *
   * @return {function} Draw Chart.
   */
  Drupal.googleCharts.drawChart = function (chartId, chartType, dataTable, googleChartOptions) {
    return function () {
      var data = google.visualization.arrayToDataTable(JSON.parse(dataTable));
      var options = JSON.parse(googleChartOptions);
      var googleChartTypeObject = JSON.parse(chartType);
      var googleChartTypeFormatted = googleChartTypeObject.type;
      var chart;

      switch (googleChartTypeFormatted) {
        case 'BarChart':
          chart = new google.visualization.BarChart(document.getElementById(chartId));
          break;
        case 'ColumnChart':
          chart = new google.visualization.ColumnChart(document.getElementById(chartId));
          break;
        case 'DonutChart':
          chart = new google.visualization.PieChart(document.getElementById(chartId));
          break;
        case 'PieChart':
          chart = new google.visualization.PieChart(document.getElementById(chartId));
          break;
        case 'ScatterChart':
          chart = new google.visualization.ScatterChart(document.getElementById(chartId));
          break;
        case 'AreaChart':
          chart = new google.visualization.AreaChart(document.getElementById(chartId));
          break;
        case 'LineChart':
          chart = new google.visualization.LineChart(document.getElementById(chartId));
          break;
        case 'SplineChart':
          chart = new google.visualization.LineChart(document.getElementById(chartId));
          break;
        case 'GaugeChart':
          chart = new google.visualization.Gauge(document.getElementById(chartId));
      }
      // Fix for https://www.drupal.org/project/charts/issues/2950654.
      // Would be interested in a different approach that allowed the default
      // colors to be applied first, rather than unsetting.
      if (options['colors'].length > 10) {
        for (var i in options) {
          if (i === 'colors') {
            delete options[i];
            break;
          }
        }
      }
      chart.draw(data, options);
    };
  };

  /**
   * Helper function to run a callback function once when triggering an event
   * multiple times.
   *
   * Example usage:
   * @code
   *  $(window).resize(function () {
   *    Drupal.googleCharts.waitForFinalEvent(function(){
   *      alert('Resize...');
   *    }, 500, "some unique string");
   *  });
   * @endcode
   */
  Drupal.googleCharts.waitForFinalEvent = (function () {
    var timers = {};
    return function (callback, ms, uniqueId) {
      if (!uniqueId) {
        uniqueId = "Don't call this twice without a uniqueId";
      }
      if (timers[uniqueId]) {
        clearTimeout(timers[uniqueId]);
      }
      timers[uniqueId] = setTimeout(callback, ms);
    };
  })();

}(jQuery));
;
(function(){var a="' of type ",k="SCRIPT",n="array",p="charts-version",q="function",t="google.charts.load",u="hasOwnProperty",v="number",w="object",x="pre-45",y="propertyIsEnumerable",z="string",A="text/javascript",B="toLocaleString";function C(){return function(b){return b}}function D(){return function(){}}function E(b){return function(){return this[b]}}function F(b){return function(){return b}}var H,I=I||{};I.scope={};
I.Jq=function(b,c,d){b instanceof String&&(b=String(b));for(var e=b.length,f=0;f<e;f++){var g=b[f];if(c.call(d,g,f,b))return{Vj:f,Gl:g}}return{Vj:-1,Gl:void 0}};I.vh=!1;I.Zl=!1;I.$l=!1;I.defineProperty=I.vh||typeof Object.defineProperties==q?Object.defineProperty:function(b,c,d){b!=Array.prototype&&b!=Object.prototype&&(b[c]=d.value)};I.Dj=function(b){return"undefined"!=typeof window&&window===b?b:"undefined"!=typeof global&&null!=global?global:b};I.global=I.Dj(this);
I.Mk=function(b){if(b){for(var c=I.global,d=["Promise"],e=0;e<d.length-1;e++){var f=d[e];f in c||(c[f]={});c=c[f]}d=d[d.length-1];e=c[d];b=b(e);b!=e&&null!=b&&I.defineProperty(c,d,{configurable:!0,writable:!0,value:b})}};I.Xp=function(b,c,d){if(null==b)throw new TypeError("The 'this' value for String.prototype."+d+" must not be null or undefined");if(c instanceof RegExp)throw new TypeError("First argument to String.prototype."+d+" must not be a regular expression");return b+""};
I.Di=function(b){var c=0;return function(){return c<b.length?{done:!1,value:b[c++]}:{done:!0}}};I.Ci=function(b){return{next:I.Di(b)}};I.Gg=function(b){var c="undefined"!=typeof Symbol&&Symbol.iterator&&b[Symbol.iterator];return c?c.call(b):I.Ci(b)};I.Qh=!1;
I.Mk(function(b){function c(b){this.ba=g.ya;this.la=void 0;this.ub=[];var c=this.fd();try{b(c.resolve,c.reject)}catch(r){c.reject(r)}}function d(){this.La=null}function e(b){return b instanceof c?b:new c(function(c){c(b)})}if(b&&!I.Qh)return b;d.prototype.Xe=function(b){null==this.La&&(this.La=[],this.Hi());this.La.push(b)};d.prototype.Hi=function(){var b=this;this.Ye(function(){b.pj()})};var f=I.global.setTimeout;d.prototype.Ye=function(b){f(b,0)};d.prototype.pj=function(){for(;this.La&&this.La.length;){var b=
this.La;this.La=[];for(var c=0;c<b.length;++c){var d=b[c];b[c]=null;try{d()}catch(G){this.Ii(G)}}}this.La=null};d.prototype.Ii=function(b){this.Ye(function(){throw b;})};var g={ya:0,Ka:1,na:2};c.prototype.fd=function(){function b(b){return function(e){d||(d=!0,b.call(c,e))}}var c=this,d=!1;return{resolve:b(this.Rk),reject:b(this.Sd)}};c.prototype.Rk=function(b){if(b===this)this.Sd(new TypeError("A Promise cannot resolve to itself"));else if(b instanceof c)this.jl(b);else{a:switch(typeof b){case w:var d=
null!=b;break a;case q:d=!0;break a;default:d=!1}d?this.Qk(b):this.zf(b)}};c.prototype.Qk=function(b){var c=void 0;try{c=b.then}catch(r){this.Sd(r);return}typeof c==q?this.kl(c,b):this.zf(b)};c.prototype.Sd=function(b){this.$g(g.na,b)};c.prototype.zf=function(b){this.$g(g.Ka,b)};c.prototype.$g=function(b,c){if(this.ba!=g.ya)throw Error("Cannot settle("+b+", "+c+"): Promise already settled in state"+this.ba);this.ba=b;this.la=c;this.rj()};c.prototype.rj=function(){if(null!=this.ub){for(var b=0;b<this.ub.length;++b)h.Xe(this.ub[b]);
this.ub=null}};var h=new d;c.prototype.jl=function(b){var c=this.fd();b.dc(c.resolve,c.reject)};c.prototype.kl=function(b,c){var d=this.fd();try{b.call(c,d.resolve,d.reject)}catch(G){d.reject(G)}};c.prototype.then=function(b,d){function e(b,c){return typeof b==q?function(c){try{f(b(c))}catch(ba){g(ba)}}:c}var f,g,h=new c(function(b,c){f=b;g=c});this.dc(e(b,f),e(d,g));return h};c.prototype["catch"]=function(b){return this.then(void 0,b)};c.prototype.dc=function(b,c){function d(){switch(e.ba){case g.Ka:b(e.la);
break;case g.na:c(e.la);break;default:throw Error("Unexpected state: "+e.ba);}}var e=this;null==this.ub?h.Xe(d):this.ub.push(d)};c.resolve=e;c.reject=function(b){return new c(function(c,d){d(b)})};c.race=function(b){return new c(function(c,d){for(var f=I.Gg(b),g=f.next();!g.done;g=f.next())e(g.value).dc(c,d)})};c.all=function(b){var d=I.Gg(b),f=d.next();return f.done?e([]):new c(function(b,c){function g(c){return function(d){h[c]=d;l--;0==l&&b(h)}}var h=[],l=0;do h.push(void 0),l++,e(f.value).dc(g(h.length-
1),c),f=d.next();while(!f.done)})};return c});var J=J||{};J.global=this;J.W=function(b){return void 0!==b};J.N=function(b){return typeof b==z};J.Yj=function(b){return"boolean"==typeof b};J.Rb=function(b){return typeof b==v};J.ld=function(b,c,d){b=b.split(".");d=d||J.global;b[0]in d||"undefined"==typeof d.execScript||d.execScript("var "+b[0]);for(var e;b.length&&(e=b.shift());)!b.length&&J.W(c)?d[e]=c:d=d[e]&&d[e]!==Object.prototype[e]?d[e]:d[e]={}};J.define=function(b,c){J.ld(b,c)};J.Z=!0;J.I="en";
J.Xc=!0;J.mi=!1;J.Mh=!J.Z;J.Pm=!1;J.Os=function(b){if(J.tg())throw Error("goog.provide cannot be used within a module.");J.gf(b)};J.gf=function(b,c){J.ld(b,c)};J.$f=function(){null===J.gd&&(J.gd=J.Hj());return J.gd};J.Yh=/^[\w+/_-]+[=]{0,2}$/;J.gd=null;J.Hj=function(){var b=J.global.document;return(b=b.querySelector&&b.querySelector("script[nonce]"))&&(b=b.nonce||b.getAttribute("nonce"))&&J.Yh.test(b)?b:""};J.ui=/^[a-zA-Z_$][a-zA-Z0-9._$]*$/;
J.uc=function(b){if(!J.N(b)||!b||-1==b.search(J.ui))throw Error("Invalid module identifier");if(!J.sg())throw Error("Module "+b+" has been loaded incorrectly. Note, modules cannot be loaded as normal scripts. They require some kind of pre-processing step. You're likely trying to load a module via a script tag or as a part of a concatenated bundle without rewriting the module. For more info see: https://github.com/google/closure-library/wiki/goog.module:-an-ES6-module-like-alternative-to-goog.provide.");
if(J.ia.Sb)throw Error("goog.module may only be called once per module.");J.ia.Sb=b};J.uc.get=F(null);J.uc.kr=F(null);J.Ab={we:"es6",Vc:"goog"};J.ia=null;J.tg=function(){return J.sg()||J.ck()};J.sg=function(){return!!J.ia&&J.ia.type==J.Ab.Vc};J.ck=function(){if(J.ia&&J.ia.type==J.Ab.we)return!0;var b=J.global.$jscomp;return b?typeof b.qd!=q?!1:!!b.qd():!1};J.uc.hd=function(){J.ia.hd=!0};
J.fj=function(b){if(J.ia)J.ia.Sb=b;else{var c=J.global.$jscomp;if(!c||typeof c.qd!=q)throw Error('Module with namespace "'+b+'" has been loaded incorrectly.');c=c.Ok(c.qd());J.Fg[b]={sj:c,type:J.Ab.we,Jk:b}}};J.uc.wq=J.fj;J.It=function(b){if(J.Mh)throw b=b||"",Error("Importing test-only code into non-debug environment"+(b?": "+b:"."));};J.Pq=D();J.ob=function(b){b=b.split(".");for(var c=J.global,d=0;d<b.length;d++)if(c=c[b[d]],!J.bb(c))return null;return c};
J.wr=function(b,c){c=c||J.global;for(var d in b)c[d]=b[d]};J.jp=D();J.mu=!1;J.Qm=!0;J.zk=function(b){J.global.console&&J.global.console.error(b)};J.Ok=D();J.at=function(){return{}};J.Li="";J.cb=D();J.ip=function(){throw Error("unimplemented abstract method");};J.kp=function(b){b.Ed=void 0;b.jr=function(){if(b.Ed)return b.Ed;J.Z&&(J.lg[J.lg.length]=b);return b.Ed=new b}};J.lg=[];J.Ln=!0;J.ii=J.Z;J.Fg={};J.Bm=!1;J.Wo="detect";J.Xo="";J.oi="transpile.js";J.Cd=null;
J.El=function(){if(null==J.Cd){try{var b=!eval('"use strict";let x = 1; function f() { return typeof x; };f() == "number";')}catch(c){b=!1}J.Cd=b}return J.Cd};J.Ll=function(b){return"(function(){"+b+"\n;})();\n"};
J.ss=function(b){var c=J.ia;try{J.ia={Sb:"",hd:!1,type:J.Ab.Vc};if(J.Ba(b))var d=b.call(void 0,{});else if(J.N(b))J.El()&&(b=J.Ll(b)),d=J.wk.call(void 0,b);else throw Error("Invalid module definition");var e=J.ia.Sb;if(J.N(e)&&e)J.ia.hd?J.gf(e,d):J.ii&&Object.seal&&typeof d==w&&null!=d&&Object.seal(d),J.Fg[e]={sj:d,type:J.Ab.Vc,Jk:J.ia.Sb};else throw Error('Invalid module name "'+e+'"');}finally{J.ia=c}};J.wk=function(b){eval(b);return{}};
J.Ds=function(b){b=b.split("/");for(var c=0;c<b.length;)"."==b[c]?b.splice(c,1):c&&".."==b[c]&&b[c-1]&&".."!=b[c-1]?b.splice(--c,2):c++;return b.join("/")};J.uk=function(b){if(J.global.Gh)return J.global.Gh(b);try{var c=new J.global.XMLHttpRequest;c.open("get",b,!1);c.send();return 0==c.status||200==c.status?c.responseText:null}catch(d){return null}};
J.du=function(b,c,d){var e=J.global.$jscomp;e||(J.global.$jscomp=e={});var f=e.de;if(!f){var g=J.Li+J.oi,h=J.uk(g);if(h){(function(){eval(h+"\n//# sourceURL="+g)}).call(J.global);if(J.global.$gwtExport&&J.global.$gwtExport.$jscomp&&!J.global.$gwtExport.$jscomp.transpile)throw Error('The transpiler did not properly export the "transpile" method. $gwtExport: '+JSON.stringify(J.global.$gwtExport));J.global.$jscomp.de=J.global.$gwtExport.$jscomp.transpile;e=J.global.$jscomp;f=e.de}}if(!f){var l=" requires transpilation but no transpiler was found.";
l+=' Please add "//javascript/closure:transpiler" as a data dependency to ensure it is included.';f=e.de=function(b,c){J.zk(c+l);return b}}return f(b,c,d)};
J.ca=function(b){var c=typeof b;if(c==w)if(b){if(b instanceof Array)return n;if(b instanceof Object)return c;var d=Object.prototype.toString.call(b);if("[object Window]"==d)return w;if("[object Array]"==d||typeof b.length==v&&"undefined"!=typeof b.splice&&"undefined"!=typeof b.propertyIsEnumerable&&!b.propertyIsEnumerable("splice"))return n;if("[object Function]"==d||"undefined"!=typeof b.call&&"undefined"!=typeof b.propertyIsEnumerable&&!b.propertyIsEnumerable("call"))return q}else return"null";
else if(c==q&&"undefined"==typeof b.call)return w;return c};J.cs=function(b){return null===b};J.bb=function(b){return null!=b};J.isArray=function(b){return J.ca(b)==n};J.Nb=function(b){var c=J.ca(b);return c==n||c==w&&typeof b.length==v};J.Or=function(b){return J.ka(b)&&typeof b.getFullYear==q};J.Ba=function(b){return J.ca(b)==q};J.ka=function(b){var c=typeof b;return c==w&&null!=b||c==q};J.bg=function(b){return b[J.Va]||(b[J.Va]=++J.wl)};J.zr=function(b){return!!b[J.Va]};
J.Nk=function(b){null!==b&&"removeAttribute"in b&&b.removeAttribute(J.Va);try{delete b[J.Va]}catch(c){}};J.Va="closure_uid_"+(1E9*Math.random()>>>0);J.wl=0;J.ir=J.bg;J.Ws=J.Nk;J.Wi=function(b){var c=J.ca(b);if(c==w||c==n){if(typeof b.clone===q)return b.clone();c=c==n?[]:{};for(var d in b)c[d]=J.Wi(b[d]);return c}return b};J.Ni=function(b,c,d){return b.call.apply(b.bind,arguments)};
J.Mi=function(b,c,d){if(!b)throw Error();if(2<arguments.length){var e=Array.prototype.slice.call(arguments,2);return function(){var d=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(d,e);return b.apply(c,d)}}return function(){return b.apply(c,arguments)}};J.bind=function(b,c,d){J.bind=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?J.Ni:J.Mi;return J.bind.apply(null,arguments)};
J.eb=function(b,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=d.slice();c.push.apply(c,arguments);return b.apply(this,c)}};J.ys=function(b,c){for(var d in c)b[d]=c[d]};J.now=J.Xc&&Date.now||function(){return+new Date};
J.vr=function(b){if(J.global.execScript)J.global.execScript(b,"JavaScript");else if(J.global.eval){if(null==J.ic){try{J.global.eval("var _evalTest_ = 1;")}catch(e){}if("undefined"!=typeof J.global._evalTest_){try{delete J.global._evalTest_}catch(e){}J.ic=!0}else J.ic=!1}if(J.ic)J.global.eval(b);else{var c=J.global.document,d=c.createElement(k);d.type=A;d.defer=!1;d.appendChild(c.createTextNode(b));c.head.appendChild(d);c.head.removeChild(d)}}else throw Error("goog.globalEval not available");};
J.ic=null;J.fr=function(b,c){function d(b){b=b.split("-");for(var c=[],d=0;d<b.length;d++)c.push(e(b[d]));return c.join("-")}function e(b){return J.lf[b]||b}if("."==String(b).charAt(0))throw Error('className passed in goog.getCssName must not start with ".". You passed: '+b);var f=J.lf?"BY_WHOLE"==J.ej?e:d:C();b=c?b+"-"+f(c):f(b);return J.global.Fh?J.global.Fh(b):b};J.qt=function(b,c){J.lf=b;J.ej=c};
J.lr=function(b,c){c&&(b=b.replace(/\{\$([^}]+)}/g,function(b,e){return null!=c&&e in c?c[e]:b}));return b};J.mr=C();J.rf=function(b,c){J.ld(b,c,void 0)};J.Iq=function(b,c,d){b[c]=d};J.$a=function(b,c){function d(){}d.prototype=c.prototype;b.Hc=c.prototype;b.prototype=new d;b.prototype.constructor=b;b.Ki=function(b,d,g){for(var e=Array(arguments.length-2),f=2;f<arguments.length;f++)e[f-2]=arguments[f];return c.prototype[d].apply(b,e)}};
J.Ki=function(b,c,d){var e=arguments.callee.caller;if(J.mi||J.Z&&!e)throw Error("arguments.caller not defined.  goog.base() cannot be used with strict mode code. See http://www.ecma-international.org/ecma-262/5.1/#sec-C");if("undefined"!==typeof e.Hc){for(var f=Array(arguments.length-1),g=1;g<arguments.length;g++)f[g-1]=arguments[g];return e.Hc.constructor.apply(b,f)}if(typeof c!=z&&"symbol"!=typeof c)throw Error("method names provided to goog.base must be a string or a symbol");f=Array(arguments.length-
2);for(g=2;g<arguments.length;g++)f[g-2]=arguments[g];g=!1;for(var h=b.constructor;h;h=h.Hc&&h.Hc.constructor)if(h.prototype[c]===e)g=!0;else if(g)return h.prototype[c].apply(b,f);if(b[c]===e)return b.constructor.prototype[c].apply(b,f);throw Error("goog.base called from a method of one name to a method of a different name");};J.scope=function(b){if(J.tg())throw Error("goog.scope is not supported within a module.");b.call(J.global)};
J.pa=function(b,c){var d=c.constructor,e=c.ol;d&&d!=Object.prototype.constructor||(d=function(){throw Error("cannot instantiate an interface (no constructor defined).");});d=J.pa.aj(d,b);b&&J.$a(d,b);delete c.constructor;delete c.ol;J.pa.We(d.prototype,c);null!=e&&(e instanceof Function?e(d):J.pa.We(d,e));return d};J.pa.hi=J.Z;
J.pa.aj=function(b,c){function d(){var c=b.apply(this,arguments)||this;c[J.Va]=c[J.Va];this.constructor===d&&e&&Object.seal instanceof Function&&Object.seal(c);return c}if(!J.pa.hi)return b;var e=!J.pa.nk(c);return d};J.pa.nk=function(b){return b&&b.prototype&&b.prototype[J.ri]};J.pa.He=["constructor",u,"isPrototypeOf",y,B,"toString","valueOf"];
J.pa.We=function(b,c){for(var d in c)Object.prototype.hasOwnProperty.call(c,d)&&(b[d]=c[d]);for(var e=0;e<J.pa.He.length;e++)d=J.pa.He[e],Object.prototype.hasOwnProperty.call(c,d)&&(b[d]=c[d])};J.Xt=D();J.ri="goog_defineClass_legacy_unsealable";J.debug={};J.debug.Error=function(b){if(Error.captureStackTrace)Error.captureStackTrace(this,J.debug.Error);else{var c=Error().stack;c&&(this.stack=c)}b&&(this.message=String(b))};J.$a(J.debug.Error,Error);J.debug.Error.prototype.name="CustomError";J.a={};J.a.fa={Ja:1,am:2,ac:3,pm:4,Sm:5,Rm:6,mo:7,wm:8,Sc:9,Jm:10,Nh:11,Zn:12};J.o={};J.o.ma=J.Z;J.o.Vb=function(b,c){J.debug.Error.call(this,J.o.ql(b,c))};J.$a(J.o.Vb,J.debug.Error);J.o.Vb.prototype.name="AssertionError";J.o.Kh=function(b){throw b;};J.o.jd=J.o.Kh;J.o.ql=function(b,c){b=b.split("%s");for(var d="",e=b.length-1,f=0;f<e;f++)d+=b[f]+(f<c.length?c[f]:"%s");return d+b[e]};J.o.Aa=function(b,c,d,e){var f="Assertion failed";if(d){f+=": "+d;var g=e}else b&&(f+=": "+b,g=c);b=new J.o.Vb(""+f,g||[]);J.o.jd(b)};J.o.ut=function(b){J.o.ma&&(J.o.jd=b)};
J.o.assert=function(b,c,d){J.o.ma&&!b&&J.o.Aa("",null,c,Array.prototype.slice.call(arguments,2));return b};J.o.ha=function(b,c){J.o.ma&&J.o.jd(new J.o.Vb("Failure"+(b?": "+b:""),Array.prototype.slice.call(arguments,1)))};J.o.Hp=function(b,c,d){J.o.ma&&!J.Rb(b)&&J.o.Aa("Expected number but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.Kp=function(b,c,d){J.o.ma&&!J.N(b)&&J.o.Aa("Expected string but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.tp=function(b,c,d){J.o.ma&&!J.Ba(b)&&J.o.Aa("Expected function but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.Ip=function(b,c,d){J.o.ma&&!J.ka(b)&&J.o.Aa("Expected object but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.pp=function(b,c,d){J.o.ma&&!J.isArray(b)&&J.o.Aa("Expected array but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.qp=function(b,c,d){J.o.ma&&!J.Yj(b)&&J.o.Aa("Expected boolean but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.rp=function(b,c,d){!J.o.ma||J.ka(b)&&b.nodeType==J.a.fa.Ja||J.o.Aa("Expected Element but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.up=function(b,c,d,e){!J.o.ma||b instanceof c||J.o.Aa("Expected instanceof %s but got %s.",[J.o.ag(c),J.o.ag(b)],d,Array.prototype.slice.call(arguments,3));return b};J.o.sp=function(b,c,d){!J.o.ma||typeof b==v&&isFinite(b)||J.o.Aa("Expected %s to be a finite number but it is not.",[b],c,Array.prototype.slice.call(arguments,2));return b};J.o.Jp=function(){for(var b in Object.prototype)J.o.ha(b+" should not be enumerable in Object.prototype.")};
J.o.ag=function(b){return b instanceof Function?b.displayName||b.name||"unknown type name":b instanceof Object?b.constructor.displayName||b.constructor.name||Object.prototype.toString.call(b):null===b?"null":typeof b};J.j={};J.Fa=J.Xc;J.j.Ca=!1;J.j.Lk=function(b){return b[b.length-1]};J.j.os=J.j.Lk;J.j.indexOf=J.Fa&&(J.j.Ca||Array.prototype.indexOf)?function(b,c,d){return Array.prototype.indexOf.call(b,c,d)}:function(b,c,d){d=null==d?0:0>d?Math.max(0,b.length+d):d;if(J.N(b))return J.N(c)&&1==c.length?b.indexOf(c,d):-1;for(;d<b.length;d++)if(d in b&&b[d]===c)return d;return-1};
J.j.lastIndexOf=J.Fa&&(J.j.Ca||Array.prototype.lastIndexOf)?function(b,c,d){return Array.prototype.lastIndexOf.call(b,c,null==d?b.length-1:d)}:function(b,c,d){d=null==d?b.length-1:d;0>d&&(d=Math.max(0,b.length+d));if(J.N(b))return J.N(c)&&1==c.length?b.lastIndexOf(c,d):-1;for(;0<=d;d--)if(d in b&&b[d]===c)return d;return-1};
J.j.forEach=J.Fa&&(J.j.Ca||Array.prototype.forEach)?function(b,c,d){Array.prototype.forEach.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)g in f&&c.call(d,f[g],g,b)};J.j.yf=function(b,c){for(var d=J.N(b)?b.split(""):b,e=b.length-1;0<=e;--e)e in d&&c.call(void 0,d[e],e,b)};
J.j.filter=J.Fa&&(J.j.Ca||Array.prototype.filter)?function(b,c,d){return Array.prototype.filter.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=[],g=0,h=J.N(b)?b.split(""):b,l=0;l<e;l++)if(l in h){var m=h[l];c.call(d,m,l,b)&&(f[g++]=m)}return f};J.j.map=J.Fa&&(J.j.Ca||Array.prototype.map)?function(b,c,d){return Array.prototype.map.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=Array(e),g=J.N(b)?b.split(""):b,h=0;h<e;h++)h in g&&(f[h]=c.call(d,g[h],h,b));return f};
J.j.reduce=J.Fa&&(J.j.Ca||Array.prototype.reduce)?function(b,c,d,e){e&&(c=J.bind(c,e));return Array.prototype.reduce.call(b,c,d)}:function(b,c,d,e){var f=d;J.j.forEach(b,function(d,h){f=c.call(e,f,d,h,b)});return f};J.j.reduceRight=J.Fa&&(J.j.Ca||Array.prototype.reduceRight)?function(b,c,d,e){e&&(c=J.bind(c,e));return Array.prototype.reduceRight.call(b,c,d)}:function(b,c,d,e){var f=d;J.j.yf(b,function(d,h){f=c.call(e,f,d,h,b)});return f};
J.j.some=J.Fa&&(J.j.Ca||Array.prototype.some)?function(b,c,d){return Array.prototype.some.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&c.call(d,f[g],g,b))return!0;return!1};J.j.every=J.Fa&&(J.j.Ca||Array.prototype.every)?function(b,c,d){return Array.prototype.every.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&!c.call(d,f[g],g,b))return!1;return!0};
J.j.count=function(b,c,d){var e=0;J.j.forEach(b,function(b,g,h){c.call(d,b,g,h)&&++e},d);return e};J.j.find=function(b,c,d){c=J.j.findIndex(b,c,d);return 0>c?null:J.N(b)?b.charAt(c):b[c]};J.j.findIndex=function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&c.call(d,f[g],g,b))return g;return-1};J.j.Kq=function(b,c,d){c=J.j.tj(b,c,d);return 0>c?null:J.N(b)?b.charAt(c):b[c]};
J.j.tj=function(b,c,d){for(var e=J.N(b)?b.split(""):b,f=b.length-1;0<=f;f--)if(f in e&&c.call(d,e[f],f,b))return f;return-1};J.j.contains=function(b,c){return 0<=J.j.indexOf(b,c)};J.j.Qb=function(b){return 0==b.length};J.j.clear=function(b){if(!J.isArray(b))for(var c=b.length-1;0<=c;c--)delete b[c];b.length=0};J.j.Dr=function(b,c){J.j.contains(b,c)||b.push(c)};J.j.hg=function(b,c,d){J.j.splice(b,d,0,c)};J.j.Fr=function(b,c,d){J.eb(J.j.splice,b,d,0).apply(null,c)};
J.j.insertBefore=function(b,c,d){var e;2==arguments.length||0>(e=J.j.indexOf(b,d))?b.push(c):J.j.hg(b,c,e)};J.j.remove=function(b,c){c=J.j.indexOf(b,c);var d;(d=0<=c)&&J.j.wb(b,c);return d};J.j.Ys=function(b,c){c=J.j.lastIndexOf(b,c);return 0<=c?(J.j.wb(b,c),!0):!1};J.j.wb=function(b,c){return 1==Array.prototype.splice.call(b,c,1).length};J.j.Xs=function(b,c,d){c=J.j.findIndex(b,c,d);return 0<=c?(J.j.wb(b,c),!0):!1};
J.j.Us=function(b,c,d){var e=0;J.j.yf(b,function(f,g){c.call(d,f,g,b)&&J.j.wb(b,g)&&e++});return e};J.j.concat=function(b){return Array.prototype.concat.apply([],arguments)};J.j.join=function(b){return Array.prototype.concat.apply([],arguments)};J.j.jh=function(b){var c=b.length;if(0<c){for(var d=Array(c),e=0;e<c;e++)d[e]=b[e];return d}return[]};J.j.clone=J.j.jh;
J.j.extend=function(b,c){for(var d=1;d<arguments.length;d++){var e=arguments[d];if(J.Nb(e)){var f=b.length||0,g=e.length||0;b.length=f+g;for(var h=0;h<g;h++)b[f+h]=e[h]}else b.push(e)}};J.j.splice=function(b,c,d,e){return Array.prototype.splice.apply(b,J.j.slice(arguments,1))};J.j.slice=function(b,c,d){return 2>=arguments.length?Array.prototype.slice.call(b,c):Array.prototype.slice.call(b,c,d)};
J.j.Vs=function(b,c,d){function e(b){return J.ka(b)?"o"+J.bg(b):(typeof b).charAt(0)+b}c=c||b;d=d||e;for(var f={},g=0,h=0;h<b.length;){var l=b[h++],m=d(l);Object.prototype.hasOwnProperty.call(f,m)||(f[m]=!0,c[g++]=l)}c.length=g};J.j.Ze=function(b,c,d){return J.j.$e(b,d||J.j.Oa,!1,c)};J.j.Op=function(b,c,d){return J.j.$e(b,c,!0,void 0,d)};J.j.$e=function(b,c,d,e,f){for(var g=0,h=b.length,l;g<h;){var m=g+h>>1;var r=d?c.call(f,b[m],m,b):c(e,b[m]);0<r?g=m+1:(h=m,l=!r)}return l?g:~g};
J.j.sort=function(b,c){b.sort(c||J.j.Oa)};J.j.Rt=function(b,c){for(var d=Array(b.length),e=0;e<b.length;e++)d[e]={index:e,value:b[e]};var f=c||J.j.Oa;J.j.sort(d,function(b,c){return f(b.value,c.value)||b.index-c.index});for(e=0;e<b.length;e++)b[e]=d[e].value};J.j.ml=function(b,c,d){var e=d||J.j.Oa;J.j.sort(b,function(b,d){return e(c(b),c(d))})};J.j.Ot=function(b,c,d){J.j.ml(b,function(b){return b[c]},d)};
J.j.js=function(b,c,d){c=c||J.j.Oa;for(var e=1;e<b.length;e++){var f=c(b[e-1],b[e]);if(0<f||0==f&&d)return!1}return!0};J.j.Ib=function(b,c){if(!J.Nb(b)||!J.Nb(c)||b.length!=c.length)return!1;for(var d=b.length,e=J.j.gj,f=0;f<d;f++)if(!e(b[f],c[f]))return!1;return!0};J.j.cq=function(b,c,d){d=d||J.j.Oa;for(var e=Math.min(b.length,c.length),f=0;f<e;f++){var g=d(b[f],c[f]);if(0!=g)return g}return J.j.Oa(b.length,c.length)};J.j.Oa=function(b,c){return b>c?1:b<c?-1:0};
J.j.Hr=function(b,c){return-J.j.Oa(b,c)};J.j.gj=function(b,c){return b===c};J.j.Mp=function(b,c,d){d=J.j.Ze(b,c,d);return 0>d?(J.j.hg(b,c,-(d+1)),!0):!1};J.j.Np=function(b,c,d){c=J.j.Ze(b,c,d);return 0<=c?J.j.wb(b,c):!1};J.j.Qp=function(b,c,d){for(var e={},f=0;f<b.length;f++){var g=b[f],h=c.call(d,g,f,b);J.W(h)&&(e[h]||(e[h]=[])).push(g)}return e};J.j.au=function(b,c,d){var e={};J.j.forEach(b,function(f,g){e[c.call(d,f,g,b)]=f});return e};
J.j.Qs=function(b,c,d){var e=[],f=0,g=b;d=d||1;void 0!==c&&(f=b,g=c);if(0>d*(g-f))return[];if(0<d)for(b=f;b<g;b+=d)e.push(b);else for(b=f;b>g;b+=d)e.push(b);return e};J.j.repeat=function(b,c){for(var d=[],e=0;e<c;e++)d[e]=b;return d};J.j.flatten=function(b){for(var c=[],d=0;d<arguments.length;d++){var e=arguments[d];if(J.isArray(e))for(var f=0;f<e.length;f+=8192)for(var g=J.j.flatten.apply(null,J.j.slice(e,f,f+8192)),h=0;h<g.length;h++)c.push(g[h]);else c.push(e)}return c};
J.j.rotate=function(b,c){b.length&&(c%=b.length,0<c?Array.prototype.unshift.apply(b,b.splice(-c,c)):0>c&&Array.prototype.push.apply(b,b.splice(0,-c)));return b};J.j.As=function(b,c,d){c=Array.prototype.splice.call(b,c,1);Array.prototype.splice.call(b,d,0,c[0])};
J.j.qu=function(b){if(!arguments.length)return[];for(var c=[],d=arguments[0].length,e=1;e<arguments.length;e++)arguments[e].length<d&&(d=arguments[e].length);for(e=0;e<d;e++){for(var f=[],g=0;g<arguments.length;g++)f.push(arguments[g][e]);c.push(f)}return c};J.j.Nt=function(b,c){c=c||Math.random;for(var d=b.length-1;0<d;d--){var e=Math.floor(c()*(d+1)),f=b[d];b[d]=b[e];b[e]=f}};J.j.iq=function(b,c){var d=[];J.j.forEach(c,function(c){d.push(b[c])});return d};
J.j.fq=function(b,c,d){return J.j.concat.apply([],J.j.map(b,c,d))};J.async={};J.async.Xb=function(b,c,d){this.tk=d;this.dj=b;this.Pk=c;this.vc=0;this.qc=null};J.async.Xb.prototype.get=function(){if(0<this.vc){this.vc--;var b=this.qc;this.qc=b.next;b.next=null}else b=this.dj();return b};J.async.Xb.prototype.put=function(b){this.Pk(b);this.vc<this.tk&&(this.vc++,b.next=this.qc,this.qc=b)};J.debug.aa={};J.debug.Tm=D();J.debug.aa.vb=[];J.debug.aa.Qd=[];J.debug.aa.Mg=!1;J.debug.aa.register=function(b){J.debug.aa.vb[J.debug.aa.vb.length]=b;if(J.debug.aa.Mg)for(var c=J.debug.aa.Qd,d=0;d<c.length;d++)b(J.bind(c[d].Ml,c[d]))};J.debug.aa.zs=function(b){J.debug.aa.Mg=!0;for(var c=J.bind(b.Ml,b),d=0;d<J.debug.aa.vb.length;d++)J.debug.aa.vb[d](c);J.debug.aa.Qd.push(b)};J.debug.aa.ju=function(b){var c=J.debug.aa.Qd;b=J.bind(b.s,b);for(var d=0;d<J.debug.aa.vb.length;d++)J.debug.aa.vb[d](b);c.length--};J.a.on=D();J.a.c=function(b){this.rl=b};J.a.c.prototype.toString=E("rl");J.a.c.Nl=new J.a.c("A");J.a.c.Ol=new J.a.c("ABBR");J.a.c.Ql=new J.a.c("ACRONYM");J.a.c.Rl=new J.a.c("ADDRESS");J.a.c.Vl=new J.a.c("APPLET");J.a.c.Wl=new J.a.c("AREA");J.a.c.Xl=new J.a.c("ARTICLE");J.a.c.Yl=new J.a.c("ASIDE");J.a.c.bm=new J.a.c("AUDIO");J.a.c.cm=new J.a.c("B");J.a.c.dm=new J.a.c("BASE");J.a.c.em=new J.a.c("BASEFONT");J.a.c.fm=new J.a.c("BDI");J.a.c.gm=new J.a.c("BDO");J.a.c.jm=new J.a.c("BIG");J.a.c.km=new J.a.c("BLOCKQUOTE");
J.a.c.lm=new J.a.c("BODY");J.a.c.re=new J.a.c("BR");J.a.c.mm=new J.a.c("BUTTON");J.a.c.nm=new J.a.c("CANVAS");J.a.c.om=new J.a.c("CAPTION");J.a.c.qm=new J.a.c("CENTER");J.a.c.rm=new J.a.c("CITE");J.a.c.sm=new J.a.c("CODE");J.a.c.tm=new J.a.c("COL");J.a.c.um=new J.a.c("COLGROUP");J.a.c.vm=new J.a.c("COMMAND");J.a.c.xm=new J.a.c("DATA");J.a.c.ym=new J.a.c("DATALIST");J.a.c.zm=new J.a.c("DD");J.a.c.Am=new J.a.c("DEL");J.a.c.Cm=new J.a.c("DETAILS");J.a.c.Dm=new J.a.c("DFN");J.a.c.Em=new J.a.c("DIALOG");
J.a.c.Fm=new J.a.c("DIR");J.a.c.Gm=new J.a.c("DIV");J.a.c.Hm=new J.a.c("DL");J.a.c.Km=new J.a.c("DT");J.a.c.Nm=new J.a.c("EM");J.a.c.Om=new J.a.c("EMBED");J.a.c.Vm=new J.a.c("FIELDSET");J.a.c.Wm=new J.a.c("FIGCAPTION");J.a.c.Xm=new J.a.c("FIGURE");J.a.c.Ym=new J.a.c("FONT");J.a.c.Zm=new J.a.c("FOOTER");J.a.c.$m=new J.a.c("FORM");J.a.c.an=new J.a.c("FRAME");J.a.c.bn=new J.a.c("FRAMESET");J.a.c.cn=new J.a.c("H1");J.a.c.dn=new J.a.c("H2");J.a.c.en=new J.a.c("H3");J.a.c.fn=new J.a.c("H4");J.a.c.gn=new J.a.c("H5");
J.a.c.hn=new J.a.c("H6");J.a.c.jn=new J.a.c("HEAD");J.a.c.kn=new J.a.c("HEADER");J.a.c.ln=new J.a.c("HGROUP");J.a.c.mn=new J.a.c("HR");J.a.c.nn=new J.a.c("HTML");J.a.c.pn=new J.a.c("I");J.a.c.sn=new J.a.c("IFRAME");J.a.c.tn=new J.a.c("IMG");J.a.c.un=new J.a.c("INPUT");J.a.c.vn=new J.a.c("INS");J.a.c.An=new J.a.c("ISINDEX");J.a.c.Dn=new J.a.c("KBD");J.a.c.En=new J.a.c("KEYGEN");J.a.c.Fn=new J.a.c("LABEL");J.a.c.Hn=new J.a.c("LEGEND");J.a.c.In=new J.a.c("LI");J.a.c.Jn=new J.a.c("LINK");J.a.c.Nn=new J.a.c("MAIN");
J.a.c.On=new J.a.c("MAP");J.a.c.Pn=new J.a.c("MARK");J.a.c.Qn=new J.a.c("MATH");J.a.c.Rn=new J.a.c("MENU");J.a.c.Sn=new J.a.c("MENUITEM");J.a.c.Tn=new J.a.c("META");J.a.c.Un=new J.a.c("METER");J.a.c.Wn=new J.a.c("NAV");J.a.c.Xn=new J.a.c("NOFRAMES");J.a.c.Yn=new J.a.c("NOSCRIPT");J.a.c.ao=new J.a.c("OBJECT");J.a.c.bo=new J.a.c("OL");J.a.c.co=new J.a.c("OPTGROUP");J.a.c.eo=new J.a.c("OPTION");J.a.c.fo=new J.a.c("OUTPUT");J.a.c.ho=new J.a.c("P");J.a.c.io=new J.a.c("PARAM");J.a.c.jo=new J.a.c("PICTURE");
J.a.c.lo=new J.a.c("PRE");J.a.c.no=new J.a.c("PROGRESS");J.a.c.Q=new J.a.c("Q");J.a.c.oo=new J.a.c("RP");J.a.c.po=new J.a.c("RT");J.a.c.qo=new J.a.c("RTC");J.a.c.ro=new J.a.c("RUBY");J.a.c.to=new J.a.c("S");J.a.c.wo=new J.a.c("SAMP");J.a.c.xo=new J.a.c(k);J.a.c.yo=new J.a.c("SECTION");J.a.c.zo=new J.a.c("SELECT");J.a.c.Ao=new J.a.c("SMALL");J.a.c.Bo=new J.a.c("SOURCE");J.a.c.Co=new J.a.c("SPAN");J.a.c.Do=new J.a.c("STRIKE");J.a.c.Eo=new J.a.c("STRONG");J.a.c.Fo=new J.a.c("STYLE");J.a.c.Go=new J.a.c("SUB");
J.a.c.Ho=new J.a.c("SUMMARY");J.a.c.Io=new J.a.c("SUP");J.a.c.Jo=new J.a.c("SVG");J.a.c.Ko=new J.a.c("TABLE");J.a.c.Lo=new J.a.c("TBODY");J.a.c.Mo=new J.a.c("TD");J.a.c.No=new J.a.c("TEMPLATE");J.a.c.Oo=new J.a.c("TEXTAREA");J.a.c.Po=new J.a.c("TFOOT");J.a.c.Qo=new J.a.c("TH");J.a.c.Ro=new J.a.c("THEAD");J.a.c.So=new J.a.c("TIME");J.a.c.To=new J.a.c("TITLE");J.a.c.Uo=new J.a.c("TR");J.a.c.Vo=new J.a.c("TRACK");J.a.c.Zo=new J.a.c("TT");J.a.c.ap=new J.a.c("U");J.a.c.bp=new J.a.c("UL");J.a.c.cp=new J.a.c("VAR");
J.a.c.ep=new J.a.c("VIDEO");J.a.c.fp=new J.a.c("WBR");J.M={};J.M.Xi=function(b){return function(){return b}};J.M.Um=F(!1);J.M.Yo=F(!0);J.M.$n=F(null);J.M.Wj=C();J.M.error=function(b){return function(){throw Error(b);}};J.M.ha=function(b){return function(){throw b;}};J.M.lock=function(b,c){c=c||0;return function(){return b.apply(this,Array.prototype.slice.call(arguments,0,c))}};J.M.Hs=function(b){return function(){return arguments[b]}};
J.M.Ms=function(b,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=Array.prototype.slice.call(arguments);c.push.apply(c,d);return b.apply(this,c)}};J.M.pu=function(b,c){return J.M.fl(b,J.M.Xi(c))};J.M.Gq=function(b,c){return function(d){return c?b==d:b===d}};J.M.eq=function(b,c){var d=arguments,e=d.length;return function(){var b;e&&(b=d[e-1].apply(this,arguments));for(var c=e-2;0<=c;c--)b=d[c].call(this,b);return b}};
J.M.fl=function(b){var c=arguments,d=c.length;return function(){for(var b,f=0;f<d;f++)b=c[f].apply(this,arguments);return b}};J.M.and=function(b){var c=arguments,d=c.length;return function(){for(var b=0;b<d;b++)if(!c[b].apply(this,arguments))return!1;return!0}};J.M.or=function(b){var c=arguments,d=c.length;return function(){for(var b=0;b<d;b++)if(c[b].apply(this,arguments))return!0;return!1}};J.M.Gs=function(b){return function(){return!b.apply(this,arguments)}};
J.M.create=function(b,c){function d(){}d.prototype=b.prototype;var e=new d;b.apply(e,Array.prototype.slice.call(arguments,1));return e};J.M.Bh=!0;J.M.Ri=function(b){var c=!1,d;return function(){if(!J.M.Bh)return b();c||(d=b(),c=!0);return d}};J.M.once=function(b){var c=b;return function(){if(c){var b=c;c=null;b()}}};J.M.uq=function(b,c,d){var e=0;return function(f){J.global.clearTimeout(e);var g=arguments;e=J.global.setTimeout(function(){b.apply(d,g)},c)}};
J.M.Yt=function(b,c,d){function e(){g=J.global.setTimeout(f,c);b.apply(d,l)}function f(){g=0;h&&(h=!1,e())}var g=0,h=!1,l=[];return function(b){l=arguments;g?h=!0:e()}};J.M.Rs=function(b,c,d){function e(){f=0}var f=0;return function(g){f||(f=J.global.setTimeout(e,c),b.apply(d,arguments))}};J.f={};J.f.Rc=!1;J.f.Ph=!1;J.f.Re={Fe:"\u00a0"};J.f.startsWith=function(b,c){return 0==b.lastIndexOf(c,0)};J.f.endsWith=function(b,c){var d=b.length-c.length;return 0<=d&&b.indexOf(c,d)==d};J.f.bd=function(b,c){return 0==J.f.af(c,b.substr(0,c.length))};J.f.Vp=function(b,c){return 0==J.f.af(c,b.substr(b.length-c.length,c.length))};J.f.Wp=function(b,c){return b.toLowerCase()==c.toLowerCase()};
J.f.Wt=function(b,c){for(var d=b.split("%s"),e="",f=Array.prototype.slice.call(arguments,1);f.length&&1<d.length;)e+=d.shift()+f.shift();return e+d.join("%s")};J.f.bq=function(b){return b.replace(/[\s\xa0]+/g," ").replace(/^\s+|\s+$/g,"")};J.f.Gd=function(b){return/^[\s\xa0]*$/.test(b)};J.f.Rr=function(b){return 0==b.length};J.f.Qb=J.f.Gd;J.f.$j=function(b){return J.f.Gd(J.f.Ek(b))};J.f.Qr=J.f.$j;J.f.Lr=function(b){return!/[^\t\n\r ]/.test(b)};J.f.Ir=function(b){return!/[^a-zA-Z]/.test(b)};
J.f.ds=function(b){return!/[^0-9]/.test(b)};J.f.Jr=function(b){return!/[^a-zA-Z0-9]/.test(b)};J.f.ks=function(b){return" "==b};J.f.ls=function(b){return 1==b.length&&" "<=b&&"~">=b||"\u0080"<=b&&"\ufffd">=b};J.f.Ut=function(b){return b.replace(/(\r\n|\r|\n)+/g," ")};J.f.Ui=function(b){return b.replace(/(\r\n|\r|\n)/g,"\n")};J.f.Fs=function(b){return b.replace(/\xa0|\s/g," ")};J.f.Es=function(b){return b.replace(/\xa0|[ \t]+/g," ")};
J.f.aq=function(b){return b.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")};J.f.trim=J.Xc&&String.prototype.trim?function(b){return b.trim()}:function(b){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(b)[1]};J.f.trimLeft=function(b){return b.replace(/^[\s\xa0]+/,"")};J.f.trimRight=function(b){return b.replace(/[\s\xa0]+$/,"")};J.f.af=function(b,c){b=String(b).toLowerCase();c=String(c).toLowerCase();return b<c?-1:b==c?0:1};
J.f.Og=function(b,c,d){if(b==c)return 0;if(!b)return-1;if(!c)return 1;for(var e=b.toLowerCase().match(d),f=c.toLowerCase().match(d),g=Math.min(e.length,f.length),h=0;h<g;h++){d=e[h];var l=f[h];if(d!=l)return b=parseInt(d,10),!isNaN(b)&&(c=parseInt(l,10),!isNaN(c)&&b-c)?b-c:d<l?-1:1}return e.length!=f.length?e.length-f.length:b<c?-1:1};J.f.Gr=function(b,c){return J.f.Og(b,c,/\d+|\D+/g)};J.f.vj=function(b,c){return J.f.Og(b,c,/\d+|\.\d+|\D+/g)};J.f.Is=J.f.vj;J.f.lu=function(b){return encodeURIComponent(String(b))};
J.f.ku=function(b){return decodeURIComponent(b.replace(/\+/g," "))};J.f.Ng=function(b,c){return b.replace(/(\r\n|\r|\n)/g,c?"<br />":"<br>")};
J.f.va=function(b,c){if(c)b=b.replace(J.f.fe,"&amp;").replace(J.f.Ee,"&lt;").replace(J.f.Be,"&gt;").replace(J.f.Le,"&quot;").replace(J.f.Ne,"&#39;").replace(J.f.Ge,"&#0;"),J.f.Rc&&(b=b.replace(J.f.xe,"&#101;"));else{if(!J.f.th.test(b))return b;-1!=b.indexOf("&")&&(b=b.replace(J.f.fe,"&amp;"));-1!=b.indexOf("<")&&(b=b.replace(J.f.Ee,"&lt;"));-1!=b.indexOf(">")&&(b=b.replace(J.f.Be,"&gt;"));-1!=b.indexOf('"')&&(b=b.replace(J.f.Le,"&quot;"));-1!=b.indexOf("'")&&(b=b.replace(J.f.Ne,"&#39;"));-1!=b.indexOf("\x00")&&
(b=b.replace(J.f.Ge,"&#0;"));J.f.Rc&&-1!=b.indexOf("e")&&(b=b.replace(J.f.xe,"&#101;"))}return b};J.f.fe=/&/g;J.f.Ee=/</g;J.f.Be=/>/g;J.f.Le=/"/g;J.f.Ne=/'/g;J.f.Ge=/\x00/g;J.f.xe=/e/g;J.f.th=J.f.Rc?/[\x00&<>"'e]/:/[\x00&<>"']/;J.f.lh=function(b){return J.f.contains(b,"&")?!J.f.Ph&&"document"in J.global?J.f.mh(b):J.f.zl(b):b};J.f.hu=function(b,c){return J.f.contains(b,"&")?J.f.mh(b,c):b};
J.f.mh=function(b,c){var d={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'};var e=c?c.createElement("div"):J.global.document.createElement("div");return b.replace(J.f.Th,function(b,c){var f=d[b];if(f)return f;"#"==c.charAt(0)&&(c=Number("0"+c.substr(1)),isNaN(c)||(f=String.fromCharCode(c)));f||(e.innerHTML=b+" ",f=e.firstChild.nodeValue.slice(0,-1));return d[b]=f})};
J.f.zl=function(b){return b.replace(/&([^;]+);/g,function(b,d){switch(d){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:return"#"!=d.charAt(0)||(d=Number("0"+d.substr(1)),isNaN(d))?b:String.fromCharCode(d)}})};J.f.Th=/&([^;\s<&]+);?/g;J.f.Jl=function(b){return J.f.Ng(b.replace(/  /g," &#160;"),void 0)};J.f.Ns=function(b){return b.replace(/(^|[\n ]) /g,"$1"+J.f.Re.Fe)};
J.f.Vt=function(b,c){for(var d=c.length,e=0;e<d;e++){var f=1==d?c:c.charAt(e);if(b.charAt(0)==f&&b.charAt(b.length-1)==f)return b.substring(1,b.length-1)}return b};J.f.truncate=function(b,c,d){d&&(b=J.f.lh(b));b.length>c&&(b=b.substring(0,c-3)+"...");d&&(b=J.f.va(b));return b};J.f.fu=function(b,c,d,e){d&&(b=J.f.lh(b));e&&b.length>c?(e>c&&(e=c),b=b.substring(0,c-e)+"..."+b.substring(b.length-e)):b.length>c&&(e=Math.floor(c/2),b=b.substring(0,e+c%2)+"..."+b.substring(b.length-e));d&&(b=J.f.va(b));return b};
J.f.Zd={"\x00":"\\0","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\x0B":"\\x0B",'"':'\\"',"\\":"\\\\","<":"<"};J.f.sc={"'":"\\'"};J.f.quote=function(b){b=String(b);for(var c=['"'],d=0;d<b.length;d++){var e=b.charAt(d),f=e.charCodeAt(0);c[d+1]=J.f.Zd[e]||(31<f&&127>f?e:J.f.pf(e))}c.push('"');return c.join("")};J.f.Hq=function(b){for(var c=[],d=0;d<b.length;d++)c[d]=J.f.pf(b.charAt(d));return c.join("")};
J.f.pf=function(b){if(b in J.f.sc)return J.f.sc[b];if(b in J.f.Zd)return J.f.sc[b]=J.f.Zd[b];var c=b.charCodeAt(0);if(31<c&&127>c)var d=b;else{if(256>c){if(d="\\x",16>c||256<c)d+="0"}else d="\\u",4096>c&&(d+="0");d+=c.toString(16).toUpperCase()}return J.f.sc[b]=d};J.f.contains=function(b,c){return-1!=b.indexOf(c)};J.f.bf=function(b,c){return J.f.contains(b.toLowerCase(),c.toLowerCase())};J.f.jq=function(b,c){return b&&c?b.split(c).length-1:0};J.f.wb=C();
J.f.remove=function(b,c){return b.replace(c,"")};J.f.Ts=function(b,c){c=new RegExp(J.f.Rd(c),"g");return b.replace(c,"")};J.f.Zs=function(b,c,d){c=new RegExp(J.f.Rd(c),"g");return b.replace(c,d.replace(/\$/g,"$$$$"))};J.f.Rd=function(b){return String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08")};J.f.repeat=String.prototype.repeat?function(b,c){return b.repeat(c)}:function(b,c){return Array(c+1).join(b)};
J.f.Ls=function(b,c,d){b=J.W(d)?b.toFixed(d):String(b);d=b.indexOf(".");-1==d&&(d=b.length);return J.f.repeat("0",Math.max(0,c-d))+b};J.f.Ek=function(b){return null==b?"":String(b)};J.f.Rp=function(b){return Array.prototype.join.call(arguments,"")};J.f.rr=function(){return Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^J.now()).toString(36)};
J.f.Db=function(b,c){var d=0;b=J.f.trim(String(b)).split(".");c=J.f.trim(String(c)).split(".");for(var e=Math.max(b.length,c.length),f=0;0==d&&f<e;f++){var g=b[f]||"",h=c[f]||"";do{g=/(\d*)(\D*)(.*)/.exec(g)||["","","",""];h=/(\d*)(\D*)(.*)/.exec(h)||["","","",""];if(0==g[0].length&&0==h[0].length)break;d=J.f.cd(0==g[1].length?0:parseInt(g[1],10),0==h[1].length?0:parseInt(h[1],10))||J.f.cd(0==g[2].length,0==h[2].length)||J.f.cd(g[2],h[2]);g=g[3];h=h[3]}while(0==d)}return d};
J.f.cd=function(b,c){return b<c?-1:b>c?1:0};J.f.Ar=function(b){for(var c=0,d=0;d<b.length;++d)c=31*c+b.charCodeAt(d)>>>0;return c};J.f.Al=2147483648*Math.random()|0;J.f.sq=function(){return"goog_"+J.f.Al++};J.f.$t=function(b){var c=Number(b);return 0==c&&J.f.Gd(b)?NaN:c};J.f.Wr=function(b){return/^[a-z]+([A-Z][a-z]*)*$/.test(b)};J.f.ms=function(b){return/^([A-Z][a-z]*)+$/.test(b)};J.f.Zt=function(b){return String(b).replace(/\-([a-z])/g,function(b,d){return d.toUpperCase()})};
J.f.bu=function(b){return String(b).replace(/([A-Z])/g,"-$1").toLowerCase()};J.f.cu=function(b,c){c=J.N(c)?J.f.Rd(c):"\\s";return b.replace(new RegExp("(^"+(c?"|["+c+"]+":"")+")([a-z])","g"),function(b,c,f){return c+f.toUpperCase()})};J.f.Up=function(b){return String(b.charAt(0)).toUpperCase()+String(b.substr(1)).toLowerCase()};J.f.parseInt=function(b){isFinite(b)&&(b=String(b));return J.N(b)?/^\s*-?0x/i.test(b)?parseInt(b,16):parseInt(b,10):NaN};
J.f.Pt=function(b,c,d){b=b.split(c);for(var e=[];0<d&&b.length;)e.push(b.shift()),d--;b.length&&e.push(b.join(c));return e};J.f.ps=function(b,c){if(c)typeof c==z&&(c=[c]);else return b;for(var d=-1,e=0;e<c.length;e++)if(""!=c[e]){var f=b.lastIndexOf(c[e]);f>d&&(d=f)}return-1==d?b:b.slice(d+1)};
J.f.Bq=function(b,c){var d=[],e=[];if(b==c)return 0;if(!b.length||!c.length)return Math.max(b.length,c.length);for(var f=0;f<c.length+1;f++)d[f]=f;for(f=0;f<b.length;f++){e[0]=f+1;for(var g=0;g<c.length;g++)e[g+1]=Math.min(e[g]+1,d[g+1]+1,d[g]+Number(b[f]!=c[g]));for(g=0;g<d.length;g++)d[g]=e[g]}return e[c.length]};J.g={};J.g.userAgent={};J.g.userAgent.A={};J.g.userAgent.A.Of=function(){var b=J.g.userAgent.A.Fj();return b&&(b=b.userAgent)?b:""};J.g.userAgent.A.Fj=function(){return J.global.navigator};J.g.userAgent.A.nh=J.g.userAgent.A.Of();J.g.userAgent.A.Kt=function(b){J.g.userAgent.A.nh=b||J.g.userAgent.A.Of()};J.g.userAgent.A.pb=function(){return J.g.userAgent.A.nh};J.g.userAgent.A.L=function(b){return J.f.contains(J.g.userAgent.A.pb(),b)};
J.g.userAgent.A.Jg=function(b){return J.f.bf(J.g.userAgent.A.pb(),b)};J.g.userAgent.A.sf=function(b){for(var c=/(\w[\w ]+)\/([^\s]+)\s*(?:\((.*?)\))?/g,d=[],e;e=c.exec(b);)d.push([e[1],e[2],e[3]||void 0]);return d};J.object={};J.object.is=function(b,c){return b===c?0!==b||1/b===1/c:b!==b&&c!==c};J.object.forEach=function(b,c,d){for(var e in b)c.call(d,b[e],e,b)};J.object.filter=function(b,c,d){var e={},f;for(f in b)c.call(d,b[f],f,b)&&(e[f]=b[f]);return e};J.object.map=function(b,c,d){var e={},f;for(f in b)e[f]=c.call(d,b[f],f,b);return e};J.object.some=function(b,c,d){for(var e in b)if(c.call(d,b[e],e,b))return!0;return!1};J.object.every=function(b,c,d){for(var e in b)if(!c.call(d,b[e],e,b))return!1;return!0};
J.object.er=function(b){var c=0,d;for(d in b)c++;return c};J.object.cr=function(b){for(var c in b)return c};J.object.dr=function(b){for(var c in b)return b[c]};J.object.contains=function(b,c){return J.object.Zi(b,c)};J.object.ur=function(b){var c=[],d=0,e;for(e in b)c[d++]=b[e];return c};J.object.Mf=function(b){var c=[],d=0,e;for(e in b)c[d++]=e;return c};J.object.tr=function(b,c){var d=J.Nb(c),e=d?c:arguments;for(d=d?0:1;d<e.length;d++){if(null==b)return;b=b[e[d]]}return b};
J.object.Yi=function(b,c){return null!==b&&c in b};J.object.Zi=function(b,c){for(var d in b)if(b[d]==c)return!0;return!1};J.object.uj=function(b,c,d){for(var e in b)if(c.call(d,b[e],e,b))return e};J.object.Lq=function(b,c,d){return(c=J.object.uj(b,c,d))&&b[c]};J.object.Qb=function(b){for(var c in b)return!1;return!0};J.object.clear=function(b){for(var c in b)delete b[c]};J.object.remove=function(b,c){var d;(d=c in b)&&delete b[c];return d};
J.object.add=function(b,c,d){if(null!==b&&c in b)throw Error('The object already contains the key "'+c+'"');J.object.set(b,c,d)};J.object.get=function(b,c,d){return null!==b&&c in b?b[c]:d};J.object.set=function(b,c,d){b[c]=d};J.object.xt=function(b,c,d){return c in b?b[c]:b[c]=d};J.object.Mt=function(b,c,d){if(c in b)return b[c];d=d();return b[c]=d};J.object.Ib=function(b,c){for(var d in b)if(!(d in c)||b[d]!==c[d])return!1;for(d in c)if(!(d in b))return!1;return!0};
J.object.clone=function(b){var c={},d;for(d in b)c[d]=b[d];return c};J.object.Bl=function(b){var c=J.ca(b);if(c==w||c==n){if(J.Ba(b.clone))return b.clone();c=c==n?[]:{};for(var d in b)c[d]=J.object.Bl(b[d]);return c}return b};J.object.eu=function(b){var c={},d;for(d in b)c[b[d]]=d;return c};J.object.Ke=["constructor",u,"isPrototypeOf",y,B,"toString","valueOf"];
J.object.extend=function(b,c){for(var d,e,f=1;f<arguments.length;f++){e=arguments[f];for(d in e)b[d]=e[d];for(var g=0;g<J.object.Ke.length;g++)d=J.object.Ke[g],Object.prototype.hasOwnProperty.call(e,d)&&(b[d]=e[d])}};J.object.create=function(b){var c=arguments.length;if(1==c&&J.isArray(arguments[0]))return J.object.create.apply(null,arguments[0]);if(c%2)throw Error("Uneven number of arguments");for(var d={},e=0;e<c;e+=2)d[arguments[e]]=arguments[e+1];return d};
J.object.bj=function(b){var c=arguments.length;if(1==c&&J.isArray(arguments[0]))return J.object.bj.apply(null,arguments[0]);for(var d={},e=0;e<c;e++)d[arguments[e]]=!0;return d};J.object.lq=function(b){var c=b;Object.isFrozen&&!Object.isFrozen(b)&&(c=Object.create(b),Object.freeze(c));return c};J.object.Tr=function(b){return!!Object.isFrozen&&Object.isFrozen(b)};
J.object.ar=function(b,c,d){if(!b)return[];if(!Object.getOwnPropertyNames||!Object.getPrototypeOf)return J.object.Mf(b);for(var e={};b&&(b!==Object.prototype||c)&&(b!==Function.prototype||d);){for(var f=Object.getOwnPropertyNames(b),g=0;g<f.length;g++)e[f[g]]=!0;b=Object.getPrototypeOf(b)}return J.object.Mf(e)};J.g.userAgent.w={};J.g.userAgent.w.Hg=function(){return J.g.userAgent.A.L("Opera")};J.g.userAgent.w.Hk=function(){return J.g.userAgent.A.L("Trident")||J.g.userAgent.A.L("MSIE")};J.g.userAgent.w.Od=function(){return J.g.userAgent.A.L("Edge")};J.g.userAgent.w.Pd=function(){return J.g.userAgent.A.L("Firefox")||J.g.userAgent.A.L("FxiOS")};
J.g.userAgent.w.Ig=function(){return J.g.userAgent.A.L("Safari")&&!(J.g.userAgent.w.Md()||J.g.userAgent.w.Nd()||J.g.userAgent.w.Hg()||J.g.userAgent.w.Od()||J.g.userAgent.w.Pd()||J.g.userAgent.w.Ag()||J.g.userAgent.A.L("Android"))};J.g.userAgent.w.Nd=function(){return J.g.userAgent.A.L("Coast")};J.g.userAgent.w.Ik=function(){return(J.g.userAgent.A.L("iPad")||J.g.userAgent.A.L("iPhone"))&&!J.g.userAgent.w.Ig()&&!J.g.userAgent.w.Md()&&!J.g.userAgent.w.Nd()&&!J.g.userAgent.w.Pd()&&J.g.userAgent.A.L("AppleWebKit")};
J.g.userAgent.w.Md=function(){return(J.g.userAgent.A.L("Chrome")||J.g.userAgent.A.L("CriOS"))&&!J.g.userAgent.w.Od()};J.g.userAgent.w.Gk=function(){return J.g.userAgent.A.L("Android")&&!(J.g.userAgent.w.og()||J.g.userAgent.w.ak()||J.g.userAgent.w.Kd()||J.g.userAgent.w.Ag())};J.g.userAgent.w.Kd=J.g.userAgent.w.Hg;J.g.userAgent.w.rc=J.g.userAgent.w.Hk;J.g.userAgent.w.Ra=J.g.userAgent.w.Od;J.g.userAgent.w.ak=J.g.userAgent.w.Pd;J.g.userAgent.w.hs=J.g.userAgent.w.Ig;J.g.userAgent.w.Nr=J.g.userAgent.w.Nd;
J.g.userAgent.w.Vr=J.g.userAgent.w.Ik;J.g.userAgent.w.og=J.g.userAgent.w.Md;J.g.userAgent.w.Kr=J.g.userAgent.w.Gk;J.g.userAgent.w.Ag=function(){return J.g.userAgent.A.L("Silk")};
J.g.userAgent.w.Lb=function(){function b(b){b=J.j.find(b,e);return d[b]||""}var c=J.g.userAgent.A.pb();if(J.g.userAgent.w.rc())return J.g.userAgent.w.Ej(c);c=J.g.userAgent.A.sf(c);var d={};J.j.forEach(c,function(b){d[b[0]]=b[1]});var e=J.eb(J.object.Yi,d);return J.g.userAgent.w.Kd()?b(["Version","Opera"]):J.g.userAgent.w.Ra()?b(["Edge"]):J.g.userAgent.w.og()?b(["Chrome","CriOS"]):(c=c[2])&&c[1]||""};J.g.userAgent.w.xa=function(b){return 0<=J.f.Db(J.g.userAgent.w.Lb(),b)};
J.g.userAgent.w.Ej=function(b){var c=/rv: *([\d\.]*)/.exec(b);if(c&&c[1])return c[1];c="";var d=/MSIE +([\d\.]+)/.exec(b);if(d&&d[1])if(b=/Trident\/(\d.\d)/.exec(b),"7.0"==d[1])if(b&&b[1])switch(b[1]){case "4.0":c="8.0";break;case "5.0":c="9.0";break;case "6.0":c="10.0";break;case "7.0":c="11.0"}else c="7.0";else c=d[1];return c};J.g.userAgent.V={};J.g.userAgent.V.jk=function(){return J.g.userAgent.A.L("Presto")};J.g.userAgent.V.mk=function(){return J.g.userAgent.A.L("Trident")||J.g.userAgent.A.L("MSIE")};J.g.userAgent.V.Ra=function(){return J.g.userAgent.A.L("Edge")};J.g.userAgent.V.Cg=function(){return J.g.userAgent.A.Jg("WebKit")&&!J.g.userAgent.V.Ra()};J.g.userAgent.V.bk=function(){return J.g.userAgent.A.L("Gecko")&&!J.g.userAgent.V.Cg()&&!J.g.userAgent.V.mk()&&!J.g.userAgent.V.Ra()};
J.g.userAgent.V.Lb=function(){var b=J.g.userAgent.A.pb();if(b){b=J.g.userAgent.A.sf(b);var c=J.g.userAgent.V.Cj(b);if(c)return"Gecko"==c[0]?J.g.userAgent.V.Nj(b):c[1];b=b[0];var d;if(b&&(d=b[2])&&(d=/Trident\/([^\s;]+)/.exec(d)))return d[1]}return""};J.g.userAgent.V.Cj=function(b){if(!J.g.userAgent.V.Ra())return b[1];for(var c=0;c<b.length;c++){var d=b[c];if("Edge"==d[0])return d}};J.g.userAgent.V.xa=function(b){return 0<=J.f.Db(J.g.userAgent.V.Lb(),b)};
J.g.userAgent.V.Nj=function(b){return(b=J.j.find(b,function(b){return"Firefox"==b[0]}))&&b[1]||""};J.async.gh=function(b){J.global.setTimeout(function(){throw b;},0)};J.async.qa=function(b,c,d){var e=b;c&&(e=J.bind(b,c));e=J.async.qa.ph(e);J.Ba(J.global.setImmediate)&&(d||J.async.qa.Fl())?J.global.setImmediate(e):(J.async.qa.Yg||(J.async.qa.Yg=J.async.qa.Jj()),J.async.qa.Yg(e))};J.async.qa.Fl=function(){return J.global.Window&&J.global.Window.prototype&&!J.g.userAgent.w.Ra()&&J.global.Window.prototype.setImmediate==J.global.setImmediate?!1:!0};
J.async.qa.Jj=function(){var b=J.global.MessageChannel;"undefined"===typeof b&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!J.g.userAgent.V.jk()&&(b=function(){var b=document.createElement("IFRAME");b.style.display="none";b.src="";document.documentElement.appendChild(b);var c=b.contentWindow;b=c.document;b.open();b.write("");b.close();var d="callImmediate"+Math.random(),e="file:"==c.location.protocol?"*":c.location.protocol+"//"+c.location.host;b=J.bind(function(b){if(("*"==
e||b.origin==e)&&b.data==d)this.port1.onmessage()},this);c.addEventListener("message",b,!1);this.port1={};this.port2={postMessage:function(){c.postMessage(d,e)}}});if("undefined"!==typeof b&&!J.g.userAgent.w.rc()){var c=new b,d={},e=d;c.port1.onmessage=function(){if(J.W(d.next)){d=d.next;var b=d.cf;d.cf=null;b()}};return function(b){e.next={cf:b};e=e.next;c.port2.postMessage(0)}}return"undefined"!==typeof document&&"onreadystatechange"in document.createElement(k)?function(b){var c=document.createElement(k);
c.onreadystatechange=function(){c.onreadystatechange=null;c.parentNode.removeChild(c);c=null;b();b=null};document.documentElement.appendChild(c)}:function(b){J.global.setTimeout(b,0)}};J.async.qa.ph=J.M.Wj;J.debug.aa.register(function(b){J.async.qa.ph=b});J.async.Ga=function(){this.Lc=this.yb=null};J.async.Ga.Qc=100;J.async.Ga.Kb=new J.async.Xb(function(){return new J.async.Yc},function(b){b.reset()},J.async.Ga.Qc);J.async.Ga.prototype.add=function(b,c){var d=J.async.Ga.Kb.get();d.set(b,c);this.Lc?this.Lc.next=d:this.yb=d;this.Lc=d};J.async.Ga.prototype.remove=function(){var b=null;this.yb&&(b=this.yb,this.yb=this.yb.next,this.yb||(this.Lc=null),b.next=null);return b};J.async.Yc=function(){this.next=this.scope=this.nd=null};
J.async.Yc.prototype.set=function(b,c){this.nd=b;this.scope=c;this.next=null};J.async.Yc.prototype.reset=function(){this.next=this.scope=this.nd=null};J.xh=!1;J.async.P=function(b,c){J.async.P.Ec||J.async.P.Xj();J.async.P.Kc||(J.async.P.Ec(),J.async.P.Kc=!0);J.async.P.ee.add(b,c)};J.async.P.Xj=function(){if(J.xh||J.global.Promise&&J.global.Promise.resolve){var b=J.global.Promise.resolve(void 0);J.async.P.Ec=function(){b.then(J.async.P.Ac)}}else J.async.P.Ec=function(){J.async.qa(J.async.P.Ac)}};J.async.P.Nq=function(b){J.async.P.Ec=function(){J.async.qa(J.async.P.Ac);b&&b(J.async.P.Ac)}};J.async.P.Kc=!1;J.async.P.ee=new J.async.Ga;
J.Z&&(J.async.P.bt=function(){J.async.P.Kc=!1;J.async.P.ee=new J.async.Ga});J.async.P.Ac=function(){for(var b;b=J.async.P.ee.remove();){try{b.nd.call(b.scope)}catch(c){J.async.gh(c)}J.async.Ga.Kb.put(b)}J.async.P.Kc=!1};J.a.o={};J.a.o.Fp=D();J.a.o.Zc=C();J.a.o.vp=D();J.a.o.Ei=function(b){return J.a.o.Zc(b)};J.a.o.Bp=D();J.a.o.Ap=D();J.a.o.wp=D();J.a.o.Ep=D();J.a.o.Gi=function(b){return J.a.o.Zc(b)};J.a.o.xp=D();J.a.o.Fi=function(b){return J.a.o.Zc(b)};J.a.o.yp=D();J.a.o.zp=D();J.a.o.Cp=D();J.a.o.Dp=D();J.a.o.vq=function(b){return J.ka(b)?b.constructor.displayName||b.constructor.name||Object.prototype.toString.call(b):void 0===b?"undefined":null===b?"null":typeof b};
J.a.o.nc=function(b){return(b=b&&b.ownerDocument)&&(b.defaultView||b.parentWindow)||J.global};J.g.userAgent.platform={};J.g.userAgent.platform.ng=function(){return J.g.userAgent.A.L("Android")};J.g.userAgent.platform.xg=function(){return J.g.userAgent.A.L("iPod")};J.g.userAgent.platform.wg=function(){return J.g.userAgent.A.L("iPhone")&&!J.g.userAgent.A.L("iPod")&&!J.g.userAgent.A.L("iPad")};J.g.userAgent.platform.vg=function(){return J.g.userAgent.A.L("iPad")};J.g.userAgent.platform.ug=function(){return J.g.userAgent.platform.wg()||J.g.userAgent.platform.vg()||J.g.userAgent.platform.xg()};
J.g.userAgent.platform.yg=function(){return J.g.userAgent.A.L("Macintosh")};J.g.userAgent.platform.gk=function(){return J.g.userAgent.A.L("Linux")};J.g.userAgent.platform.Eg=function(){return J.g.userAgent.A.L("Windows")};J.g.userAgent.platform.pg=function(){return J.g.userAgent.A.L("CrOS")};J.g.userAgent.platform.Mr=function(){return J.g.userAgent.A.L("CrKey")};J.g.userAgent.platform.ek=function(){return J.g.userAgent.A.Jg("KaiOS")};
J.g.userAgent.platform.Lb=function(){var b=J.g.userAgent.A.pb(),c="";J.g.userAgent.platform.Eg()?(c=/Windows (?:NT|Phone) ([0-9.]+)/,c=(b=c.exec(b))?b[1]:"0.0"):J.g.userAgent.platform.ug()?(c=/(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/,c=(b=c.exec(b))&&b[1].replace(/_/g,".")):J.g.userAgent.platform.yg()?(c=/Mac OS X ([0-9_.]+)/,c=(b=c.exec(b))?b[1].replace(/_/g,"."):"10"):J.g.userAgent.platform.ng()?(c=/Android\s+([^\);]+)(\)|;)/,c=(b=c.exec(b))&&b[1]):J.g.userAgent.platform.pg()&&(c=/(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/,
c=(b=c.exec(b))&&b[1]);return c||""};J.g.userAgent.platform.xa=function(b){return 0<=J.f.Db(J.g.userAgent.platform.Lb(),b)};J.Ia={};J.Ia.object=function(b,c){return c};J.Ia.Yd=function(b){J.Ia.Yd[" "](b);return b};J.Ia.Yd[" "]=J.cb;J.Ia.Sp=function(b,c){try{return J.Ia.Yd(b[c]),!0}catch(d){}return!1};J.Ia.cache=function(b,c,d,e){e=e?e(c):c;return Object.prototype.hasOwnProperty.call(b,e)?b[e]:b[e]=d(c)};J.userAgent={};J.userAgent.je=!1;J.userAgent.he=!1;J.userAgent.ie=!1;J.userAgent.oe=!1;J.userAgent.Pc=!1;J.userAgent.me=!1;J.userAgent.uh=!1;J.userAgent.zb=J.userAgent.je||J.userAgent.he||J.userAgent.ie||J.userAgent.Pc||J.userAgent.oe||J.userAgent.me;J.userAgent.Mj=function(){return J.g.userAgent.A.pb()};J.userAgent.zd=function(){return J.global.navigator||null};J.userAgent.nr=function(){return J.userAgent.zd()};J.userAgent.Ie=J.userAgent.zb?J.userAgent.me:J.g.userAgent.w.Kd();
J.userAgent.$=J.userAgent.zb?J.userAgent.je:J.g.userAgent.w.rc();J.userAgent.ve=J.userAgent.zb?J.userAgent.he:J.g.userAgent.V.Ra();J.userAgent.Mm=J.userAgent.ve||J.userAgent.$;J.userAgent.Tc=J.userAgent.zb?J.userAgent.ie:J.g.userAgent.V.bk();J.userAgent.Bb=J.userAgent.zb?J.userAgent.oe||J.userAgent.Pc:J.g.userAgent.V.Cg();J.userAgent.ik=function(){return J.userAgent.Bb&&J.g.userAgent.A.L("Mobile")};J.userAgent.Vn=J.userAgent.Pc||J.userAgent.ik();J.userAgent.uo=J.userAgent.Bb;
J.userAgent.ij=function(){var b=J.userAgent.zd();return b&&b.platform||""};J.userAgent.ko=J.userAgent.ij();J.userAgent.le=!1;J.userAgent.pe=!1;J.userAgent.ke=!1;J.userAgent.qe=!1;J.userAgent.ge=!1;J.userAgent.Nc=!1;J.userAgent.Mc=!1;J.userAgent.Oc=!1;J.userAgent.wh=!1;J.userAgent.za=J.userAgent.le||J.userAgent.pe||J.userAgent.ke||J.userAgent.qe||J.userAgent.ge||J.userAgent.Nc||J.userAgent.Mc||J.userAgent.Oc;J.userAgent.Mn=J.userAgent.za?J.userAgent.le:J.g.userAgent.platform.yg();
J.userAgent.gp=J.userAgent.za?J.userAgent.pe:J.g.userAgent.platform.Eg();J.userAgent.fk=function(){return J.g.userAgent.platform.gk()||J.g.userAgent.platform.pg()};J.userAgent.Kn=J.userAgent.za?J.userAgent.ke:J.userAgent.fk();J.userAgent.rk=function(){var b=J.userAgent.zd();return!!b&&J.f.contains(b.appVersion||"","X11")};J.userAgent.hp=J.userAgent.za?J.userAgent.qe:J.userAgent.rk();J.userAgent.Ul=J.userAgent.za?J.userAgent.ge:J.g.userAgent.platform.ng();
J.userAgent.yn=J.userAgent.za?J.userAgent.Nc:J.g.userAgent.platform.wg();J.userAgent.xn=J.userAgent.za?J.userAgent.Mc:J.g.userAgent.platform.vg();J.userAgent.zn=J.userAgent.za?J.userAgent.Oc:J.g.userAgent.platform.xg();J.userAgent.wn=J.userAgent.za?J.userAgent.Nc||J.userAgent.Mc||J.userAgent.Oc:J.g.userAgent.platform.ug();J.userAgent.Cn=J.userAgent.za?J.userAgent.wh:J.g.userAgent.platform.ek();
J.userAgent.jj=function(){var b="",c=J.userAgent.Oj();c&&(b=c?c[1]:"");return J.userAgent.$&&(c=J.userAgent.Ff(),null!=c&&c>parseFloat(b))?String(c):b};J.userAgent.Oj=function(){var b=J.userAgent.Mj();if(J.userAgent.Tc)return/rv:([^\);]+)(\)|;)/.exec(b);if(J.userAgent.ve)return/Edge\/([\d\.]+)/.exec(b);if(J.userAgent.$)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(b);if(J.userAgent.Bb)return/WebKit\/(\S+)/.exec(b);if(J.userAgent.Ie)return/(?:Version)[ \/]?(\S+)/.exec(b)};
J.userAgent.Ff=function(){var b=J.global.document;return b?b.documentMode:void 0};J.userAgent.VERSION=J.userAgent.jj();J.userAgent.compare=function(b,c){return J.f.Db(b,c)};J.userAgent.pk={};J.userAgent.xa=function(b){return J.userAgent.uh||J.Ia.cache(J.userAgent.pk,b,function(){return 0<=J.f.Db(J.userAgent.VERSION,b)})};J.userAgent.ns=J.userAgent.xa;J.userAgent.Pb=function(b){return Number(J.userAgent.Oh)>=b};J.userAgent.Pr=J.userAgent.Pb;var K;var L=J.global.document,aa=J.userAgent.Ff();
K=L&&J.userAgent.$?aa||("CSS1Compat"==L.compatMode?parseInt(J.userAgent.VERSION,10):5):void 0;J.userAgent.Oh=K;J.a.gb={Ch:!J.userAgent.$||J.userAgent.Pb(9),Dh:!J.userAgent.Tc&&!J.userAgent.$||J.userAgent.$&&J.userAgent.Pb(9)||J.userAgent.Tc&&J.userAgent.xa("1.9.1"),se:J.userAgent.$&&!J.userAgent.xa("9"),Eh:J.userAgent.$||J.userAgent.Ie||J.userAgent.Bb,Uh:J.userAgent.$,Gn:J.userAgent.$&&!J.userAgent.Pb(9)};J.a.tags={};J.a.tags.yi={area:!0,base:!0,br:!0,col:!0,command:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0};J.a.tags.qk=function(b){return!0===J.a.tags.yi[b]};J.f.$o=D();J.f.H=function(b,c){this.be=b===J.f.H.Ae&&c||"";this.ni=J.f.H.Pe};J.f.H.prototype.wa=!0;J.f.H.prototype.ja=E("be");J.f.H.prototype.toString=function(){return"Const{"+this.be+"}"};J.f.H.s=function(b){if(b instanceof J.f.H&&b.constructor===J.f.H&&b.ni===J.f.H.Pe)return b.be;J.o.ha("expected object of type Const, got '"+b+"'");return"type_error:Const"};J.f.H.from=function(b){return new J.f.H(J.f.H.Ae,b)};J.f.H.Pe={};J.f.H.Ae={};J.f.H.EMPTY=J.f.H.from("");J.b={};J.b.O=function(){this.wc="";this.di=J.b.O.da};J.b.O.prototype.wa=!0;J.b.O.da={};J.b.O.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.O.EMPTY:J.b.O.Eb(b)};J.b.O.Rq=function(b,c){for(var d=[],e=1;e<arguments.length;e++)d.push(J.b.O.dh(arguments[e]));return J.b.O.Eb("("+J.f.H.s(b)+")("+d.join(", ")+");")};J.b.O.Vq=function(b){return J.b.O.Eb(J.b.O.dh(b))};J.b.O.prototype.ja=E("wc");J.Z&&(J.b.O.prototype.toString=function(){return"SafeScript{"+this.wc+"}"});
J.b.O.s=function(b){if(b instanceof J.b.O&&b.constructor===J.b.O&&b.di===J.b.O.da)return b.wc;J.o.ha("expected object of type SafeScript, got '"+b+a+J.ca(b));return"type_error:SafeScript"};J.b.O.dh=function(b){return JSON.stringify(b).replace(/</g,"\\x3c")};J.b.O.Eb=function(b){return(new J.b.O).ab(b)};J.b.O.prototype.ab=function(b){this.wc=b;return this};J.b.O.EMPTY=J.b.O.Eb("");J.ua={};J.ua.url={};J.ua.url.$i=function(b){return J.ua.url.cg().createObjectURL(b)};J.ua.url.ct=function(b){J.ua.url.cg().revokeObjectURL(b)};J.ua.url.cg=function(){var b=J.ua.url.wf();if(null!=b)return b;throw Error("This browser doesn't seem to support blob URLs");};J.ua.url.wf=function(){return J.W(J.global.URL)&&J.W(J.global.URL.createObjectURL)?J.global.URL:J.W(J.global.webkitURL)&&J.W(J.global.webkitURL.createObjectURL)?J.global.webkitURL:J.W(J.global.createObjectURL)?J.global:null};
J.ua.url.Pp=function(){return null!=J.ua.url.wf()};J.h={};J.h.i={};J.h.i.Rh=!1;
J.h.i.De=J.h.i.Rh||("ar"==J.I.substring(0,2).toLowerCase()||"fa"==J.I.substring(0,2).toLowerCase()||"he"==J.I.substring(0,2).toLowerCase()||"iw"==J.I.substring(0,2).toLowerCase()||"ps"==J.I.substring(0,2).toLowerCase()||"sd"==J.I.substring(0,2).toLowerCase()||"ug"==J.I.substring(0,2).toLowerCase()||"ur"==J.I.substring(0,2).toLowerCase()||"yi"==J.I.substring(0,2).toLowerCase())&&(2==J.I.length||"-"==J.I.substring(2,3)||"_"==J.I.substring(2,3))||3<=J.I.length&&"ckb"==J.I.substring(0,3).toLowerCase()&&
(3==J.I.length||"-"==J.I.substring(3,4)||"_"==J.I.substring(3,4))||7<=J.I.length&&("-"==J.I.substring(2,3)||"_"==J.I.substring(2,3))&&("adlm"==J.I.substring(3,7).toLowerCase()||"arab"==J.I.substring(3,7).toLowerCase()||"hebr"==J.I.substring(3,7).toLowerCase()||"nkoo"==J.I.substring(3,7).toLowerCase()||"rohg"==J.I.substring(3,7).toLowerCase()||"thaa"==J.I.substring(3,7).toLowerCase())||8<=J.I.length&&("-"==J.I.substring(3,4)||"_"==J.I.substring(3,4))&&("adlm"==J.I.substring(4,8).toLowerCase()||"arab"==
J.I.substring(4,8).toLowerCase()||"hebr"==J.I.substring(4,8).toLowerCase()||"nkoo"==J.I.substring(4,8).toLowerCase()||"rohg"==J.I.substring(4,8).toLowerCase()||"thaa"==J.I.substring(4,8).toLowerCase());J.h.i.kb={Wh:"\u202a",$h:"\u202b",Je:"\u202c",Xh:"\u200e",ai:"\u200f"};J.h.i.S={Ta:1,Ua:-1,sa:0};J.h.i.$b="right";J.h.i.Yb="left";J.h.i.rn=J.h.i.De?J.h.i.Yb:J.h.i.$b;J.h.i.qn=J.h.i.De?J.h.i.$b:J.h.i.Yb;
J.h.i.ul=function(b){return typeof b==v?0<b?J.h.i.S.Ta:0>b?J.h.i.S.Ua:J.h.i.S.sa:null==b?null:b?J.h.i.S.Ua:J.h.i.S.Ta};J.h.i.sb="A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff";J.h.i.xb="\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc";J.h.i.Uj=/<[^>]*>|&[^;]+;/g;J.h.i.Sa=function(b,c){return c?b.replace(J.h.i.Uj,""):b};
J.h.i.Uk=new RegExp("["+J.h.i.xb+"]");J.h.i.Ak=new RegExp("["+J.h.i.sb+"]");J.h.i.Bd=function(b,c){return J.h.i.Uk.test(J.h.i.Sa(b,c))};J.h.i.yr=J.h.i.Bd;J.h.i.fg=function(b){return J.h.i.Ak.test(J.h.i.Sa(b,void 0))};J.h.i.Dk=new RegExp("^["+J.h.i.sb+"]");J.h.i.Zk=new RegExp("^["+J.h.i.xb+"]");J.h.i.kk=function(b){return J.h.i.Zk.test(b)};J.h.i.hk=function(b){return J.h.i.Dk.test(b)};J.h.i.$r=function(b){return!J.h.i.hk(b)&&!J.h.i.kk(b)};J.h.i.Bk=new RegExp("^[^"+J.h.i.xb+"]*["+J.h.i.sb+"]");
J.h.i.Wk=new RegExp("^[^"+J.h.i.sb+"]*["+J.h.i.xb+"]");J.h.i.ah=function(b,c){return J.h.i.Wk.test(J.h.i.Sa(b,c))};J.h.i.gs=J.h.i.ah;J.h.i.nl=function(b,c){return J.h.i.Bk.test(J.h.i.Sa(b,c))};J.h.i.Yr=J.h.i.nl;J.h.i.zg=/^http:\/\/.*/;J.h.i.bs=function(b,c){b=J.h.i.Sa(b,c);return J.h.i.zg.test(b)||!J.h.i.fg(b)&&!J.h.i.Bd(b)};J.h.i.Ck=new RegExp("["+J.h.i.sb+"][^"+J.h.i.xb+"]*$");J.h.i.Xk=new RegExp("["+J.h.i.xb+"][^"+J.h.i.sb+"]*$");J.h.i.mj=function(b,c){return J.h.i.Ck.test(J.h.i.Sa(b,c))};
J.h.i.Xr=J.h.i.mj;J.h.i.nj=function(b,c){return J.h.i.Xk.test(J.h.i.Sa(b,c))};J.h.i.es=J.h.i.nj;J.h.i.Yk=/^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;J.h.i.fs=function(b){return J.h.i.Yk.test(b)};J.h.i.Pi=/(\(.*?\)+)|(\[.*?\]+)|(\{.*?\}+)|(<.*?>+)/g;J.h.i.xr=function(b,c){c=(void 0===c?J.h.i.Bd(b):c)?J.h.i.kb.ai:J.h.i.kb.Xh;return b.replace(J.h.i.Pi,c+"$&"+c)};
J.h.i.Eq=function(b){return"<"==b.charAt(0)?b.replace(/<\w+/,"$& dir=rtl"):"\n<span dir=rtl>"+b+"</span>"};J.h.i.Fq=function(b){return J.h.i.kb.$h+b+J.h.i.kb.Je};J.h.i.Cq=function(b){return"<"==b.charAt(0)?b.replace(/<\w+/,"$& dir=ltr"):"\n<span dir=ltr>"+b+"</span>"};J.h.i.Dq=function(b){return J.h.i.kb.Wh+b+J.h.i.kb.Je};J.h.i.kj=/:\s*([.\d][.\w]*)\s+([.\d][.\w]*)\s+([.\d][.\w]*)\s+([.\d][.\w]*)/g;J.h.i.sk=/left/gi;J.h.i.Tk=/right/gi;J.h.i.sl=/%%%%/g;
J.h.i.xs=function(b){return b.replace(J.h.i.kj,":$1 $4 $3 $2").replace(J.h.i.sk,"%%%%").replace(J.h.i.Tk,J.h.i.Yb).replace(J.h.i.sl,J.h.i.$b)};J.h.i.lj=/([\u0591-\u05f2])"/g;J.h.i.ll=/([\u0591-\u05f2])'/g;J.h.i.Cs=function(b){return b.replace(J.h.i.lj,"$1\u05f4").replace(J.h.i.ll,"$1\u05f3")};J.h.i.Kl=/\s+/;J.h.i.Tj=/[\d\u06f0-\u06f9]/;J.h.i.Vk=.4;
J.h.i.qf=function(b,c){var d=0,e=0,f=!1;b=J.h.i.Sa(b,c).split(J.h.i.Kl);for(c=0;c<b.length;c++){var g=b[c];J.h.i.ah(g)?(d++,e++):J.h.i.zg.test(g)?f=!0:J.h.i.fg(g)?e++:J.h.i.Tj.test(g)&&(f=!0)}return 0==e?f?J.h.i.S.Ta:J.h.i.S.sa:d/e>J.h.i.Vk?J.h.i.S.Ua:J.h.i.S.Ta};J.h.i.xq=function(b,c){return J.h.i.qf(b,c)==J.h.i.S.Ua};J.h.i.rt=function(b,c){b&&(c=J.h.i.ul(c))&&(b.style.textAlign=c==J.h.i.S.Ua?J.h.i.$b:J.h.i.Yb,b.dir=c==J.h.i.S.Ua?"rtl":"ltr")};
J.h.i.st=function(b,c){switch(J.h.i.qf(c)){case J.h.i.S.Ta:b.dir="ltr";break;case J.h.i.S.Ua:b.dir="rtl";break;default:b.removeAttribute("dir")}};J.h.i.Lm=D();J.b.C=function(){this.zc="";this.pi=J.b.C.da};J.b.C.prototype.wa=!0;J.b.C.prototype.ja=E("zc");J.b.C.prototype.Dd=!0;J.b.C.prototype.Za=function(){return J.h.i.S.Ta};J.Z&&(J.b.C.prototype.toString=function(){return"TrustedResourceUrl{"+this.zc+"}"});J.b.C.s=function(b){if(b instanceof J.b.C&&b.constructor===J.b.C&&b.pi===J.b.C.da)return b.zc;J.o.ha("expected object of type TrustedResourceUrl, got '"+b+a+J.ca(b));return"type_error:TrustedResourceUrl"};
J.b.C.format=function(b,c){var d=J.f.H.s(b);if(!J.b.C.zh.test(d))throw Error("Invalid TrustedResourceUrl format: "+d);b=d.replace(J.b.C.Sh,function(b,f){if(!Object.prototype.hasOwnProperty.call(c,f))throw Error('Found marker, "'+f+'", in format string, "'+d+'", but no valid label mapping found in args: '+JSON.stringify(c));b=c[f];return b instanceof J.f.H?J.f.H.s(b):encodeURIComponent(String(b))});return J.b.C.Hb(b)};J.b.C.Sh=/%{(\w+)}/g;J.b.C.zh=/^((https:)?\/\/[0-9a-z.:[\]-]+\/|\/[^/\\]|[^:/\\]+\/|[^:/\\]*[?#]|about:blank#)/i;
J.b.C.ti=/^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;J.b.C.Oq=function(b,c,d,e){b=J.b.C.format(b,c);b=J.b.C.s(b);b=J.b.C.ti.exec(b);c=b[3]||"";return J.b.C.Hb(b[1]+J.b.C.bh("?",b[2]||"",d)+J.b.C.bh("#",c,e))};J.b.C.jc=function(b){return J.b.C.Hb(J.f.H.s(b))};J.b.C.Sq=function(b){for(var c="",d=0;d<b.length;d++)c+=J.f.H.s(b[d]);return J.b.C.Hb(c)};J.b.C.da={};J.b.C.Hb=function(b){var c=new J.b.C;c.zc=b;return c};
J.b.C.bh=function(b,c,d){if(null==d)return c;if(J.N(d))return d?b+encodeURIComponent(d):"";for(var e in d){var f=d[e];f=J.isArray(f)?f:[f];for(var g=0;g<f.length;g++){var h=f[g];null!=h&&(c||(c=b),c+=(c.length>b.length?"&":"")+encodeURIComponent(e)+"="+encodeURIComponent(String(h)))}}return c};J.b.l=function(){this.Ha="";this.gi=J.b.l.da};J.b.l.ga="about:invalid#zClosurez";J.b.l.prototype.wa=!0;J.b.l.prototype.ja=E("Ha");J.b.l.prototype.Dd=!0;J.b.l.prototype.Za=function(){return J.h.i.S.Ta};J.Z&&(J.b.l.prototype.toString=function(){return"SafeUrl{"+this.Ha+"}"});J.b.l.s=function(b){if(b instanceof J.b.l&&b.constructor===J.b.l&&b.gi===J.b.l.da)return b.Ha;J.o.ha("expected object of type SafeUrl, got '"+b+a+J.ca(b));return"type_error:SafeUrl"};J.b.l.jc=function(b){return J.b.l.oa(J.f.H.s(b))};
J.b.Me=/^(?:audio\/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-wav|wav|webm)|image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|text\/csv|video\/(?:mpeg|mp4|ogg|webm|quicktime))$/i;J.b.l.Qq=function(b){b=J.b.Me.test(b.type)?J.ua.url.$i(b):J.b.l.ga;return J.b.l.oa(b)};J.b.Jh=/^data:([^;,]*);base64,[a-z0-9+\/]+=*$/i;J.b.l.Tq=function(b){b=b.replace(/(%0A|%0D)/g,"");var c=b.match(J.b.Jh);c=c&&J.b.Me.test(c[1]);return J.b.l.oa(c?b:J.b.l.ga)};
J.b.l.Zq=function(b){J.f.bd(b,"tel:")||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.ki=/^sip[s]?:[+a-z0-9_.!$%&'*\/=^`{|}~-]+@([a-z0-9-]+\.)+[a-z0-9]{2,63}$/i;J.b.l.Xq=function(b){J.b.ki.test(decodeURIComponent(b))||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.Uq=function(b){J.f.bd(b,"fb-messenger://share")||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.Yq=function(b){J.f.bd(b,"sms:")&&J.b.l.lk(b)||(b=J.b.l.ga);return J.b.l.oa(b)};
J.b.l.lk=function(b){var c=b.indexOf("#");0<c&&(b=b.substring(0,c));c=b.match(/[?&]body=/gi);if(!c)return!0;if(1<c.length)return!1;b=b.match(/[?&]body=([^&]*)/)[1];if(!b)return!0;try{decodeURIComponent(b)}catch(d){return!1}return/^(?:[a-z0-9\-_.~]|%[0-9a-f]{2})+$/i.test(b)};J.b.l.kt=function(b,c){return J.b.l.Ud(/^chrome-extension:\/\/([^\/]+)\//,b,c)};J.b.l.mt=function(b,c){return J.b.l.Ud(/^moz-extension:\/\/([^\/]+)\//,b,c)};
J.b.l.lt=function(b,c){return J.b.l.Ud(/^ms-browser-extension:\/\/([^\/]+)\//,b,c)};J.b.l.Ud=function(b,c,d){(b=b.exec(c))?(b=b[1],-1==(d instanceof J.f.H?[J.f.H.s(d)]:d.map(function(b){return J.f.H.s(b)})).indexOf(b)&&(c=J.b.l.ga)):c=J.b.l.ga;return J.b.l.oa(c)};J.b.l.$q=function(b){return J.b.l.oa(J.b.C.s(b))};J.b.Wc=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;J.b.l.vo=J.b.Wc;
J.b.l.Dc=function(b){if(b instanceof J.b.l)return b;b=typeof b==w&&b.wa?b.ja():String(b);J.b.Wc.test(b)||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.ra=function(b){if(b instanceof J.b.l)return b;b=typeof b==w&&b.wa?b.ja():String(b);J.b.Wc.test(b)||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.da={};J.b.l.oa=function(b){var c=new J.b.l;c.Ha=b;return c};J.b.l.Pl=J.b.l.oa("about:blank");J.b.v=function(){this.yc="";this.fi=J.b.v.da};J.b.v.prototype.wa=!0;J.b.v.da={};J.b.v.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.v.EMPTY:J.b.v.Fb(b)};J.b.v.Yp=D();J.b.v.prototype.ja=E("yc");J.Z&&(J.b.v.prototype.toString=function(){return"SafeStyle{"+this.yc+"}"});J.b.v.s=function(b){if(b instanceof J.b.v&&b.constructor===J.b.v&&b.fi===J.b.v.da)return b.yc;J.o.ha("expected object of type SafeStyle, got '"+b+a+J.ca(b));return"type_error:SafeStyle"};J.b.v.Fb=function(b){return(new J.b.v).ab(b)};
J.b.v.prototype.ab=function(b){this.yc=b;return this};J.b.v.EMPTY=J.b.v.Fb("");J.b.v.ga="zClosurez";J.b.v.create=function(b){var c="",d;for(d in b){if(!/^[-_a-zA-Z0-9]+$/.test(d))throw Error("Name allows only [-_a-zA-Z0-9], got: "+d);var e=b[d];null!=e&&(e=J.isArray(e)?J.j.map(e,J.b.v.Ug).join(" "):J.b.v.Ug(e),c+=d+":"+e+";")}return c?J.b.v.Fb(c):J.b.v.EMPTY};
J.b.v.Ug=function(b){return b instanceof J.b.l?'url("'+J.b.l.s(b).replace(/</g,"%3c").replace(/[\\"]/g,"\\$&")+'")':b instanceof J.f.H?J.f.H.s(b):J.b.v.cl(String(b))};
J.b.v.cl=function(b){var c=b.replace(J.b.v.ze,"$1").replace(J.b.v.ze,"$1").replace(J.b.v.Qe,"url");if(J.b.v.vi.test(c)){if(J.b.v.Hh.test(b))return J.o.ha("String value disallows comments, got: "+b),J.b.v.ga;if(!J.b.v.Qj(b))return J.o.ha("String value requires balanced quotes, got: "+b),J.b.v.ga;if(!J.b.v.Rj(b))return J.o.ha("String value requires balanced square brackets and one identifier per pair of brackets, got: "+b),J.b.v.ga}else return J.o.ha("String value allows only "+J.b.v.Te+" and simple functions, got: "+
b),J.b.v.ga;return J.b.v.dl(b)};J.b.v.Qj=function(b){for(var c=!0,d=!0,e=0;e<b.length;e++){var f=b.charAt(e);"'"==f&&d?c=!c:'"'==f&&c&&(d=!d)}return c&&d};J.b.v.Rj=function(b){for(var c=!0,d=/^[-_a-zA-Z0-9]$/,e=0;e<b.length;e++){var f=b.charAt(e);if("]"==f){if(c)return!1;c=!0}else if("["==f){if(!c)return!1;c=!1}else if(!c&&!d.test(f))return!1}return c};J.b.v.Te="[-,.\"'%_!# a-zA-Z0-9\\[\\]]";J.b.v.vi=new RegExp("^"+J.b.v.Te+"+$");J.b.v.Qe=/\b(url\([ \t\n]*)('[ -&(-\[\]-~]*'|"[ !#-\[\]-~]*"|[!#-&*-\[\]-~]*)([ \t\n]*\))/g;
J.b.v.ze=/\b(hsl|hsla|rgb|rgba|matrix|calc|minmax|fit-content|repeat|(rotate|scale|translate)(X|Y|Z|3d)?)\([-+*/0-9a-z.%\[\], ]+\)/g;J.b.v.Hh=/\/\*/;J.b.v.dl=function(b){return b.replace(J.b.v.Qe,function(b,d,e,f){var c="";e=e.replace(/^(['"])(.*)\1$/,function(b,d,e){c=d;return e});b=J.b.l.Dc(e).ja();return d+c+b+c+f})};J.b.v.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):d+=J.b.v.s(b)}var d="";J.j.forEach(arguments,c);return d?J.b.v.Fb(d):J.b.v.EMPTY};J.b.R=function(){this.xc="";this.ei=J.b.R.da};J.b.R.prototype.wa=!0;J.b.R.da={};
J.b.R.nq=function(b,c){if(J.f.contains(b,"<"))throw Error("Selector does not allow '<', got: "+b);var d=b.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g,"");if(!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=^$|]+$/.test(d))throw Error("Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=^$|] and strings, got: "+b);if(!J.b.R.Pj(d))throw Error("() and [] in selector must be balanced, got: "+b);c instanceof J.b.v||(c=J.b.v.create(c));b=b+"{"+J.b.v.s(c)+"}";return J.b.R.Gb(b)};
J.b.R.Pj=function(b){for(var c={"(":")","[":"]"},d=[],e=0;e<b.length;e++){var f=b[e];if(c[f])d.push(c[f]);else if(J.object.contains(c,f)&&d.pop()!=f)return!1}return 0==d.length};J.b.R.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):d+=J.b.R.s(b)}var d="";J.j.forEach(arguments,c);return J.b.R.Gb(d)};J.b.R.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.R.EMPTY:J.b.R.Gb(b)};J.b.R.prototype.ja=E("xc");J.Z&&(J.b.R.prototype.toString=function(){return"SafeStyleSheet{"+this.xc+"}"});
J.b.R.s=function(b){if(b instanceof J.b.R&&b.constructor===J.b.R&&b.ei===J.b.R.da)return b.xc;J.o.ha("expected object of type SafeStyleSheet, got '"+b+a+J.ca(b));return"type_error:SafeStyleSheet"};J.b.R.Gb=function(b){return(new J.b.R).ab(b)};J.b.R.prototype.ab=function(b){this.xc=b;return this};J.b.R.EMPTY=J.b.R.Gb("");J.b.m=function(){this.Ha="";this.ci=J.b.m.da;this.hc=null};J.b.m.prototype.Dd=!0;J.b.m.prototype.Za=E("hc");J.b.m.prototype.wa=!0;J.b.m.prototype.ja=E("Ha");J.Z&&(J.b.m.prototype.toString=function(){return"SafeHtml{"+this.Ha+"}"});J.b.m.s=function(b){if(b instanceof J.b.m&&b.constructor===J.b.m&&b.ci===J.b.m.da)return b.Ha;J.o.ha("expected object of type SafeHtml, got '"+b+a+J.ca(b));return"type_error:SafeHtml"};
J.b.m.va=function(b){if(b instanceof J.b.m)return b;var c=typeof b==w,d=null;c&&b.Dd&&(d=b.Za());return J.b.m.ta(J.f.va(c&&b.wa?b.ja():String(b)),d)};J.b.m.Br=function(b){if(b instanceof J.b.m)return b;b=J.b.m.va(b);return J.b.m.ta(J.f.Ng(J.b.m.s(b)),b.Za())};J.b.m.Cr=function(b){if(b instanceof J.b.m)return b;b=J.b.m.va(b);return J.b.m.ta(J.f.Jl(J.b.m.s(b)),b.Za())};J.b.m.from=J.b.m.va;J.b.m.Se=/^[a-zA-Z0-9-]+$/;J.b.m.si={action:!0,cite:!0,data:!0,formaction:!0,href:!0,manifest:!0,poster:!0,src:!0};
J.b.m.Zh={APPLET:!0,BASE:!0,EMBED:!0,IFRAME:!0,LINK:!0,MATH:!0,META:!0,OBJECT:!0,SCRIPT:!0,STYLE:!0,SVG:!0,TEMPLATE:!0};J.b.m.create=function(b,c,d){J.b.m.Hl(String(b));return J.b.m.Ya(String(b),c,d)};J.b.m.Hl=function(b){if(!J.b.m.Se.test(b))throw Error("Invalid tag name <"+b+">.");if(b.toUpperCase()in J.b.m.Zh)throw Error("Tag name <"+b+"> is not allowed for SafeHtml.");};
J.b.m.kq=function(b,c,d,e){b&&J.b.C.s(b);var f={};f.src=b||null;f.srcdoc=c&&J.b.m.s(c);b=J.b.m.fc(f,{sandbox:""},d);return J.b.m.Ya("iframe",b,e)};J.b.m.oq=function(b,c,d,e){if(!J.b.m.Si())throw Error("The browser does not support sandboxed iframes.");var f={};f.src=b?J.b.l.s(J.b.l.Dc(b)):null;f.srcdoc=c||null;f.sandbox="";b=J.b.m.fc(f,{},d);return J.b.m.Ya("iframe",b,e)};J.b.m.Si=function(){return J.global.HTMLIFrameElement&&"sandbox"in J.global.HTMLIFrameElement.prototype};
J.b.m.qq=function(b,c){J.b.C.s(b);b=J.b.m.fc({src:b},{},c);return J.b.m.Ya("script",b)};J.b.m.pq=function(b,c){for(var d in c){var e=d.toLowerCase();if("language"==e||"src"==e||"text"==e||"type"==e)throw Error('Cannot set "'+e+'" attribute');}d="";b=J.j.concat(b);for(e=0;e<b.length;e++)d+=J.b.O.s(b[e]);b=J.b.m.ta(d,J.h.i.S.sa);return J.b.m.Ya("script",c,b)};
J.b.m.rq=function(b,c){c=J.b.m.fc({type:"text/css"},{},c);var d="";b=J.j.concat(b);for(var e=0;e<b.length;e++)d+=J.b.R.s(b[e]);b=J.b.m.ta(d,J.h.i.S.sa);return J.b.m.Ya("style",c,b)};J.b.m.mq=function(b,c){b=J.b.l.s(J.b.l.Dc(b));(J.g.userAgent.w.rc()||J.g.userAgent.w.Ra())&&J.f.contains(b,";")&&(b="'"+b.replace(/'/g,"%27")+"'");return J.b.m.Ya("meta",{"http-equiv":"refresh",content:(c||0)+"; url="+b})};
J.b.m.xj=function(b,c,d){if(d instanceof J.f.H)d=J.f.H.s(d);else if("style"==c.toLowerCase())d=J.b.m.Kj(d);else{if(/^on/i.test(c))throw Error('Attribute "'+c+'" requires goog.string.Const value, "'+d+'" given.');if(c.toLowerCase()in J.b.m.si)if(d instanceof J.b.C)d=J.b.C.s(d);else if(d instanceof J.b.l)d=J.b.l.s(d);else if(J.N(d))d=J.b.l.Dc(d).ja();else throw Error('Attribute "'+c+'" on tag "'+b+'" requires goog.html.SafeUrl, goog.string.Const, or string, value "'+d+'" given.');}d.wa&&(d=d.ja());
return c+'="'+J.f.va(String(d))+'"'};J.b.m.Kj=function(b){if(!J.ka(b))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof b+" given: "+b);b instanceof J.b.v||(b=J.b.v.create(b));return J.b.v.s(b)};J.b.m.tq=function(b,c,d,e){c=J.b.m.create(c,d,e);c.hc=b;return c};
J.b.m.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):(b=J.b.m.va(b),e+=J.b.m.s(b),b=b.Za(),d==J.h.i.S.sa?d=b:b!=J.h.i.S.sa&&d!=b&&(d=null))}var d=J.h.i.S.sa,e="";J.j.forEach(arguments,c);return J.b.m.ta(e,d)};J.b.m.gq=function(b,c){var d=J.b.m.concat(J.j.slice(arguments,1));d.hc=b;return d};J.b.m.da={};J.b.m.ta=function(b,c){return(new J.b.m).ab(b,c)};J.b.m.prototype.ab=function(b,c){this.Ha=b;this.hc=c;return this};
J.b.m.Ya=function(b,c,d){var e=null;var f="<"+b+J.b.m.pl(b,c);J.bb(d)?J.isArray(d)||(d=[d]):d=[];J.a.tags.qk(b.toLowerCase())?f+=">":(e=J.b.m.concat(d),f+=">"+J.b.m.s(e)+"</"+b+">",e=e.Za());(b=c&&c.dir)&&(e=/^(ltr|rtl|auto)$/i.test(b)?J.h.i.S.sa:null);return J.b.m.ta(f,e)};J.b.m.pl=function(b,c){var d="";if(c)for(var e in c){if(!J.b.m.Se.test(e))throw Error('Invalid attribute name "'+e+'".');var f=c[e];J.bb(f)&&(d+=" "+J.b.m.xj(b,e,f))}return d};
J.b.m.fc=function(b,c,d){var e={},f;for(f in b)e[f]=b[f];for(f in c)e[f]=c[f];for(f in d){var g=f.toLowerCase();if(g in b)throw Error('Cannot override "'+g+'" attribute, got "'+f+'" with value "'+d[f]+'"');g in c&&delete e[g];e[f]=d[f]}return e};J.b.m.Im=J.b.m.ta("<!DOCTYPE html>",J.h.i.S.sa);J.b.m.EMPTY=J.b.m.ta("",J.h.i.S.sa);J.b.m.re=J.b.m.ta("<br>",J.h.i.S.sa);J.a.J={};J.a.J.Bn={Sl:"afterbegin",Tl:"afterend",hm:"beforebegin",im:"beforeend"};J.a.J.Er=function(b,c,d){b.insertAdjacentHTML(c,J.b.m.s(d))};J.a.J.ji={MATH:!0,SCRIPT:!0,STYLE:!0,SVG:!0,TEMPLATE:!0};J.a.J.dk=J.M.Ri(function(){if(J.Z&&"undefined"===typeof document)return!1;var b=document.createElement("div");b.innerHTML="<div><div></div></div>";if(J.Z&&!b.firstChild)return!1;var c=b.firstChild.firstChild;b.innerHTML="";return!c.parentElement});
J.a.J.Cl=function(b,c){if(J.a.J.dk())for(;b.lastChild;)b.removeChild(b.lastChild);b.innerHTML=c};J.a.J.Zg=function(b,c){if(J.o.ma&&J.a.J.ji[b.tagName.toUpperCase()])throw Error("goog.dom.safe.setInnerHtml cannot be used to set content of "+b.tagName+".");J.a.J.Cl(b,J.b.m.s(c))};J.a.J.Ft=function(b,c){b.outerHTML=J.b.m.s(c)};J.a.J.vt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Fi(b).action=J.b.l.s(c)};J.a.J.pt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Ei(b).formAction=J.b.l.s(c)};
J.a.J.Bt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Gi(b).formAction=J.b.l.s(c)};J.a.J.Ht=function(b,c){b.style.cssText=J.b.v.s(c)};J.a.J.Aq=function(b,c){b.write(J.b.m.s(c))};J.a.J.nt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.href=J.b.l.s(c)};J.a.J.At=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};J.a.J.ot=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};J.a.J.Lt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};
J.a.J.tt=function(b,c){b.src=J.b.C.s(c)};J.a.J.wt=function(b,c){b.src=J.b.C.s(c)};J.a.J.yt=function(b,c){b.src=J.b.C.s(c)};J.a.J.zt=function(b,c){b.srcdoc=J.b.m.s(c)};J.a.J.Ct=function(b,c,d){b.rel=d;J.f.bf(d,"stylesheet")?b.href=J.b.C.s(c):b.href=c instanceof J.b.C?J.b.C.s(c):c instanceof J.b.l?J.b.l.s(c):J.b.l.ra(c).ja()};J.a.J.Et=function(b,c){b.data=J.b.C.s(c)};J.a.J.il=function(b,c){b.src=J.b.C.s(c);(c=J.$f())&&b.setAttribute("nonce",c)};
J.a.J.Gt=function(b,c){b.text=J.b.O.s(c);(c=J.$f())&&b.setAttribute("nonce",c)};J.a.J.Dt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.href=J.b.l.s(c)};J.a.J.Lp=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.assign(J.b.l.s(c))};J.a.J.$s=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.replace(J.b.l.s(c))};J.a.J.Ks=function(b,c,d,e,f){b=b instanceof J.b.l?b:J.b.l.ra(b);return(c||window).open(J.b.l.s(b),d?J.f.H.s(d):"",e,f)};J.b.fb={};J.b.fb.$k=function(b,c){return J.b.m.ta(c,null)};J.b.fb.gt=function(b,c){return J.b.O.Eb(c)};J.b.fb.ht=function(b,c){return J.b.v.Fb(c)};J.b.fb.it=function(b,c){return J.b.R.Gb(c)};J.b.fb.jt=function(b,c){return J.b.l.oa(c)};J.b.fb.gu=function(b,c){return J.b.C.Hb(c)};J.u={};J.u.Ps=function(b){return Math.floor(Math.random()*b)};J.u.iu=function(b,c){return b+Math.random()*(c-b)};J.u.Zp=function(b,c,d){return Math.min(Math.max(b,c),d)};J.u.Lg=function(b,c){b%=c;return 0>b*c?b+c:b};J.u.qs=function(b,c,d){return b+d*(c-b)};J.u.Bs=function(b,c,d){return Math.abs(b-c)<=(d||1E-6)};J.u.ae=function(b){return J.u.Lg(b,360)};J.u.St=function(b){return J.u.Lg(b,2*Math.PI)};J.u.kh=function(b){return b*Math.PI/180};J.u.tl=function(b){return 180*b/Math.PI};
J.u.np=function(b,c){return c*Math.cos(J.u.kh(b))};J.u.op=function(b,c){return c*Math.sin(J.u.kh(b))};J.u.angle=function(b,c,d,e){return J.u.ae(J.u.tl(Math.atan2(e-c,d-b)))};J.u.mp=function(b,c){b=J.u.ae(c)-J.u.ae(b);180<b?b-=360:-180>=b&&(b=360+b);return b};J.u.sign=function(b){return 0<b?1:0>b?-1:b};
J.u.us=function(b,c,d,e){d=d||function(b,c){return b==c};e=e||function(c){return b[c]};for(var f=b.length,g=c.length,h=[],l=0;l<f+1;l++)h[l]=[],h[l][0]=0;for(var m=0;m<g+1;m++)h[0][m]=0;for(l=1;l<=f;l++)for(m=1;m<=g;m++)d(b[l-1],c[m-1])?h[l][m]=h[l-1][m-1]+1:h[l][m]=Math.max(h[l-1][m],h[l][m-1]);var r=[];l=f;for(m=g;0<l&&0<m;)d(b[l-1],c[m-1])?(r.unshift(e(l-1,m-1)),l--,m--):h[l-1][m]>h[l][m-1]?l--:m--;return r};J.u.ce=function(b){return J.j.reduce(arguments,function(b,d){return b+d},0)};
J.u.Ji=function(b){return J.u.ce.apply(null,arguments)/arguments.length};J.u.bl=function(b){var c=arguments.length;if(2>c)return 0;var d=J.u.Ji.apply(null,arguments);return J.u.ce.apply(null,J.j.map(arguments,function(b){return Math.pow(b-d,2)}))/(c-1)};J.u.Tt=function(b){return Math.sqrt(J.u.bl.apply(null,arguments))};J.u.Ur=function(b){return isFinite(b)&&0==b%1};J.u.Sr=function(b){return isFinite(b)};J.u.Zr=function(b){return 0==b&&0>1/b};
J.u.ts=function(b){if(0<b){var c=Math.round(Math.log(b)*Math.LOG10E);return c-(parseFloat("1e"+c)>b?1:0)}return 0==b?-Infinity:NaN};J.u.et=function(b,c){return Math.floor(b+(c||2E-15))};J.u.dt=function(b,c){return Math.ceil(b-(c||2E-15))};J.u.X=function(b,c){this.x=J.W(b)?b:0;this.y=J.W(c)?c:0};J.u.X.prototype.clone=function(){return new J.u.X(this.x,this.y)};J.Z&&(J.u.X.prototype.toString=function(){return"("+this.x+", "+this.y+")"});J.u.X.prototype.Ib=function(b){return b instanceof J.u.X&&J.u.X.Ib(this,b)};J.u.X.Ib=function(b,c){return b==c?!0:b&&c?b.x==c.x&&b.y==c.y:!1};J.u.X.zq=function(b,c){var d=b.x-c.x;b=b.y-c.y;return Math.sqrt(d*d+b*b)};J.u.X.vs=function(b){return Math.sqrt(b.x*b.x+b.y*b.y)};
J.u.X.azimuth=function(b){return J.u.angle(0,0,b.x,b.y)};J.u.X.Qt=function(b,c){var d=b.x-c.x;b=b.y-c.y;return d*d+b*b};J.u.X.yq=function(b,c){return new J.u.X(b.x-c.x,b.y-c.y)};J.u.X.ce=function(b,c){return new J.u.X(b.x+c.x,b.y+c.y)};H=J.u.X.prototype;H.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};H.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};H.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
H.translate=function(b,c){b instanceof J.u.X?(this.x+=b.x,this.y+=b.y):(this.x+=Number(b),J.Rb(c)&&(this.y+=c));return this};H.scale=function(b,c){c=J.Rb(c)?c:b;this.x*=b;this.y*=c;return this};J.u.lb=function(b,c){this.width=b;this.height=c};J.u.lb.Ib=function(b,c){return b==c?!0:b&&c?b.width==c.width&&b.height==c.height:!1};J.u.lb.prototype.clone=function(){return new J.u.lb(this.width,this.height)};J.Z&&(J.u.lb.prototype.toString=function(){return"("+this.width+" x "+this.height+")"});H=J.u.lb.prototype;H.Ai=function(){return this.width*this.height};H.aspectRatio=function(){return this.width/this.height};H.Qb=function(){return!this.Ai()};
H.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};H.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};H.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};H.scale=function(b,c){c=J.Rb(c)?c:b;this.width*=b;this.height*=c;return this};J.a.yh=!1;J.a.ne=!1;J.a.Ih=J.a.yh||J.a.ne;J.a.td=function(b){return b?new J.a.jb(J.a.Qa(b)):J.a.hj||(J.a.hj=new J.a.jb)};J.a.yj=function(){return document};J.a.ud=function(b){return J.a.xd(document,b)};J.a.xd=function(b,c){return J.N(c)?b.getElementById(c):c};J.a.Gj=function(b){return J.a.Zf(document,b)};J.a.Zf=function(b,c){return J.a.xd(b,c)};J.a.qh=J.a.ud;J.a.getElementsByTagName=function(b,c){return(c||document).getElementsByTagName(String(b))};
J.a.yd=function(b,c,d){return J.a.kc(document,b,c,d)};J.a.Bj=function(b,c,d){return J.a.wd(document,b,c,d)};J.a.If=function(b,c){var d=c||document;return J.a.ad(d)?d.querySelectorAll("."+b):J.a.kc(document,"*",b,c)};J.a.vd=function(b,c){var d=c||document;return(d.getElementsByClassName?d.getElementsByClassName(b)[0]:J.a.wd(document,"*",b,c))||null};J.a.Yf=function(b,c){return J.a.vd(b,c)};J.a.ad=function(b){return!(!b.querySelectorAll||!b.querySelector)};
J.a.kc=function(b,c,d,e){b=e||b;c=c&&"*"!=c?String(c).toUpperCase():"";if(J.a.ad(b)&&(c||d))return b.querySelectorAll(c+(d?"."+d:""));if(d&&b.getElementsByClassName){b=b.getElementsByClassName(d);if(c){e={};for(var f=0,g=0,h;h=b[g];g++)c==h.nodeName&&(e[f++]=h);e.length=f;return e}return b}b=b.getElementsByTagName(c||"*");if(d){e={};for(g=f=0;h=b[g];g++)c=h.className,typeof c.split==q&&J.j.contains(c.split(/\s+/),d)&&(e[f++]=h);e.length=f;return e}return b};
J.a.wd=function(b,c,d,e){var f=e||b,g=c&&"*"!=c?String(c).toUpperCase():"";return J.a.ad(f)&&(g||d)?f.querySelector(g+(d?"."+d:"")):J.a.kc(b,c,d,e)[0]||null};J.a.rh=J.a.yd;J.a.Gc=function(b,c){J.object.forEach(c,function(c,e){c&&typeof c==w&&c.wa&&(c=c.ja());"style"==e?b.style.cssText=c:"class"==e?b.className=c:"for"==e?b.htmlFor=c:J.a.ue.hasOwnProperty(e)?b.setAttribute(J.a.ue[e],c):J.f.startsWith(e,"aria-")||J.f.startsWith(e,"data-")?b.setAttribute(e,c):b[e]=c})};
J.a.ue={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",nonce:"nonce",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};J.a.dg=function(b){return J.a.eg(b||window)};J.a.eg=function(b){b=b.document;b=J.a.Ob(b)?b.documentElement:b.body;return new J.u.lb(b.clientWidth,b.clientHeight)};J.a.zj=function(){return J.a.rd(window)};J.a.gr=function(b){return J.a.rd(b)};
J.a.rd=function(b){var c=b.document,d=0;if(c){d=c.body;var e=c.documentElement;if(!e||!d)return 0;b=J.a.eg(b).height;if(J.a.Ob(c)&&e.scrollHeight)d=e.scrollHeight!=b?e.scrollHeight:e.offsetHeight;else{c=e.scrollHeight;var f=e.offsetHeight;e.clientHeight!=f&&(c=d.scrollHeight,f=d.offsetHeight);d=c>b?c>f?c:f:c<f?c:f}}return d};J.a.pr=function(b){return J.a.td((b||J.global||window).document).Gf()};J.a.Gf=function(){return J.a.Hf(document)};
J.a.Hf=function(b){var c=J.a.sd(b);b=J.a.nc(b);return J.userAgent.$&&J.userAgent.xa("10")&&b.pageYOffset!=c.scrollTop?new J.u.X(c.scrollLeft,c.scrollTop):new J.u.X(b.pageXOffset||c.scrollLeft,b.pageYOffset||c.scrollTop)};J.a.Aj=function(){return J.a.sd(document)};J.a.sd=function(b){return b.scrollingElement?b.scrollingElement:!J.userAgent.Bb&&J.a.Ob(b)?b.documentElement:b.body||b.documentElement};J.a.qb=function(b){return b?J.a.nc(b):window};J.a.nc=function(b){return b.parentWindow||b.defaultView};
J.a.ed=function(b,c,d){return J.a.jf(document,arguments)};J.a.jf=function(b,c){var d=String(c[0]),e=c[1];if(!J.a.gb.Ch&&e&&(e.name||e.type)){d=["<",d];e.name&&d.push(' name="',J.f.va(e.name),'"');if(e.type){d.push(' type="',J.f.va(e.type),'"');var f={};J.object.extend(f,e);delete f.type;e=f}d.push(">");d=d.join("")}d=b.createElement(d);e&&(J.N(e)?d.className=e:J.isArray(e)?d.className=e.join(" "):J.a.Gc(d,e));2<c.length&&J.a.Ve(b,d,c,2);return d};
J.a.Ve=function(b,c,d,e){function f(d){d&&c.appendChild(J.N(d)?b.createTextNode(d):d)}for(;e<d.length;e++){var g=d[e];J.Nb(g)&&!J.a.Id(g)?J.j.forEach(J.a.Jd(g)?J.j.jh(g):g,f):f(g)}};J.a.sh=J.a.ed;J.a.createElement=function(b){return J.a.Na(document,b)};J.a.Na=function(b,c){return b.createElement(String(c))};J.a.createTextNode=function(b){return document.createTextNode(String(b))};J.a.cj=function(b,c,d){return J.a.kf(document,b,c,!!d)};
J.a.kf=function(b,c,d,e){for(var f=J.a.Na(b,"TABLE"),g=f.appendChild(J.a.Na(b,"TBODY")),h=0;h<c;h++){for(var l=J.a.Na(b,"TR"),m=0;m<d;m++){var r=J.a.Na(b,"TD");e&&J.a.Wd(r,J.f.Re.Fe);l.appendChild(r)}g.appendChild(l)}return f};J.a.hq=function(b){var c=J.j.map(arguments,J.f.H.s);c=J.b.fb.$k(J.f.H.from("Constant HTML string, that gets turned into a Node later, so it will be automatically balanced."),c.join(""));return J.a.Sg(c)};J.a.Sg=function(b){return J.a.Tg(document,b)};
J.a.Tg=function(b,c){var d=J.a.Na(b,"DIV");J.a.gb.Uh?(J.a.J.Zg(d,J.b.m.concat(J.b.m.re,c)),d.removeChild(d.firstChild)):J.a.J.Zg(d,c);return J.a.Vi(b,d)};J.a.Vi=function(b,c){if(1==c.childNodes.length)return c.removeChild(c.firstChild);for(b=b.createDocumentFragment();c.firstChild;)b.appendChild(c.firstChild);return b};J.a.Zj=function(){return J.a.Ob(document)};J.a.Ob=function(b){return J.a.Ih?J.a.ne:"CSS1Compat"==b.compatMode};J.a.canHaveChildren=function(b){if(b.nodeType!=J.a.fa.Ja)return!1;switch(b.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case k:case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
J.a.appendChild=function(b,c){b.appendChild(c)};J.a.append=function(b,c){J.a.Ve(J.a.Qa(b),b,arguments,1)};J.a.Td=function(b){for(var c;c=b.firstChild;)b.removeChild(c)};J.a.kg=function(b,c){c.parentNode&&c.parentNode.insertBefore(b,c)};J.a.jg=function(b,c){c.parentNode&&c.parentNode.insertBefore(b,c.nextSibling)};J.a.ig=function(b,c,d){b.insertBefore(c,b.childNodes[d]||null)};J.a.removeNode=function(b){return b&&b.parentNode?b.parentNode.removeChild(b):null};
J.a.Rg=function(b,c){var d=c.parentNode;d&&d.replaceChild(b,c)};J.a.xf=function(b){var c,d=b.parentNode;if(d&&d.nodeType!=J.a.fa.Nh){if(b.removeNode)return b.removeNode(!1);for(;c=b.firstChild;)d.insertBefore(c,b);return J.a.removeNode(b)}};J.a.Ef=function(b){return J.a.gb.Dh&&void 0!=b.children?b.children:J.j.filter(b.childNodes,function(b){return b.nodeType==J.a.fa.Ja})};J.a.Jf=function(b){return J.W(b.firstElementChild)?b.firstElementChild:J.a.lc(b.firstChild,!0)};
J.a.Nf=function(b){return J.W(b.lastElementChild)?b.lastElementChild:J.a.lc(b.lastChild,!1)};J.a.Pf=function(b){return J.W(b.nextElementSibling)?b.nextElementSibling:J.a.lc(b.nextSibling,!0)};J.a.Wf=function(b){return J.W(b.previousElementSibling)?b.previousElementSibling:J.a.lc(b.previousSibling,!1)};J.a.lc=function(b,c){for(;b&&b.nodeType!=J.a.fa.Ja;)b=c?b.nextSibling:b.previousSibling;return b};
J.a.Qf=function(b){if(!b)return null;if(b.firstChild)return b.firstChild;for(;b&&!b.nextSibling;)b=b.parentNode;return b?b.nextSibling:null};J.a.Xf=function(b){if(!b)return null;if(!b.previousSibling)return b.parentNode;for(b=b.previousSibling;b&&b.lastChild;)b=b.lastChild;return b};J.a.Id=function(b){return J.ka(b)&&0<b.nodeType};J.a.Fd=function(b){return J.ka(b)&&b.nodeType==J.a.fa.Ja};J.a.Dg=function(b){return J.ka(b)&&b.window==b};
J.a.Vf=function(b){var c;if(J.a.gb.Eh&&!(J.userAgent.$&&J.userAgent.xa("9")&&!J.userAgent.xa("10")&&J.global.SVGElement&&b instanceof J.global.SVGElement)&&(c=b.parentElement))return c;c=b.parentNode;return J.a.Fd(c)?c:null};J.a.contains=function(b,c){if(!b||!c)return!1;if(b.contains&&c.nodeType==J.a.fa.Ja)return b==c||b.contains(c);if("undefined"!=typeof b.compareDocumentPosition)return b==c||!!(b.compareDocumentPosition(c)&16);for(;c&&b!=c;)c=c.parentNode;return c==b};
J.a.df=function(b,c){if(b==c)return 0;if(b.compareDocumentPosition)return b.compareDocumentPosition(c)&2?1:-1;if(J.userAgent.$&&!J.userAgent.Pb(9)){if(b.nodeType==J.a.fa.Sc)return-1;if(c.nodeType==J.a.fa.Sc)return 1}if("sourceIndex"in b||b.parentNode&&"sourceIndex"in b.parentNode){var d=b.nodeType==J.a.fa.Ja,e=c.nodeType==J.a.fa.Ja;if(d&&e)return b.sourceIndex-c.sourceIndex;var f=b.parentNode,g=c.parentNode;return f==g?J.a.ff(b,c):!d&&J.a.contains(f,c)?-1*J.a.ef(b,c):!e&&J.a.contains(g,b)?J.a.ef(c,
b):(d?b.sourceIndex:f.sourceIndex)-(e?c.sourceIndex:g.sourceIndex)}e=J.a.Qa(b);d=e.createRange();d.selectNode(b);d.collapse(!0);b=e.createRange();b.selectNode(c);b.collapse(!0);return d.compareBoundaryPoints(J.global.Range.START_TO_END,b)};J.a.ef=function(b,c){var d=b.parentNode;if(d==c)return-1;for(;c.parentNode!=d;)c=c.parentNode;return J.a.ff(c,b)};J.a.ff=function(b,c){for(;c=c.previousSibling;)if(c==b)return-1;return 1};
J.a.tf=function(b){var c,d=arguments.length;if(!d)return null;if(1==d)return arguments[0];var e=[],f=Infinity;for(c=0;c<d;c++){for(var g=[],h=arguments[c];h;)g.unshift(h),h=h.parentNode;e.push(g);f=Math.min(f,g.length)}g=null;for(c=0;c<f;c++){h=e[0][c];for(var l=1;l<d;l++)if(h!=e[l][c])return g;g=h}return g};J.a.Qa=function(b){return b.nodeType==J.a.fa.Sc?b:b.ownerDocument||b.document};J.a.Kf=function(b){return b.contentDocument||b.contentWindow.document};
J.a.Lf=function(b){try{return b.contentWindow||(b.contentDocument?J.a.qb(b.contentDocument):null)}catch(c){}return null};J.a.Wd=function(b,c){if("textContent"in b)b.textContent=c;else if(b.nodeType==J.a.fa.ac)b.data=String(c);else if(b.firstChild&&b.firstChild.nodeType==J.a.fa.ac){for(;b.lastChild!=b.firstChild;)b.removeChild(b.lastChild);b.firstChild.data=String(c)}else{J.a.Td(b);var d=J.a.Qa(b);b.appendChild(d.createTextNode(String(c)))}};
J.a.Uf=function(b){if("outerHTML"in b)return b.outerHTML;var c=J.a.Qa(b);c=J.a.Na(c,"DIV");c.appendChild(b.cloneNode(!0));return c.innerHTML};J.a.uf=function(b,c){var d=[];return J.a.md(b,c,d,!0)?d[0]:void 0};J.a.vf=function(b,c){var d=[];J.a.md(b,c,d,!1);return d};J.a.md=function(b,c,d,e){if(null!=b)for(b=b.firstChild;b;){if(c(b)&&(d.push(b),e)||J.a.md(b,c,d,e))return!0;b=b.nextSibling}return!1};J.a.Oe={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1};J.a.Zb={IMG:" ",BR:"\n"};
J.a.Hd=function(b){return J.a.gg(b)&&J.a.Bg(b)};J.a.Xg=function(b,c){c?b.tabIndex=0:(b.tabIndex=-1,b.removeAttribute("tabIndex"))};J.a.qg=function(b){var c;return(c=J.a.Kk(b)?!b.disabled&&(!J.a.gg(b)||J.a.Bg(b)):J.a.Hd(b))&&J.userAgent.$?J.a.Sj(b):c};J.a.gg=function(b){return J.userAgent.$&&!J.userAgent.xa("9")?(b=b.getAttributeNode("tabindex"),J.bb(b)&&b.specified):b.hasAttribute("tabindex")};J.a.Bg=function(b){b=b.tabIndex;return J.Rb(b)&&0<=b&&32768>b};
J.a.Kk=function(b){return"A"==b.tagName||"INPUT"==b.tagName||"TEXTAREA"==b.tagName||"SELECT"==b.tagName||"BUTTON"==b.tagName};J.a.Sj=function(b){b=!J.Ba(b.getBoundingClientRect)||J.userAgent.$&&null==b.parentElement?{height:b.offsetHeight,width:b.offsetWidth}:b.getBoundingClientRect();return J.bb(b)&&0<b.height&&0<b.width};
J.a.mc=function(b){if(J.a.gb.se&&null!==b&&"innerText"in b)b=J.f.Ui(b.innerText);else{var c=[];J.a.Ad(b,c,!0);b=c.join("")}b=b.replace(/ \xAD /g," ").replace(/\xAD/g,"");b=b.replace(/\u200B/g,"");J.a.gb.se||(b=b.replace(/ +/g," "));" "!=b&&(b=b.replace(/^\s*/,""));return b};J.a.sr=function(b){var c=[];J.a.Ad(b,c,!1);return c.join("")};
J.a.Ad=function(b,c,d){if(!(b.nodeName in J.a.Oe))if(b.nodeType==J.a.fa.ac)d?c.push(String(b.nodeValue).replace(/(\r\n|\r|\n)/g,"")):c.push(b.nodeValue);else if(b.nodeName in J.a.Zb)c.push(J.a.Zb[b.nodeName]);else for(b=b.firstChild;b;)J.a.Ad(b,c,d),b=b.nextSibling};J.a.Sf=function(b){return J.a.mc(b).length};J.a.Tf=function(b,c){c=c||J.a.Qa(b).body;for(var d=[];b&&b!=c;){for(var e=b;e=e.previousSibling;)d.unshift(J.a.mc(e));b=b.parentNode}return J.f.trimLeft(d.join("")).replace(/ +/g," ").length};
J.a.Rf=function(b,c,d){b=[b];for(var e=0,f=null;0<b.length&&e<c;)if(f=b.pop(),!(f.nodeName in J.a.Oe))if(f.nodeType==J.a.fa.ac){var g=f.nodeValue.replace(/(\r\n|\r|\n)/g,"").replace(/ +/g," ");e+=g.length}else if(f.nodeName in J.a.Zb)e+=J.a.Zb[f.nodeName].length;else for(g=f.childNodes.length-1;0<=g;g--)b.push(f.childNodes[g]);J.ka(d)&&(d.Ss=f?f.nodeValue.length+c-e-1:0,d.node=f);return f};
J.a.Jd=function(b){if(b&&typeof b.length==v){if(J.ka(b))return typeof b.item==q||typeof b.item==z;if(J.Ba(b))return typeof b.item==q}return!1};J.a.pd=function(b,c,d,e){if(!c&&!d)return null;var f=c?String(c).toUpperCase():null;return J.a.od(b,function(b){return(!f||b.nodeName==f)&&(!d||J.N(b.className)&&J.j.contains(b.className.split(/\s+/),d))},!0,e)};J.a.Bf=function(b,c,d){return J.a.pd(b,null,c,d)};
J.a.od=function(b,c,d,e){b&&!d&&(b=b.parentNode);for(d=0;b&&(null==e||d<=e);){if(c(b))return b;b=b.parentNode;d++}return null};J.a.Af=function(b){try{var c=b&&b.activeElement;return c&&c.nodeName?c:null}catch(d){return null}};J.a.qr=function(){var b=J.a.qb();return J.W(b.devicePixelRatio)?b.devicePixelRatio:b.matchMedia?J.a.tc(3)||J.a.tc(2)||J.a.tc(1.5)||J.a.tc(1)||.75:1};
J.a.tc=function(b){return J.a.qb().matchMedia("(min-resolution: "+b+"dppx),(min--moz-device-pixel-ratio: "+b+"),(min-resolution: "+96*b+"dpi)").matches?b:0};J.a.Df=function(b){return b.getContext("2d")};J.a.jb=function(b){this.Y=b||J.global.document||document};H=J.a.jb.prototype;H.td=J.a.td;H.yj=E("Y");H.ud=function(b){return J.a.xd(this.Y,b)};H.Gj=function(b){return J.a.Zf(this.Y,b)};H.qh=J.a.jb.prototype.ud;H.getElementsByTagName=function(b,c){return(c||this.Y).getElementsByTagName(String(b))};
H.yd=function(b,c,d){return J.a.kc(this.Y,b,c,d)};H.Bj=function(b,c,d){return J.a.wd(this.Y,b,c,d)};H.If=function(b,c){return J.a.If(b,c||this.Y)};H.vd=function(b,c){return J.a.vd(b,c||this.Y)};H.Yf=function(b,c){return J.a.Yf(b,c||this.Y)};H.rh=J.a.jb.prototype.yd;H.Gc=J.a.Gc;H.dg=function(b){return J.a.dg(b||this.qb())};H.zj=function(){return J.a.rd(this.qb())};H.ed=function(b,c,d){return J.a.jf(this.Y,arguments)};H.sh=J.a.jb.prototype.ed;H.createElement=function(b){return J.a.Na(this.Y,b)};
H.createTextNode=function(b){return this.Y.createTextNode(String(b))};H.cj=function(b,c,d){return J.a.kf(this.Y,b,c,!!d)};H.Sg=function(b){return J.a.Tg(this.Y,b)};H.Zj=function(){return J.a.Ob(this.Y)};H.qb=function(){return J.a.nc(this.Y)};H.Aj=function(){return J.a.sd(this.Y)};H.Gf=function(){return J.a.Hf(this.Y)};H.Af=function(b){return J.a.Af(b||this.Y)};H.appendChild=J.a.appendChild;H.append=J.a.append;H.canHaveChildren=J.a.canHaveChildren;H.Td=J.a.Td;H.kg=J.a.kg;H.jg=J.a.jg;H.ig=J.a.ig;
H.removeNode=J.a.removeNode;H.Rg=J.a.Rg;H.xf=J.a.xf;H.Ef=J.a.Ef;H.Jf=J.a.Jf;H.Nf=J.a.Nf;H.Pf=J.a.Pf;H.Wf=J.a.Wf;H.Qf=J.a.Qf;H.Xf=J.a.Xf;H.Id=J.a.Id;H.Fd=J.a.Fd;H.Dg=J.a.Dg;H.Vf=J.a.Vf;H.contains=J.a.contains;H.df=J.a.df;H.tf=J.a.tf;H.Qa=J.a.Qa;H.Kf=J.a.Kf;H.Lf=J.a.Lf;H.Wd=J.a.Wd;H.Uf=J.a.Uf;H.uf=J.a.uf;H.vf=J.a.vf;H.Hd=J.a.Hd;H.Xg=J.a.Xg;H.qg=J.a.qg;H.mc=J.a.mc;H.Sf=J.a.Sf;H.Tf=J.a.Tf;H.Rf=J.a.Rf;H.Jd=J.a.Jd;H.pd=J.a.pd;H.Bf=J.a.Bf;H.od=J.a.od;H.Df=J.a.Df;J.Qg={};J.Qg.so=D();J.Thenable=D();J.Thenable.prototype.then=D();J.Thenable.Ce="$goog_Thenable";J.Thenable.Ue=function(b){b.prototype[J.Thenable.Ce]=!0};J.Thenable.rg=function(b){if(!b)return!1;try{return!!b[J.Thenable.Ce]}catch(c){return!1}};J.Promise=function(b,c){this.ba=J.Promise.T.ya;this.la=void 0;this.mb=this.Ma=this.ea=null;this.kd=!1;0<J.Promise.Wa?this.Jc=0:0==J.Promise.Wa&&(this.oc=!1);J.Promise.Da&&(this.$d=[],M(this,Error("created")),this.mf=0);if(b!=J.cb)try{var d=this;b.call(c,function(b){N(d,J.Promise.T.Ka,b)},function(b){if(J.Z&&!(b instanceof J.Promise.ib))try{if(b instanceof Error)throw b;throw Error("Promise rejected.");}catch(f){}N(d,J.Promise.T.na,b)})}catch(e){N(this,J.Promise.T.na,e)}};J.Promise.Da=!1;
J.Promise.Wa=0;J.Promise.T={ya:0,Ah:1,Ka:2,na:3};J.Promise.te=function(){this.next=this.context=this.tb=this.Tb=this.Xa=null;this.bc=!1};J.Promise.te.prototype.reset=function(){this.context=this.tb=this.Tb=this.Xa=null;this.bc=!1};J.Promise.Qc=100;J.Promise.Kb=new J.async.Xb(function(){return new J.Promise.te},function(b){b.reset()},J.Promise.Qc);J.Promise.Cf=function(b,c,d){var e=J.Promise.Kb.get();e.Tb=b;e.tb=c;e.context=d;return e};J.Promise.Sk=function(b){J.Promise.Kb.put(b)};
J.Promise.resolve=function(b){if(b instanceof J.Promise)return b;var c=new J.Promise(J.cb);N(c,J.Promise.T.Ka,b);return c};J.Promise.reject=function(b){return new J.Promise(function(c,d){d(b)})};J.Promise.Bc=function(b,c,d){J.Promise.Kg(b,c,d,null)||J.async.P(J.eb(c,b))};J.Promise.race=function(b){return new J.Promise(function(c,d){b.length||c(void 0);for(var e=0,f;e<b.length;e++)f=b[e],J.Promise.Bc(f,c,d)})};
J.Promise.all=function(b){return new J.Promise(function(c,d){var e=b.length,f=[];if(e)for(var g=function(b,d){e--;f[b]=d;0==e&&c(f)},h=function(b){d(b)},l=0,m;l<b.length;l++)m=b[l],J.Promise.Bc(m,J.eb(g,l),h);else c(f)})};J.Promise.lp=function(b){return new J.Promise(function(c){var d=b.length,e=[];if(d)for(var f=function(b,f,g){d--;e[b]=f?{wj:!0,value:g}:{wj:!1,reason:g};0==d&&c(e)},g=0,h;g<b.length;g++)h=b[g],J.Promise.Bc(h,J.eb(f,g,!0),J.eb(f,g,!1));else c(e)})};
J.Promise.Mq=function(b){return new J.Promise(function(c,d){var e=b.length,f=[];if(e)for(var g=function(b){c(b)},h=function(b,c){e--;f[b]=c;0==e&&d(f)},l=0,m;l<b.length;l++)m=b[l],J.Promise.Bc(m,g,J.eb(h,l));else c(void 0)})};J.Promise.ou=function(){var b,c,d=new J.Promise(function(d,f){b=d;c=f});return new J.Promise.bi(d,b,c)};J.Promise.prototype.then=function(b,c,d){J.Promise.Da&&M(this,Error("then"));return ca(this,J.Ba(b)?b:null,J.Ba(c)?c:null,d)};J.Thenable.Ue(J.Promise);
J.Promise.prototype.cancel=function(b){this.ba==J.Promise.T.ya&&J.async.P(function(){var c=new J.Promise.ib(b);O(this,c)},this)};function O(b,c){if(b.ba==J.Promise.T.ya)if(b.ea){var d=b.ea;if(d.Ma){for(var e=0,f=null,g=null,h=d.Ma;h&&(h.bc||(e++,h.Xa==b&&(f=h),!(f&&1<e)));h=h.next)f||(g=h);f&&(d.ba==J.Promise.T.ya&&1==e?O(d,c):(g?(e=g,e.next==d.mb&&(d.mb=e),e.next=e.next.next):P(d),Q(d,f,J.Promise.T.na,c)))}b.ea=null}else N(b,J.Promise.T.na,c)}
function R(b,c){b.Ma||b.ba!=J.Promise.T.Ka&&b.ba!=J.Promise.T.na||S(b);b.mb?b.mb.next=c:b.Ma=c;b.mb=c}function ca(b,c,d,e){var f=J.Promise.Cf(null,null,null);f.Xa=new J.Promise(function(b,h){f.Tb=c?function(d){try{var f=c.call(e,d);b(f)}catch(r){h(r)}}:b;f.tb=d?function(c){try{var f=d.call(e,c);!J.W(f)&&c instanceof J.Promise.ib?h(c):b(f)}catch(r){h(r)}}:h});f.Xa.ea=b;R(b,f);return f.Xa}J.Promise.prototype.xl=function(b){this.ba=J.Promise.T.ya;N(this,J.Promise.T.Ka,b)};
J.Promise.prototype.yl=function(b){this.ba=J.Promise.T.ya;N(this,J.Promise.T.na,b)};function N(b,c,d){b.ba==J.Promise.T.ya&&(b===d&&(c=J.Promise.T.na,d=new TypeError("Promise cannot resolve to itself")),b.ba=J.Promise.T.Ah,J.Promise.Kg(d,b.xl,b.yl,b)||(b.la=d,b.ba=c,b.ea=null,S(b),c!=J.Promise.T.na||d instanceof J.Promise.ib||J.Promise.zi(b,d)))}
J.Promise.Kg=function(b,c,d,e){if(b instanceof J.Promise)return J.Promise.Da&&M(b,Error("then")),R(b,J.Promise.Cf(c||J.cb,d||null,e)),!0;if(J.Thenable.rg(b))return b.then(c,d,e),!0;if(J.ka(b))try{var f=b.then;if(J.Ba(f))return J.Promise.vl(b,f,c,d,e),!0}catch(g){return d.call(e,g),!0}return!1};J.Promise.vl=function(b,c,d,e,f){function g(b){l||(l=!0,e.call(f,b))}function h(b){l||(l=!0,d.call(f,b))}var l=!1;try{c.call(b,h,g)}catch(m){g(m)}};function S(b){b.kd||(b.kd=!0,J.async.P(b.qj,b))}
function P(b){var c=null;b.Ma&&(c=b.Ma,b.Ma=c.next,c.next=null);b.Ma||(b.mb=null);return c}J.Promise.prototype.qj=function(){for(var b;b=P(this);)J.Promise.Da&&this.mf++,Q(this,b,this.ba,this.la);this.kd=!1};
function Q(b,c,d,e){if(d==J.Promise.T.na&&c.tb&&!c.bc)if(0<J.Promise.Wa)for(;b&&b.Jc;b=b.ea)J.global.clearTimeout(b.Jc),b.Jc=0;else if(0==J.Promise.Wa)for(;b&&b.oc;b=b.ea)b.oc=!1;if(c.Xa)c.Xa.ea=null,J.Promise.mg(c,d,e);else try{c.bc?c.Tb.call(c.context):J.Promise.mg(c,d,e)}catch(f){J.Promise.pc.call(null,f)}J.Promise.Sk(c)}J.Promise.mg=function(b,c,d){c==J.Promise.T.Ka?b.Tb.call(b.context,d):b.tb&&b.tb.call(b.context,d)};
function M(b,c){if(J.Promise.Da&&J.N(c.stack)){var d=c.stack.split("\n",4)[3];c=c.message;c+=Array(11-c.length).join(" ");b.$d.push(c+d)}}function T(b,c){if(J.Promise.Da&&c&&J.N(c.stack)&&b.$d.length){for(var d=["Promise trace:"],e=b;e;e=e.ea){for(var f=b.mf;0<=f;f--)d.push(e.$d[f]);d.push("Value: ["+(e.ba==J.Promise.T.na?"REJECTED":"FULFILLED")+"] <"+String(e.la)+">")}c.stack+="\n\n"+d.join("\n")}}
J.Promise.zi=function(b,c){0<J.Promise.Wa?b.Jc=J.global.setTimeout(function(){T(b,c);J.Promise.pc.call(null,c)},J.Promise.Wa):0==J.Promise.Wa&&(b.oc=!0,J.async.P(function(){b.oc&&(T(b,c),J.Promise.pc.call(null,c))}))};J.Promise.pc=J.async.gh;J.Promise.Jt=function(b){J.Promise.pc=b};J.Promise.ib=function(b){J.debug.Error.call(this,b)};J.$a(J.Promise.ib,J.debug.Error);J.Promise.ib.prototype.name="cancel";J.Promise.bi=function(b,c,d){this.Qg=b;this.resolve=c;this.reject=d};/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
J.async.B=function(b,c){this.Fc=[];this.Pg=b;this.nf=c||null;this.rb=this.nb=!1;this.la=void 0;this.Xd=this.Oi=this.$c=!1;this.Ic=0;this.ea=null;this.cc=0;J.async.B.Da&&(this.dd=null,Error.captureStackTrace&&(b={stack:""},Error.captureStackTrace(b,J.async.B),typeof b.stack==z&&(this.dd=b.stack.replace(/^[^\n]*\n/,""))))};J.async.B.li=!1;J.async.B.Da=!1;H=J.async.B.prototype;
H.cancel=function(b){if(this.nb)this.la instanceof J.async.B&&this.la.cancel();else{if(this.ea){var c=this.ea;delete this.ea;b?c.cancel(b):(c.cc--,0>=c.cc&&c.cancel())}this.Pg?this.Pg.call(this.nf,this):this.Xd=!0;this.nb||this.Pa(new J.async.B.hb(this))}};H.hf=function(b,c){this.$c=!1;U(this,b,c)};function U(b,c,d){b.nb=!0;b.la=d;b.rb=!c;V(b)}function W(b){if(b.nb){if(!b.Xd)throw new J.async.B.Ub(b);b.Xd=!1}}H.Cb=function(b){W(this);U(this,!0,b)};H.Pa=function(b){W(this);X(this,b);U(this,!1,b)};
function X(b,c){J.async.B.Da&&b.dd&&J.ka(c)&&c.stack&&/^[^\n]+(\n   [^\n]+)+/.test(c.stack)&&(c.stack=c.stack+"\nDEFERRED OPERATION:\n"+b.dd)}function Y(b,c,d){return Z(b,c,null,d)}function da(b,c){Z(b,null,c,void 0)}function Z(b,c,d,e){b.Fc.push([c,d,e]);b.nb&&V(b);return b}H.then=function(b,c,d){var e,f,g=new J.Promise(function(b,c){e=b;f=c});Z(this,e,function(b){b instanceof J.async.B.hb?g.cancel():f(b)});return g.then(b,c,d)};J.Thenable.Ue(J.async.B);
J.async.B.prototype.Qi=function(){var b=new J.async.B;Z(this,b.Cb,b.Pa,b);b.ea=this;this.cc++;return b};function ea(b){return J.j.some(b.Fc,function(b){return J.Ba(b[1])})}
function V(b){b.Ic&&b.nb&&ea(b)&&(J.async.B.Dl(b.Ic),b.Ic=0);b.ea&&(b.ea.cc--,delete b.ea);for(var c=b.la,d=!1,e=!1;b.Fc.length&&!b.$c;){var f=b.Fc.shift(),g=f[0],h=f[1];f=f[2];if(g=b.rb?h:g)try{var l=g.call(f||b.nf,c);J.W(l)&&(b.rb=b.rb&&(l==c||l instanceof Error),b.la=c=l);if(J.Thenable.rg(c)||typeof J.global.Promise===q&&c instanceof J.global.Promise)e=!0,b.$c=!0}catch(m){c=m,b.rb=!0,X(b,c),ea(b)||(d=!0)}}b.la=c;e?(e=J.bind(b.hf,b,!0),l=J.bind(b.hf,b,!1),c instanceof J.async.B?(Z(c,e,l),c.Oi=!0):
c.then(e,l)):J.async.B.li&&c instanceof Error&&!(c instanceof J.async.B.hb)&&(d=b.rb=!0);d&&(b.Ic=J.async.B.el(c))}J.async.B.eh=function(b){var c=new J.async.B;c.Cb(b);return c};J.async.B.Wq=function(b){var c=new J.async.B;b.then(function(b){c.Cb(b)},function(b){c.Pa(b)});return c};J.async.B.ha=function(b){var c=new J.async.B;c.Pa(b);return c};J.async.B.Tp=function(){var b=new J.async.B;b.cancel();return b};
J.async.B.nu=function(b,c,d){return b instanceof J.async.B?Y(b.Qi(),c,d):Y(J.async.B.eh(b),c,d)};J.async.B.Ub=function(){J.debug.Error.call(this)};J.$a(J.async.B.Ub,J.debug.Error);J.async.B.Ub.prototype.message="Deferred has already fired";J.async.B.Ub.prototype.name="AlreadyCalledError";J.async.B.hb=function(){J.debug.Error.call(this)};J.$a(J.async.B.hb,J.debug.Error);J.async.B.hb.prototype.message="Deferred was canceled";J.async.B.hb.prototype.name="CanceledError";
J.async.B.ye=function(b){this.Mb=J.global.setTimeout(J.bind(this.fh,this),0);this.oj=b};J.async.B.ye.prototype.fh=function(){delete J.async.B.Jb[this.Mb];throw this.oj;};J.async.B.Jb={};J.async.B.el=function(b){b=new J.async.B.ye(b);J.async.B.Jb[b.Mb]=b;return b.Mb};J.async.B.Dl=function(b){var c=J.async.B.Jb[b];c&&(J.global.clearTimeout(c.Mb),delete J.async.B.Jb[b])};J.async.B.Gp=function(){var b=J.async.B.Jb,c;for(c in b){var d=b[c];J.global.clearTimeout(d.Mb);d.fh()}};J.D={};J.D.F={};J.D.F.Uc="closure_verification";J.D.F.Lh=5E3;J.D.F.Vd=[];J.D.F.al=function(b,c){function d(){var e=b.shift();e=J.D.F.Cc(e,c);b.length&&Z(e,d,d,void 0);return e}if(!b.length)return J.async.B.eh(null);var e=J.D.F.Vd.length;J.j.extend(J.D.F.Vd,b);if(e)return J.D.F.Vg;b=J.D.F.Vd;J.D.F.Vg=d();return J.D.F.Vg};
J.D.F.Cc=function(b,c){var d=c||{};c=d.document||document;var e=J.b.C.s(b),f=J.a.createElement(k),g={Wg:f,ih:void 0},h=new J.async.B(J.D.F.Ti,g),l=null,m=J.bb(d.timeout)?d.timeout:J.D.F.Lh;0<m&&(l=window.setTimeout(function(){J.D.F.ec(f,!0);h.Pa(new J.D.F.Error(J.D.F.Wb.TIMEOUT,"Timeout reached for loading script "+e))},m),g.ih=l);f.onload=f.onreadystatechange=function(){f.readyState&&"loaded"!=f.readyState&&"complete"!=f.readyState||(J.D.F.ec(f,d.$p||!1,l),h.Cb(null))};f.onerror=function(){J.D.F.ec(f,
!0,l);h.Pa(new J.D.F.Error(J.D.F.Wb.Vh,"Error while loading script "+e))};g=d.attributes||{};J.object.extend(g,{type:A,charset:"UTF-8"});J.a.Gc(f,g);J.a.J.il(f,b);J.D.F.Ij(c).appendChild(f);return h};
J.D.F.ft=function(b,c,d){J.global[J.D.F.Uc]||(J.global[J.D.F.Uc]={});var e=J.global[J.D.F.Uc],f=J.b.C.s(b);if(J.W(e[c]))return J.async.B.ha(new J.D.F.Error(J.D.F.Wb.xi,"Verification object "+c+" already defined."));b=J.D.F.Cc(b,d);var g=new J.async.B(J.bind(b.cancel,b));Y(b,function(){var b=e[c];J.W(b)?(g.Cb(b),delete e[c]):g.Pa(new J.D.F.Error(J.D.F.Wb.wi,"Script "+f+" loaded, but verification object "+c+" was not defined."))});da(b,function(b){J.W(e[c])&&delete e[c];g.Pa(b)});return g};
J.D.F.Ij=function(b){var c=J.a.getElementsByTagName("HEAD",b);return!c||J.j.Qb(c)?b.documentElement:c[0]};J.D.F.Ti=function(){if(this&&this.Wg){var b=this.Wg;b&&b.tagName==k&&J.D.F.ec(b,!0,this.ih)}};J.D.F.ec=function(b,c,d){J.bb(d)&&J.global.clearTimeout(d);b.onload=J.cb;b.onerror=J.cb;b.onreadystatechange=J.cb;c&&window.setTimeout(function(){J.a.removeNode(b)},0)};J.D.F.Wb={Vh:0,TIMEOUT:1,wi:2,xi:3};
J.D.F.Error=function(b,c){var d="Jsloader error (code #"+b+")";c&&(d+=": "+c);J.debug.Error.call(this,d);this.code=b};J.$a(J.D.F.Error,J.debug.Error);var google={G:{}};google.G.K={};google.G.K.Ea={};google.G.K.Ea.hh=3E4;google.G.K.Ea.ws=function(b,c){return{format:b,Bi:c}};google.G.K.Ea.Lj=function(b){return J.b.C.format(b.format,b.Bi)};google.G.K.Ea.load=function(b,c){b=J.b.C.format(b,c);var d=J.D.F.Cc(b,{timeout:google.G.K.Ea.hh,attributes:{async:!1,defer:!1}});return new Promise(function(b){Y(d,b)})};
google.G.K.Ea.rs=function(b){b=J.j.map(b,google.G.K.Ea.Lj);if(J.j.Qb(b))return Promise.resolve();var c={timeout:google.G.K.Ea.hh,attributes:{async:!1,defer:!1}},d=[];!J.userAgent.$||J.userAgent.xa(11)?J.j.forEach(b,function(b){d.push(J.D.F.Cc(b,c))}):d.push(J.D.F.al(b,c));return Promise.all(J.j.map(d,function(b){return new Promise(function(c){return Y(b,c)})}))};google.G.K.U={};if(J.ob(t))throw Error("Google Charts loader.js can only be loaded once.");google.G.K.U.Il={1:"1.0","1.0":"current","1.1":"upcoming",41:x,42:x,43:x,44:x,46:"46.1",previous:"45.2",current:"46",upcoming:"46.2"};google.G.K.U.Fk=function(b){var c=b,d=b.match(/^testing-/);d&&(c=c.replace(/^testing-/,""));b=c;do{var e=google.G.K.U.Il[c];e&&(c=e)}while(e);d=(d?"testing-":"")+c;return{version:c==x?b:d,yk:d}};google.G.K.U.oh=null;
google.G.K.U.xk=function(b){var c=google.G.K.U.Fk(b),d=J.f.H.from("https://www.gstatic.com/charts/%{version}/loader.js");return google.G.K.Ea.load(d,{version:c.yk}).then(function(){var d=J.ob("google.charts.loader.VersionSpecific.load")||J.ob("google.charts.loader.publicLoad")||J.ob("google.charts.versionSpecific.load");if(!d)throw Error("Bad version: "+b);google.G.K.U.oh=function(b){b=d(c.version,b);if(null==b||null==b.then){var e=J.ob("google.charts.loader.publicSetOnLoadCallback")||J.ob("google.charts.versionSpecific.setOnLoadCallback");
b=new Promise(function(b){e(b)});b.then=e}return b}})};google.G.K.U.Ld=null;google.G.K.U.gc=null;google.G.K.U.vk=function(b,c){if(!google.G.K.U.Ld){if(c.getVersionFromUrl&&window.URLSearchParams)try{var d=new URLSearchParams(top.location.search);console.info("version from url",d.get(p));b=d.get(p)||b}catch(e){console.info("Failed to get charts-version from top URL",e)}google.G.K.U.Ld=google.G.K.U.xk(b)}return google.G.K.U.gc=google.G.K.U.Ld.then(function(){return google.G.K.U.oh(c)})};
google.G.K.U.hl=function(b){if(!google.G.K.U.gc)throw Error("Must call google.charts.load before google.charts.setOnLoadCallback");return b?google.G.K.U.gc.then(b):google.G.K.U.gc};google.G.load=function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];d=0;"visualization"===c[d]&&d++;var e="current";J.N(c[d])&&(e=c[d],d++);var f={};J.ka(c[d])&&(f=c[d]);return google.G.K.U.vk(e,f)};J.rf(t,google.G.load);google.G.gl=google.G.K.U.hl;J.rf("google.charts.setOnLoadCallback",google.G.gl);}).call(this);
;
(function ($) {

  'use strict';

  /**
   * Attaches the behavior to bootstrap carousel view.
   */
  Drupal.behaviors.views_bootstrap_carousel = {
    attach: function (context, settings) {
      $('.carousel-inner').each(function() {
        if ($(this).children('div').length === 1) {
          $(this).siblings('.carousel-control, .carousel-indicators').hide();
        }
      });
    }
  }



}(jQuery));;
