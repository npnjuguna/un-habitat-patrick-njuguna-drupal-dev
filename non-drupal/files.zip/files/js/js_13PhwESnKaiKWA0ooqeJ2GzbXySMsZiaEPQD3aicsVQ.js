/**
 * @file
 * Drupal Bootstrap object.
 */

/**
 * All Drupal Bootstrap JavaScript APIs are contained in this namespace.
 *
 * @namespace
 */
(function (_, $, Drupal, drupalSettings) {
  'use strict';

  var Bootstrap = {
    processedOnce: {},
    settings: drupalSettings.bootstrap || {}
  };

  /**
   * Wraps Drupal.checkPlain() to ensure value passed isn't empty.
   *
   * Encodes special characters in a plain-text string for display as HTML.
   *
   * @param {string} str
   *   The string to be encoded.
   *
   * @return {string}
   *   The encoded string.
   *
   * @ingroup sanitization
   */
  Bootstrap.checkPlain = function (str) {
    return str && Drupal.checkPlain(str) || '';
  };

  /**
   * Creates a jQuery plugin.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} plugin
   *   A constructor function used to initialize the for the jQuery plugin.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.createPlugin = function (id, plugin, noConflict) {
    // Immediately return if plugin doesn't exist.
    if ($.fn[id] !== void 0) {
      return this.fatal('Specified jQuery plugin identifier already exists: @id. Use Drupal.bootstrap.replacePlugin() instead.', {'@id': id});
    }

    // Immediately return if plugin isn't a function.
    if (typeof plugin !== 'function') {
      return this.fatal('You must provide a constructor function to create a jQuery plugin "@id": @plugin', {'@id': id, '@plugin':  plugin});
    }

    // Add a ".noConflict()" helper method.
    this.pluginNoConflict(id, plugin, noConflict);

    $.fn[id] = plugin;
  };

  /**
   * Diff object properties.
   *
   * @param {...Object} objects
   *   Two or more objects. The first object will be used to return properties
   *   values.
   *
   * @return {Object}
   *   Returns the properties of the first passed object that are not present
   *   in all other passed objects.
   */
  Bootstrap.diffObjects = function (objects) {
    var args = Array.prototype.slice.call(arguments);
    return _.pick(args[0], _.difference.apply(_, _.map(args, function (obj) {
      return Object.keys(obj);
    })));
  };

  /**
   * Map of supported events by regular expression.
   *
   * @type {Object<Event|MouseEvent|KeyboardEvent|TouchEvent,RegExp>}
   */
  Bootstrap.eventMap = {
    Event: /^(?:load|unload|abort|error|select|change|submit|reset|focus|blur|resize|scroll)$/,
    MouseEvent: /^(?:click|dblclick|mouse(?:down|enter|leave|up|over|move|out))$/,
    KeyboardEvent: /^(?:key(?:down|press|up))$/,
    TouchEvent: /^(?:touch(?:start|end|move|cancel))$/
  };

  /**
   * Extends a jQuery Plugin.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} callback
   *   A constructor function used to initialize the for the jQuery plugin.
   *
   * @return {Function|Boolean}
   *   The jQuery plugin constructor or FALSE if the plugin does not exist.
   */
  Bootstrap.extendPlugin = function (id, callback) {
    // Immediately return if plugin doesn't exist.
    if (typeof $.fn[id] !== 'function') {
      return this.fatal('Specified jQuery plugin identifier does not exist: @id', {'@id':  id});
    }

    // Immediately return if callback isn't a function.
    if (typeof callback !== 'function') {
      return this.fatal('You must provide a callback function to extend the jQuery plugin "@id": @callback', {'@id': id, '@callback':  callback});
    }

    // Determine existing plugin constructor.
    var constructor = $.fn[id] && $.fn[id].Constructor || $.fn[id];
    var proto = constructor.prototype;

    var obj = callback.apply(constructor, [this.settings]);
    if (!$.isPlainObject(obj)) {
      return this.fatal('Returned value from callback is not a plain object that can be used to extend the jQuery plugin "@id": @obj', {'@obj':  obj});
    }

    // Add a jQuery UI like option getter/setter method.
    var option = this.option;
    if (proto.option === void(0)) {
      proto.option = function () {
        return option.apply(this, arguments);
      };
    }

    // Handle prototype properties separately.
    if (obj.prototype !== void 0) {
      for (var key in obj.prototype) {
        if (!obj.prototype.hasOwnProperty(key)) continue;
        var value = obj.prototype[key];
        if (typeof value === 'function') {
          proto[key] = this.superWrapper(proto[key] || function () {}, value);
        }
        else {
          proto[key] = $.isPlainObject(value) ? $.extend(true, {}, proto[key], value) : value;
        }
      }
    }
    delete obj.prototype;

    // Handle static properties.
    for (key in obj) {
      if (!obj.hasOwnProperty(key)) continue;
      value = obj[key];
      if (typeof value === 'function') {
        constructor[key] = this.superWrapper(constructor[key] || function () {}, value);
      }
      else {
        constructor[key] = $.isPlainObject(value) ? $.extend(true, {}, constructor[key], value) : value;
      }
    }

    return $.fn[id];
  };

  Bootstrap.superWrapper = function (parent, fn) {
    return function () {
      var previousSuper = this.super;
      this.super = parent;
      var ret = fn.apply(this, arguments);
      if (previousSuper) {
        this.super = previousSuper;
      }
      else {
        delete this.super;
      }
      return ret;
    };
  };

  /**
   * Provide a helper method for displaying when something is went wrong.
   *
   * @param {String} message
   *   The message to display.
   * @param {Object} [args]
   *   An arguments to use in message.
   *
   * @return {Boolean}
   *   Always returns FALSE.
   */
  Bootstrap.fatal = function (message, args) {
    if (this.settings.dev && console.warn) {
      for (var name in args) {
        if (args.hasOwnProperty(name) && typeof args[name] === 'object') {
          args[name] = JSON.stringify(args[name]);
        }
      }
      Drupal.throwError(new Error(Drupal.formatString(message, args)));
    }
    return false;
  };

  /**
   * Intersects object properties.
   *
   * @param {...Object} objects
   *   Two or more objects. The first object will be used to return properties
   *   values.
   *
   * @return {Object}
   *   Returns the properties of first passed object that intersects with all
   *   other passed objects.
   */
  Bootstrap.intersectObjects = function (objects) {
    var args = Array.prototype.slice.call(arguments);
    return _.pick(args[0], _.intersection.apply(_, _.map(args, function (obj) {
      return Object.keys(obj);
    })));
  };

  /**
   * An object based once plugin (similar to jquery.once, but without the DOM).
   *
   * @param {String} id
   *   A unique identifier.
   * @param {Function} callback
   *   The callback to invoke if the identifier has not yet been seen.
   *
   * @return {Bootstrap}
   */
  Bootstrap.once = function (id, callback) {
    // Immediately return if identifier has already been processed.
    if (this.processedOnce[id]) {
      return this;
    }
    callback.call(this, this.settings);
    this.processedOnce[id] = true;
    return this;
  };

  /**
   * Provide jQuery UI like ability to get/set options for Bootstrap plugins.
   *
   * @param {string|object} key
   *   A string value of the option to set, can be dot like to a nested key.
   *   An object of key/value pairs.
   * @param {*} [value]
   *   (optional) A value to set for key.
   *
   * @returns {*}
   *   - Returns nothing if key is an object or both key and value parameters
   *   were provided to set an option.
   *   - Returns the a value for a specific setting if key was provided.
   *   - Returns an object of key/value pairs of all the options if no key or
   *   value parameter was provided.
   *
   * @see https://github.com/jquery/jquery-ui/blob/master/ui/widget.js
   */
  Bootstrap.option = function (key, value) {
    var options = $.isPlainObject(key) ? $.extend({}, key) : {};

    // Get all options (clone so it doesn't reference the internal object).
    if (arguments.length === 0) {
      return $.extend({}, this.options);
    }

    // Get/set single option.
    if (typeof key === "string") {
      // Handle nested keys in dot notation.
      // e.g., "foo.bar" => { foo: { bar: true } }
      var parts = key.split('.');
      key = parts.shift();
      var obj = options;
      if (parts.length) {
        for (var i = 0; i < parts.length - 1; i++) {
          obj[parts[i]] = obj[parts[i]] || {};
          obj = obj[parts[i]];
        }
        key = parts.pop();
      }

      // Get.
      if (arguments.length === 1) {
        return obj[key] === void 0 ? null : obj[key];
      }

      // Set.
      obj[key] = value;
    }

    // Set multiple options.
    $.extend(true, this.options, options);
  };

  /**
   * Adds a ".noConflict()" helper method if needed.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} plugin
   * @param {Function} plugin
   *   A constructor function used to initialize the for the jQuery plugin.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.pluginNoConflict = function (id, plugin, noConflict) {
    if (plugin.noConflict === void 0 && (noConflict === void 0 || noConflict)) {
      var old = $.fn[id];
      plugin.noConflict = function () {
        $.fn[id] = old;
        return this;
      };
    }
  };

  /**
   * Replaces a Bootstrap jQuery plugin definition.
   *
   * @param {String} id
   *   A jQuery plugin identifier located in $.fn.
   * @param {Function} callback
   *   A callback function that is immediately invoked and must return a
   *   function that will be used as the plugin constructor.
   * @param {Boolean} [noConflict]
   *   Flag indicating whether or not to create a ".noConflict()" helper method
   *   for the plugin.
   */
  Bootstrap.replacePlugin = function (id, callback, noConflict) {
    // Immediately return if plugin doesn't exist.
    if (typeof $.fn[id] !== 'function') {
      return this.fatal('Specified jQuery plugin identifier does not exist: @id', {'@id':  id});
    }

    // Immediately return if callback isn't a function.
    if (typeof callback !== 'function') {
      return this.fatal('You must provide a valid callback function to replace a jQuery plugin: @callback', {'@callback': callback});
    }

    // Determine existing plugin constructor.
    var constructor = $.fn[id] && $.fn[id].Constructor || $.fn[id];
    var plugin = callback.apply(constructor, [this.settings]);

    // Immediately return if plugin isn't a function.
    if (typeof plugin !== 'function') {
      return this.fatal('Returned value from callback is not a usable function to replace a jQuery plugin "@id": @plugin', {'@id': id, '@plugin': plugin});
    }

    // Add a ".noConflict()" helper method.
    this.pluginNoConflict(id, plugin, noConflict);

    $.fn[id] = plugin;
  };

  /**
   * Simulates a native event on an element in the browser.
   *
   * Note: This is a fairly complete modern implementation. If things aren't
   * working quite the way you intend (in older browsers), you may wish to use
   * the jQuery.simulate plugin. If it's available, this method will defer to
   * that plugin.
   *
   * @see https://github.com/jquery/jquery-simulate
   *
   * @param {HTMLElement|jQuery} element
   *   A DOM element to dispatch event on. Note: this may be a jQuery object,
   *   however be aware that this will trigger the same event for each element
   *   inside the jQuery collection; use with caution.
   * @param {String} type
   *   The type of event to simulate.
   * @param {Object} [options]
   *   An object of options to pass to the event constructor. Typically, if
   *   an event is being proxied, you should just pass the original event
   *   object here. This allows, if the browser supports it, to be a truly
   *   simulated event.
   *
   * @return {Boolean}
   *   The return value is false if event is cancelable and at least one of the
   *   event handlers which handled this event called Event.preventDefault().
   *   Otherwise it returns true.
   */
  Bootstrap.simulate = function (element, type, options) {
    // Handle jQuery object wrappers so it triggers on each element.
    if (element instanceof $) {
      var ret = true;
      element.each(function () {
        if (!Bootstrap.simulate(this, type, options)) {
          ret = false;
        }
      });
      return ret;
    }

    if (!(element instanceof HTMLElement)) {
      this.fatal('Passed element must be an instance of HTMLElement, got "@type" instead.', {
        '@type': typeof element,
      });
    }

    // Defer to the jQuery.simulate plugin, if it's available.
    if (typeof $.simulate === 'function') {
      new $.simulate(element, type, options);
      return true;
    }

    var event;
    var ctor;
    for (var name in this.eventMap) {
      if (this.eventMap[name].test(type)) {
        ctor = name;
        break;
      }
    }
    if (!ctor) {
      throw new SyntaxError('Only rudimentary HTMLEvents, KeyboardEvents and MouseEvents are supported: ' + type);
    }
    var opts = {bubbles: true, cancelable: true};
    if (ctor === 'KeyboardEvent' || ctor === 'MouseEvent') {
      $.extend(opts, {ctrlKey: !1, altKey: !1, shiftKey: !1, metaKey: !1});
    }
    if (ctor === 'MouseEvent') {
      $.extend(opts, {button: 0, pointerX: 0, pointerY: 0, view: window});
    }
    if (options) {
      $.extend(opts, options);
    }
    if (typeof window[ctor] === 'function') {
      event = new window[ctor](type, opts);
      return element.dispatchEvent(event);
    }
    else if (document.createEvent) {
      event = document.createEvent(ctor);
      event.initEvent(type, opts.bubbles, opts.cancelable);
      return element.dispatchEvent(event);
    }
    else if (typeof element.fireEvent === 'function') {
      event = $.extend(document.createEventObject(), opts);
      return element.fireEvent('on' + type, event);
    }
    else if (typeof element[type]) {
      element[type]();
      return true;
    }
  };

  /**
   * Strips HTML and returns just text.
   *
   * @param {String|Element|jQuery} html
   *   A string of HTML content, an Element DOM object or a jQuery object.
   *
   * @return {String}
   *   The text without HTML tags.
   *
   * @todo Replace with http://locutus.io/php/strings/strip_tags/
   */
  Bootstrap.stripHtml = function (html) {
    if (html instanceof $) {
      html = html.html();
    }
    else if (html instanceof Element) {
      html = html.innerHTML;
    }
    var tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return (tmp.textContent || tmp.innerText || '').replace(/^[\s\n\t]*|[\s\n\t]*$/g, '');
  };

  /**
   * Provide a helper method for displaying when something is unsupported.
   *
   * @param {String} type
   *   The type of unsupported object, e.g. method or option.
   * @param {String} name
   *   The name of the unsupported object.
   * @param {*} [value]
   *   The value of the unsupported object.
   */
  Bootstrap.unsupported = function (type, name, value) {
    Bootstrap.warn('Unsupported by Drupal Bootstrap: (@type) @name -> @value', {
      '@type': type,
      '@name': name,
      '@value': typeof value === 'object' ? JSON.stringify(value) : value
    });
  };

  /**
   * Provide a helper method to display a warning.
   *
   * @param {String} message
   *   The message to display.
   * @param {Object} [args]
   *   Arguments to use as replacements in Drupal.formatString.
   */
  Bootstrap.warn = function (message, args) {
    if (this.settings.dev && console.warn) {
      console.warn(Drupal.formatString(message, args));
    }
  };

  /**
   * Add Bootstrap to the global Drupal object.
   *
   * @type {Bootstrap}
   */
  Drupal.bootstrap = Drupal.bootstrap || Bootstrap;

})(window._, window.jQuery, window.Drupal, window.drupalSettings);
;
(function ($, _) {

  /**
   * @class Attributes
   *
   * Modifies attributes.
   *
   * @param {Object|Attributes} attributes
   *   An object to initialize attributes with.
   */
  var Attributes = function (attributes) {
    this.data = {};
    this.data['class'] = [];
    this.merge(attributes);
  };

  /**
   * Renders the attributes object as a string to inject into an HTML element.
   *
   * @return {String}
   *   A rendered string suitable for inclusion in HTML markup.
   */
  Attributes.prototype.toString = function () {
    var output = '';
    var name, value;
    var checkPlain = function (str) {
      return str && str.toString().replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;') || '';
    };
    var data = this.getData();
    for (name in data) {
      if (!data.hasOwnProperty(name)) continue;
      value = data[name];
      if (_.isFunction(value)) value = value();
      if (_.isObject(value)) value = _.values(value);
      if (_.isArray(value)) value = value.join(' ');
      output += ' ' + checkPlain(name) + '="' + checkPlain(value) + '"';
    }
    return output;
  };

  /**
   * Renders the Attributes object as a plain object.
   *
   * @return {Object}
   *   A plain object suitable for inclusion in DOM elements.
   */
  Attributes.prototype.toPlainObject = function () {
    var object = {};
    var name, value;
    var data = this.getData();
    for (name in data) {
      if (!data.hasOwnProperty(name)) continue;
      value = data[name];
      if (_.isFunction(value)) value = value();
      if (_.isObject(value)) value = _.values(value);
      if (_.isArray(value)) value = value.join(' ');
      object[name] = value;
    }
    return object;
  };

  /**
   * Add class(es) to the array.
   *
   * @param {string|Array} value
   *   An individual class or an array of classes to add.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.addClass = function (value) {
    var args = Array.prototype.slice.call(arguments);
    this.data['class'] = this.sanitizeClasses(this.data['class'].concat(args));
    return this;
  };

  /**
   * Returns whether the requested attribute exists.
   *
   * @param {string} name
   *   An attribute name to check.
   *
   * @return {boolean}
   *   TRUE or FALSE
   */
  Attributes.prototype.exists = function (name) {
    return this.data[name] !== void(0) && this.data[name] !== null;
  };

  /**
   * Retrieve a specific attribute from the array.
   *
   * @param {string} name
   *   The specific attribute to retrieve.
   * @param {*} defaultValue
   *   (optional) The default value to set if the attribute does not exist.
   *
   * @return {*}
   *   A specific attribute value, passed by reference.
   */
  Attributes.prototype.get = function (name, defaultValue) {
    if (!this.exists(name)) this.data[name] = defaultValue;
    return this.data[name];
  };

  /**
   * Retrieves a cloned copy of the internal attributes data object.
   *
   * @return {Object}
   */
  Attributes.prototype.getData = function () {
    return _.extend({}, this.data);
  };

  /**
   * Retrieves classes from the array.
   *
   * @return {Array}
   *   The classes array.
   */
  Attributes.prototype.getClasses = function () {
    return this.get('class', []);
  };

  /**
   * Indicates whether a class is present in the array.
   *
   * @param {string|Array} className
   *   The class(es) to search for.
   *
   * @return {boolean}
   *   TRUE or FALSE
   */
  Attributes.prototype.hasClass = function (className) {
    className = this.sanitizeClasses(Array.prototype.slice.call(arguments));
    var classes = this.getClasses();
    for (var i = 0, l = className.length; i < l; i++) {
      // If one of the classes fails, immediately return false.
      if (_.indexOf(classes, className[i]) === -1) {
        return false;
      }
    }
    return true;
  };

  /**
   * Merges multiple values into the array.
   *
   * @param {Attributes|Node|jQuery|Object} object
   *   An Attributes object with existing data, a Node DOM element, a jQuery
   *   instance or a plain object where the key is the attribute name and the
   *   value is the attribute value.
   * @param {boolean} [recursive]
   *   Flag determining whether or not to recursively merge key/value pairs.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.merge = function (object, recursive) {
    // Immediately return if there is nothing to merge.
    if (!object) {
      return this;
    }

    // Get attributes from a jQuery element.
    if (object instanceof $) {
      object = object[0];
    }

    // Get attributes from a DOM element.
    if (object instanceof Node) {
      object = Array.prototype.slice.call(object.attributes).reduce(function (attributes, attribute) {
        attributes[attribute.name] = attribute.value;
        return attributes;
      }, {});
    }
    // Get attributes from an Attributes instance.
    else if (object instanceof Attributes) {
      object = object.getData();
    }
    // Otherwise, clone the object.
    else {
      object = _.extend({}, object);
    }

    // By this point, there should be a valid plain object.
    if (!$.isPlainObject(object)) {
      setTimeout(function () {
        throw new Error('Passed object is not supported: ' + object);
      });
      return this;
    }

    // Handle classes separately.
    if (object && object['class'] !== void 0) {
      this.addClass(object['class']);
      delete object['class'];
    }

    if (recursive === void 0 || recursive) {
      this.data = $.extend(true, {}, this.data, object);
    }
    else {
      this.data = $.extend({}, this.data, object);
    }

    return this;
  };

  /**
   * Removes an attribute from the array.
   *
   * @param {string} name
   *   The name of the attribute to remove.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.remove = function (name) {
    if (this.exists(name)) delete this.data[name];
    return this;
  };

  /**
   * Removes a class from the attributes array.
   *
   * @param {...string|Array} className
   *   An individual class or an array of classes to remove.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.removeClass = function (className) {
    var remove = this.sanitizeClasses(Array.prototype.slice.apply(arguments));
    this.data['class'] = _.without(this.getClasses(), remove);
    return this;
  };

  /**
   * Replaces a class in the attributes array.
   *
   * @param {string} oldValue
   *   The old class to remove.
   * @param {string} newValue
   *   The new class. It will not be added if the old class does not exist.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.replaceClass = function (oldValue, newValue) {
    var classes = this.getClasses();
    var i = _.indexOf(this.sanitizeClasses(oldValue), classes);
    if (i >= 0) {
      classes[i] = newValue;
      this.set('class', classes);
    }
    return this;
  };

  /**
   * Ensures classes are flattened into a single is an array and sanitized.
   *
   * @param {...String|Array} classes
   *   The class or classes to sanitize.
   *
   * @return {Array}
   *   A sanitized array of classes.
   */
  Attributes.prototype.sanitizeClasses = function (classes) {
    return _.chain(Array.prototype.slice.call(arguments))
      // Flatten in case there's a mix of strings and arrays.
      .flatten()

      // Split classes that may have been added with a space as a separator.
      .map(function (string) {
        return string.split(' ');
      })

      // Flatten again since it was just split into arrays.
      .flatten()

      // Filter out empty items.
      .filter()

      // Clean the class to ensure it's a valid class name.
      .map(function (value) {
        return Attributes.cleanClass(value);
      })

      // Ensure classes are unique.
      .uniq()

      // Retrieve the final value.
      .value();
  };

  /**
   * Sets an attribute on the array.
   *
   * @param {string} name
   *   The name of the attribute to set.
   * @param {*} value
   *   The value of the attribute to set.
   *
   * @return {Attributes}
   *
   * @chainable
   */
  Attributes.prototype.set = function (name, value) {
    var obj = $.isPlainObject(name) ? name : {};
    if (typeof name === 'string') {
      obj[name] = value;
    }
    return this.merge(obj);
  };

  /**
   * Prepares a string for use as a CSS identifier (element, class, or ID name).
   *
   * Note: this is essentially a direct copy from
   * \Drupal\Component\Utility\Html::cleanCssIdentifier
   *
   * @param {string} identifier
   *   The identifier to clean.
   * @param {Object} [filter]
   *   An object of string replacements to use on the identifier.
   *
   * @return {string}
   *   The cleaned identifier.
   */
  Attributes.cleanClass = function (identifier, filter) {
    filter = filter || {
      ' ': '-',
      '_': '-',
      '/': '-',
      '[': '-',
      ']': ''
    };

    identifier = identifier.toLowerCase();

    if (filter['__'] === void 0) {
      identifier = identifier.replace('__', '#DOUBLE_UNDERSCORE#');
    }

    identifier = identifier.replace(Object.keys(filter), Object.keys(filter).map(function(key) { return filter[key]; }));

    if (filter['__'] === void 0) {
      identifier = identifier.replace('#DOUBLE_UNDERSCORE#', '__');
    }

    identifier = identifier.replace(/[^\u002D\u0030-\u0039\u0041-\u005A\u005F\u0061-\u007A\u00A1-\uFFFF]/g, '');
    identifier = identifier.replace(['/^[0-9]/', '/^(-[0-9])|^(--)/'], ['_', '__']);

    return identifier;
  };

  /**
   * Creates an Attributes instance.
   *
   * @param {object|Attributes} [attributes]
   *   An object to initialize attributes with.
   *
   * @return {Attributes}
   *   An Attributes instance.
   *
   * @constructor
   */
  Attributes.create = function (attributes) {
    return new Attributes(attributes);
  };

  window.Attributes = Attributes;

})(window.jQuery, window._);
;
/**
 * @file
 * Theme hooks for the Drupal Bootstrap base theme.
 */
(function ($, Drupal, Bootstrap, Attributes) {

  /**
   * Fallback for theming an icon if the Icon API module is not installed.
   */
  if (!Drupal.icon) Drupal.icon = { bundles: {} };
  if (!Drupal.theme.icon || Drupal.theme.prototype.icon) {
    $.extend(Drupal.theme, /** @lends Drupal.theme */ {
      /**
       * Renders an icon.
       *
       * @param {string} bundle
       *   The bundle which the icon belongs to.
       * @param {string} icon
       *   The name of the icon to render.
       * @param {object|Attributes} [attributes]
       *   An object of attributes to also apply to the icon.
       *
       * @returns {string}
       */
      icon: function (bundle, icon, attributes) {
        if (!Drupal.icon.bundles[bundle]) return '';
        attributes = Attributes.create(attributes).addClass('icon').set('aria-hidden', 'true');
        icon = Drupal.icon.bundles[bundle](icon, attributes);
        return '<span' + attributes + '></span>';
      }
    });
  }

  /**
   * Callback for modifying an icon in the "bootstrap" icon bundle.
   *
   * @param {string} icon
   *   The icon being rendered.
   * @param {Attributes} attributes
   *   Attributes object for the icon.
   */
  Drupal.icon.bundles.bootstrap = function (icon, attributes) {
    attributes.addClass(['glyphicon', 'glyphicon-' + icon]);
  };

  /**
   * Add necessary theming hooks.
   */
  $.extend(Drupal.theme, /** @lends Drupal.theme */ {

    /**
     * Renders a Bootstrap AJAX glyphicon throbber.
     *
     * @returns {string}
     */
    ajaxThrobber: function () {
      return Drupal.theme('bootstrapIcon', 'refresh', {'class': ['ajax-throbber', 'glyphicon-spin'] });
    },

    /**
     * Renders a button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button. If it contains one of:
     *   - value: The label of the button.
     *   - context: The context type of Bootstrap button, can be one of:
     *     - default
     *     - primary
     *     - success
     *     - info
     *     - warning
     *     - danger
     *     - link
     *
     * @returns {string}
     */
    button: function (attributes) {
      attributes = Attributes.create(attributes).addClass('btn');
      var context = attributes.get('context', 'default');
      var label = attributes.get('value', '');
      attributes.remove('context').remove('value');
      if (!attributes.hasClass(['btn-default', 'btn-primary', 'btn-success', 'btn-info', 'btn-warning', 'btn-danger', 'btn-link'])) {
        attributes.addClass('btn-' + Bootstrap.checkPlain(context));
      }

      // Attempt to, intelligently, provide a default button "type".
      if (!attributes.exists('type')) {
        attributes.set('type', attributes.hasClass('form-submit') ? 'submit' : 'button');
      }

      return '<button' + attributes + '>' + label + '</button>';
    },

    /**
     * Alias for "button" theme hook.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    btn: function (attributes) {
      return Drupal.theme('button', attributes);
    },

    /**
     * Renders a button block element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-block': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-block'));
    },

    /**
     * Renders a large button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-lg': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-lg'));
    },

    /**
     * Renders a small button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-sm': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-sm'));
    },

    /**
     * Renders an extra small button element.
     *
     * @param {object|Attributes} attributes
     *   An object of attributes to apply to the button.
     *
     * @see Drupal.theme.button()
     *
     * @returns {string}
     */
    'btn-xs': function (attributes) {
      return Drupal.theme('button', Attributes.create(attributes).addClass('btn-xs'));
    },

    /**
     * Renders a glyphicon.
     *
     * @param {string} name
     *   The name of the glyphicon.
     * @param {object|Attributes} [attributes]
     *   An object of attributes to apply to the icon.
     *
     * @returns {string}
     */
    bootstrapIcon: function (name, attributes) {
      return Drupal.theme('icon', 'bootstrap', name, attributes);
    }

  });

})(window.jQuery, window.Drupal, window.Drupal.bootstrap, window.Attributes);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, debounce) {
  $.fn.drupalGetSummary = function () {
    var callback = this.data('summaryCallback');
    return this[0] && callback ? $.trim(callback(this[0])) : '';
  };

  $.fn.drupalSetSummary = function (callback) {
    var self = this;

    if (typeof callback !== 'function') {
      var val = callback;
      callback = function callback() {
        return val;
      };
    }

    return this.data('summaryCallback', callback).off('formUpdated.summary').on('formUpdated.summary', function () {
      self.trigger('summaryUpdated');
    }).trigger('summaryUpdated');
  };

  Drupal.behaviors.formSingleSubmit = {
    attach: function attach() {
      function onFormSubmit(e) {
        var $form = $(e.currentTarget);
        var formValues = $form.serialize();
        var previousValues = $form.attr('data-drupal-form-submit-last');
        if (previousValues === formValues) {
          e.preventDefault();
        } else {
          $form.attr('data-drupal-form-submit-last', formValues);
        }
      }

      $('body').once('form-single-submit').on('submit.singleSubmit', 'form:not([method~="GET"])', onFormSubmit);
    }
  };

  function triggerFormUpdated(element) {
    $(element).trigger('formUpdated');
  }

  function fieldsList(form) {
    var $fieldList = $(form).find('[name]').map(function (index, element) {
      return element.getAttribute('id');
    });

    return $.makeArray($fieldList);
  }

  Drupal.behaviors.formUpdated = {
    attach: function attach(context) {
      var $context = $(context);
      var contextIsForm = $context.is('form');
      var $forms = (contextIsForm ? $context : $context.find('form')).once('form-updated');
      var formFields = void 0;

      if ($forms.length) {
        $.makeArray($forms).forEach(function (form) {
          var events = 'change.formUpdated input.formUpdated ';
          var eventHandler = debounce(function (event) {
            triggerFormUpdated(event.target);
          }, 300);
          formFields = fieldsList(form).join(',');

          form.setAttribute('data-drupal-form-fields', formFields);
          $(form).on(events, eventHandler);
        });
      }

      if (contextIsForm) {
        formFields = fieldsList(context).join(',');

        var currentFields = $(context).attr('data-drupal-form-fields');

        if (formFields !== currentFields) {
          triggerFormUpdated(context);
        }
      }
    },
    detach: function detach(context, settings, trigger) {
      var $context = $(context);
      var contextIsForm = $context.is('form');
      if (trigger === 'unload') {
        var $forms = (contextIsForm ? $context : $context.find('form')).removeOnce('form-updated');
        if ($forms.length) {
          $.makeArray($forms).forEach(function (form) {
            form.removeAttribute('data-drupal-form-fields');
            $(form).off('.formUpdated');
          });
        }
      }
    }
  };

  Drupal.behaviors.fillUserInfoFromBrowser = {
    attach: function attach(context, settings) {
      var userInfo = ['name', 'mail', 'homepage'];
      var $forms = $('[data-user-info-from-browser]').once('user-info-from-browser');
      if ($forms.length) {
        userInfo.forEach(function (info) {
          var $element = $forms.find('[name=' + info + ']');
          var browserData = localStorage.getItem('Drupal.visitor.' + info);
          var emptyOrDefault = $element.val() === '' || $element.attr('data-drupal-default-value') === $element.val();
          if ($element.length && emptyOrDefault && browserData) {
            $element.val(browserData);
          }
        });
      }
      $forms.on('submit', function () {
        userInfo.forEach(function (info) {
          var $element = $forms.find('[name=' + info + ']');
          if ($element.length) {
            localStorage.setItem('Drupal.visitor.' + info, $element.val());
          }
        });
      });
    }
  };

  var handleFragmentLinkClickOrHashChange = function handleFragmentLinkClickOrHashChange(e) {
    var url = void 0;
    if (e.type === 'click') {
      url = e.currentTarget.location ? e.currentTarget.location : e.currentTarget;
    } else {
      url = window.location;
    }
    var hash = url.hash.substr(1);
    if (hash) {
      var $target = $('#' + hash);
      $('body').trigger('formFragmentLinkClickOrHashChange', [$target]);

      setTimeout(function () {
        return $target.trigger('focus');
      }, 300);
    }
  };

  var debouncedHandleFragmentLinkClickOrHashChange = debounce(handleFragmentLinkClickOrHashChange, 300, true);

  $(window).on('hashchange.form-fragment', debouncedHandleFragmentLinkClickOrHashChange);

  $(document).on('click.form-fragment', 'a[href*="#"]', debouncedHandleFragmentLinkClickOrHashChange);
})(jQuery, Drupal, Drupal.debounce);;
/**
 * @file
 * Extends methods from core/misc/form.js.
 */

(function ($, window, Drupal, drupalSettings) {

  /**
   * Behavior for "forms_has_error_value_toggle" theme setting.
   */
  Drupal.behaviors.bootstrapForm = {
    attach: function (context) {
      if (drupalSettings.bootstrap && drupalSettings.bootstrap.forms_has_error_value_toggle) {
        var $context = $(context);
        $context.find('.form-item.has-error:not(.form-type-password.has-feedback)').once('error').each(function () {
          var $formItem = $(this);
          var $input = $formItem.find(':input');
          $input.on('keyup focus blur', function () {
            if (this.defaultValue !== void 0) {
              $formItem[this.defaultValue !== this.value ? 'removeClass' : 'addClass']('has-error');
              $input[this.defaultValue !== this.value ? 'removeClass' : 'addClass']('error');
            }
          });
        });
      }
    }
  };


})(jQuery, this, Drupal, drupalSettings);
;
/**
 * @file
 * Bootstrap Modals.
 */
(function ($, Drupal, Bootstrap, Attributes) {
  'use strict';

  /**
   * Document jQuery object.
   *
   * @type {jQuery}
   */
  var $document = $(document);

  /**
   * Finds the first available and visible focusable input element.
   *
   * This is abstracted from the main code below so sub-themes can override
   * this method to return their own element if desired.
   *
   * @param {Modal} modal
   *   The Bootstrap modal instance.
   *
   * @return {jQuery}
   *   A jQuery object containing the element that should be focused. Note: if
   *   this object contains multiple elements, only the first visible one will
   *   be used.
   */
  Bootstrap.modalFindFocusableElement = function (modal) {
    return modal.$dialogBody.find(':input,:button,.btn');
  };

  $document.on('shown.bs.modal', function (e) {
    var $modal = $(e.target);
    var modal = $modal.data('bs.modal');

    // Focus the first input element found.
    if (modal && modal.options.focusInput) {
      var $focusable = Bootstrap.modalFindFocusableElement(modal);
      if ($focusable && $focusable[0]) {
        var $input = $focusable.filter(':visible:first').focus();

        // Select text if input is text.
        if (modal.options.selectText && $input.is(':text')) {
          $input[0].setSelectionRange(0, $input[0].value.length)
        }
      }
    }
  });

  /**
   * Only process this once.
   */
  Bootstrap.once('modal', function (settings) {

    /**
     * Replace the Bootstrap Modal jQuery plugin definition.
     *
     * This adds a little bit of functionality so it works better with Drupal.
     */
    Bootstrap.replacePlugin('modal', function () {
      var BootstrapModal = this;

      // Override the Modal constructor.
      var Modal = function (element, options) {
        this.options             = options;
        this.$body               = $(document.body);
        this.$element            = $(element);
        this.$dialog             = this.$element.find('.modal-dialog');
        this.$header             = this.$dialog.find('.modal-header');
        this.$close              = this.$header.find('.close');
        this.$footer             = this.$dialog.find('.modal-footer');
        this.$content            = this.$dialog.find('.modal-content');
        this.$dialogBody         = this.$content.find('.modal-body');
        this.$backdrop           = null;
        this.isShown             = null;
        this.originalBodyPad     = null;
        this.scrollbarWidth      = 0;
        this.ignoreBackdropClick = false;
      };

      // Extend defaults to take into account for theme settings.
      Modal.DEFAULTS = $.extend({}, BootstrapModal.DEFAULTS, {
        animation: !!settings.modal_animation,
        backdrop: settings.modal_backdrop === 'static' ? 'static' : !!settings.modal_backdrop,
        focusInput: !!settings.modal_focus_input,
        selectText: !!settings.modal_select_text,
        keyboard: !!settings.modal_keyboard,
        show: !!settings.modal_show,
        size: settings.modal_size
      });

      // Copy over the original prototype methods.
      Modal.prototype = BootstrapModal.prototype;

      /**
       * Handler for $.fn.modal('destroy').
       */
      Modal.prototype.destroy = function () {
        this.hide();
        Drupal.detachBehaviors(this.$element[0]);
        this.$element.removeData('bs.modal').remove();
      };

      /**
       * Initialize the modal.
       */
      Modal.prototype.init = function () {
        if (this.options.remote) {
          this.$content.load(this.options.remote, $.proxy(function () {
            this.$element.trigger('loaded.bs.modal');
          }, this));
        }
      };

      // Modal jQuery Plugin Definition.
      var Plugin = function () {
        // Extract the arguments.
        var args = Array.prototype.slice.call(arguments);
        var method = args.shift();
        var options = {};
        if ($.isPlainObject(method)) {
          options = method;
          method = null;
        }
        var ret = void 0;
        this.each(function () {
          var $this   = $(this);
          var data    = $this.data('bs.modal');
          var initialize = false;

          // Immediately return if there's no instance to invoke a valid method.
          if (!data && method && method !== 'open') {
            return;
          }

          options = $.extend({}, Modal.DEFAULTS, data && data.options, $this.data(), options);
          if (!data) {
            // When initializing the Bootstrap Modal, only pass the "supported"
            // options by intersecting the default options. This allows plugins
            // like the jQuery UI bridge to properly detect when options have
            // changed when they're set below as a global "option" method.
            $this.data('bs.modal', (data = new Modal(this, Bootstrap.intersectObjects(options, Modal.DEFAULTS))));
            initialize = true;
          }

          // If no method or arguments, treat it like it's initializing the modal.
          if (!method && !args.length) {
            data.option(options);
            initialize = true;
          }

          // Initialize the modal.
          if (initialize) {
            data.init();
          }

          if (method) {
            if (typeof data[method] === 'function') {
              try {
                ret = data[method].apply(data, args);
              }
              catch (e) {
                Drupal.throwError(e);
              }
            }
            else {
              Bootstrap.unsupported('method', method);
            }
          }
        });

        // If just one element and there was a result returned for the option passed,
        // then return the result. Otherwise, just return the jQuery object.
        return this.length === 1 && ret !== void 0 ? ret : this;
      };

      // Replace the plugin constructor with the new Modal constructor.
      Plugin.Constructor = Modal;

      // Replace the data API so that it calls $.fn.modal rather than Plugin.
      // This allows sub-themes to replace the jQuery Plugin if they like with
      // out having to redo all this boilerplate.
      $document
        .off('click.bs.modal.data-api')
        .on('click.bs.modal.data-api', '[data-toggle="modal"]', function (e) {
          var $this   = $(this);
          var href    = $this.attr('href');
          var target  = $this.attr('data-target') || (href && href.replace(/.*(?=#[^\s]+$)/, '')); // strip for ie7
          var $target = $document.find(target);
          var option  = $target.data('bs.modal') ? 'toggle' : $.extend({ remote: !/#/.test(href) && href }, $target.data(), $this.data());

          if ($this.is('a')) e.preventDefault();

          $target.one('show.bs.modal', function (showEvent) {
            // Only register focus restorer if modal will actually get shown.
            if (showEvent.isDefaultPrevented()) return;
            $target.one('hidden.bs.modal', function () {
              $this.is(':visible') && $this.trigger('focus');
            });
          });
          $target.modal(option, this);
        });

      return Plugin;
    });

    /**
     * Extend Drupal theming functions.
     */
    $.extend(Drupal.theme, /** @lend Drupal.theme */ {
      /**
       * Theme function for a Bootstrap Modal.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal.
       */
      bootstrapModal: function (variables) {
        var output = '';
        var settings = drupalSettings.bootstrap || {};
        var defaults = {
          attributes: {
            class: ['modal'],
            tabindex: -1,
            role: 'dialog'
          },
          body: '',
          closeButton: true,
          description: {
            attributes: {
              class: ['help-block']
            },
            content: null,
            position: 'before'
          },
          footer: '',
          id: 'drupal-modal',
          size: settings.modal_size ? settings.modal_size : '',
          title: {
            attributes: {
              class: ['modal-title']
            },
            content: Drupal.t('Loading...'),
            html: false,
            tag: 'h4'
          }
        };
        variables = $.extend(true, {}, defaults, variables);

        var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
        attributes.set('id', attributes.get('id', variables.id));

        if (settings.modal_animation) {
          attributes.addClass('fade');
        }

        // Build the modal wrapper.
        output += '<div' + attributes + '>';

        // Build the modal-dialog wrapper.
        output += Drupal.theme('bootstrapModalDialog', _.omit(variables, 'attributes'));

        // Close the modal wrapper.
        output += '</div>';

        // Return the constructed modal.
        return output;
      },

      /**
       * Theme function for a Bootstrap Modal dialog markup.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal close button.
       */
      bootstrapModalDialog: function (variables) {
        var output = '';

        var defaults = {
          attributes: {
            class: ['modal-dialog'],
            role: 'document'
          },
          id: 'drupal-modal'
        };
        variables = $.extend(true, {}, defaults, variables);

        var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
        attributes.set('id', attributes.get('id', variables.id + '--dialog'));

        if (variables.size) {
          attributes.addClass(variables.size);
        }
        output += '<div' + attributes + '>';

        // Build the modal-content wrapper.
        output += Drupal.theme('bootstrapModalContent', _.omit(variables, 'attributes'));

        // Close the modal-dialog wrapper.
        output += '</div>';
        return output;
      },

      /**
       * Theme function for a Bootstrap Modal content markup.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal close button.
       */
      bootstrapModalContent: function (variables) {
        var output = '';

        var defaults = {
          attributes: {
            class: ['modal-content']
          },
          id: 'drupal-modal'
        };
        variables = $.extend(true, {}, defaults, variables);

        var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
        attributes.set('id', attributes.get('id', variables.id + '--content'));

        // Build the modal-content wrapper.
        output += '<div' + attributes + '>';
        variables = _.omit(variables, 'attributes');

        // Build the header wrapper and title.
        output += Drupal.theme('bootstrapModalHeader', variables);

        // Build the body.
        output += Drupal.theme('bootstrapModalBody', variables);

        // Build the footer.
        output += Drupal.theme('bootstrapModalFooter', variables);

        // Close the modal-content wrapper.
        output += '</div>';

        return output;
      },

      /**
       * Theme function for a Bootstrap Modal body markup.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal close button.
       */
      bootstrapModalBody: function (variables) {
        var output = '';

        var defaults = {
          attributes: {
            class: ['modal-body']
          },
          body: '',
          description: {
            attributes: {
              class: ['help-block']
            },
            content: null,
            position: 'before'
          },
          id: 'drupal-modal'
        };
        variables = $.extend(true, {}, defaults, variables);

        var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
        attributes.set('id', attributes.get('id', variables.id + '--body'));

        output += '<div' + attributes + '>';

        if (typeof variables.description === 'string') {
          variables.description = $.extend({}, defaults.description, { content: variables.description });
        }

        var description = variables.description;
        description.attributes = Attributes.create(defaults.description.attributes).merge(description.attributes);

        if (description.content && description.position === 'invisible') {
          description.attributes.addClass('sr-only');
        }

        if (description.content && description.position === 'before') {
          output += '<p' + description.attributes + '>' + description.content + '</p>';
        }

        output += variables.body;

        if (description.content && (description.position === 'after' || description.position === 'invisible')) {
          output += '<p' + description.attributes + '>' + description.content + '</p>';
        }

        output += '</div>';

        return output;
      },

      /**
       * Theme function for a Bootstrap Modal close button.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal close button.
       */
      bootstrapModalClose: function (variables) {
        var defaults = {
          attributes: {
            'aria-label': Drupal.t('Close'),
            class: ['close'],
            'data-dismiss': 'modal',
            type: 'button'
          }
        };
        variables = $.extend(true, {}, defaults, variables);
        var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
        return '<button' + attributes + '><span aria-hidden="true">&times;</span></button>';
      },

      /**
       * Theme function for a Bootstrap Modal footer.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       * @param {boolean} [force]
       *   Flag to force rendering the footer, regardless if there's content.
       *
       * @return {string}
       *   The HTML for the modal footer.
       */
      bootstrapModalFooter: function (variables, force) {
        var output = '';
        var defaults = {
          attributes: {
            class: ['modal-footer']
          },
          footer: '',
          id: 'drupal-modal'
        };

        variables = $.extend(true, {}, defaults, variables);

        if (force || variables.footer) {
          var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
          attributes.set('id', attributes.get('id', variables.id + '--footer'));
          output += '<div' + attributes + '>';
          output += variables.footer;
          output += '</div>';
        }

        return output;
      },

      /**
       * Theme function for a Bootstrap Modal header.
       *
       * @param {Object} [variables]
       *   An object containing key/value pairs of variables.
       *
       * @return {string}
       *   The HTML for the modal header.
       */
      bootstrapModalHeader: function (variables) {
        var output = '';

        var defaults = {
          attributes: {
            class: ['modal-header']
          },
          closeButton: true,
          id: 'drupal-modal',
          title: {
            attributes: {
              class: ['modal-title']
            },
            content: Drupal.t('Loading...'),
            html: false,
            tag: 'h4'
          }
        };
        variables = $.extend(true, {}, defaults, variables);

        var title = variables.title;
        if (title) {
          var attributes = Attributes.create(defaults.attributes).merge(variables.attributes);
          attributes.set('id', attributes.get('id', variables.id + '--header'));

          if (typeof title === 'string') {
            title = $.extend({}, defaults.title, { content: title });
          }

          output += '<div' + attributes + '>';

          if (variables.closeButton) {
            output += Drupal.theme('bootstrapModalClose', _.omit(variables, 'attributes'));
          }

          output += '<' + Drupal.checkPlain(title.tag) + Attributes.create(defaults.title.attributes).merge(title.attributes) + '>' + (title.html ? title.content : Drupal.checkPlain(title.content)) + '</' + Drupal.checkPlain(title.tag) + '>';

          output += '</div>';
        }

        return output;
      }
    })

  });

})(window.jQuery, window.Drupal, window.Drupal.bootstrap, window.Attributes);
;
/*! jQuery UI - v1.12.1 - 2017-03-31
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(a){"function"==typeof define&&define.amd?define(["jquery","../ie","../version","../widget"],a):a(jQuery)}(function(a){var b=!1;return a(document).on("mouseup",function(){b=!1}),a.widget("ui.mouse",{version:"1.12.1",options:{cancel:"input, textarea, button, select, option",distance:1,delay:0},_mouseInit:function(){var b=this;this.element.on("mousedown."+this.widgetName,function(a){return b._mouseDown(a)}).on("click."+this.widgetName,function(c){if(!0===a.data(c.target,b.widgetName+".preventClickEvent"))return a.removeData(c.target,b.widgetName+".preventClickEvent"),c.stopImmediatePropagation(),!1}),this.started=!1},_mouseDestroy:function(){this.element.off("."+this.widgetName),this._mouseMoveDelegate&&this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate)},_mouseDown:function(c){if(!b){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(c),this._mouseDownEvent=c;var d=this,e=1===c.which,f=!("string"!=typeof this.options.cancel||!c.target.nodeName)&&a(c.target).closest(this.options.cancel).length;return!(e&&!f&&this._mouseCapture(c))||(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){d.mouseDelayMet=!0},this.options.delay)),this._mouseDistanceMet(c)&&this._mouseDelayMet(c)&&(this._mouseStarted=this._mouseStart(c)!==!1,!this._mouseStarted)?(c.preventDefault(),!0):(!0===a.data(c.target,this.widgetName+".preventClickEvent")&&a.removeData(c.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(a){return d._mouseMove(a)},this._mouseUpDelegate=function(a){return d._mouseUp(a)},this.document.on("mousemove."+this.widgetName,this._mouseMoveDelegate).on("mouseup."+this.widgetName,this._mouseUpDelegate),c.preventDefault(),b=!0,!0))}},_mouseMove:function(b){if(this._mouseMoved){if(a.ui.ie&&(!document.documentMode||document.documentMode<9)&&!b.button)return this._mouseUp(b);if(!b.which)if(b.originalEvent.altKey||b.originalEvent.ctrlKey||b.originalEvent.metaKey||b.originalEvent.shiftKey)this.ignoreMissingWhich=!0;else if(!this.ignoreMissingWhich)return this._mouseUp(b)}return(b.which||b.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(b),b.preventDefault()):(this._mouseDistanceMet(b)&&this._mouseDelayMet(b)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,b)!==!1,this._mouseStarted?this._mouseDrag(b):this._mouseUp(b)),!this._mouseStarted)},_mouseUp:function(c){this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,c.target===this._mouseDownEvent.target&&a.data(c.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(c)),this._mouseDelayTimer&&(clearTimeout(this._mouseDelayTimer),delete this._mouseDelayTimer),this.ignoreMissingWhich=!1,b=!1,c.preventDefault()},_mouseDistanceMet:function(a){return Math.max(Math.abs(this._mouseDownEvent.pageX-a.pageX),Math.abs(this._mouseDownEvent.pageY-a.pageY))>=this.options.distance},_mouseDelayMet:function(){return this.mouseDelayMet},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return!0}})});;
/*! jQuery UI - v1.12.1 - 2017-03-31
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(a){"function"==typeof define&&define.amd?define(["jquery","./mouse","../data","../plugin","../safe-active-element","../safe-blur","../scroll-parent","../version","../widget"],a):a(jQuery)}(function(a){return a.widget("ui.draggable",a.ui.mouse,{version:"1.12.1",widgetEventPrefix:"drag",options:{addClasses:!0,appendTo:"parent",axis:!1,connectToSortable:!1,containment:!1,cursor:"auto",cursorAt:!1,grid:!1,handle:!1,helper:"original",iframeFix:!1,opacity:!1,refreshPositions:!1,revert:!1,revertDuration:500,scope:"default",scroll:!0,scrollSensitivity:20,scrollSpeed:20,snap:!1,snapMode:"both",snapTolerance:20,stack:!1,zIndex:!1,drag:null,start:null,stop:null},_create:function(){"original"===this.options.helper&&this._setPositionRelative(),this.options.addClasses&&this._addClass("ui-draggable"),this._setHandleClassName(),this._mouseInit()},_setOption:function(a,b){this._super(a,b),"handle"===a&&(this._removeHandleClassName(),this._setHandleClassName())},_destroy:function(){return(this.helper||this.element).is(".ui-draggable-dragging")?void(this.destroyOnClear=!0):(this._removeHandleClassName(),void this._mouseDestroy())},_mouseCapture:function(b){var c=this.options;return!(this.helper||c.disabled||a(b.target).closest(".ui-resizable-handle").length>0)&&(this.handle=this._getHandle(b),!!this.handle&&(this._blurActiveElement(b),this._blockFrames(c.iframeFix===!0?"iframe":c.iframeFix),!0))},_blockFrames:function(b){this.iframeBlocks=this.document.find(b).map(function(){var b=a(this);return a("<div>").css("position","absolute").appendTo(b.parent()).outerWidth(b.outerWidth()).outerHeight(b.outerHeight()).offset(b.offset())[0]})},_unblockFrames:function(){this.iframeBlocks&&(this.iframeBlocks.remove(),delete this.iframeBlocks)},_blurActiveElement:function(b){var c=a.ui.safeActiveElement(this.document[0]),d=a(b.target);d.closest(c).length||a.ui.safeBlur(c)},_mouseStart:function(b){var c=this.options;return this.helper=this._createHelper(b),this._addClass(this.helper,"ui-draggable-dragging"),this._cacheHelperProportions(),a.ui.ddmanager&&(a.ui.ddmanager.current=this),this._cacheMargins(),this.cssPosition=this.helper.css("position"),this.scrollParent=this.helper.scrollParent(!0),this.offsetParent=this.helper.offsetParent(),this.hasFixedAncestor=this.helper.parents().filter(function(){return"fixed"===a(this).css("position")}).length>0,this.positionAbs=this.element.offset(),this._refreshOffsets(b),this.originalPosition=this.position=this._generatePosition(b,!1),this.originalPageX=b.pageX,this.originalPageY=b.pageY,c.cursorAt&&this._adjustOffsetFromHelper(c.cursorAt),this._setContainment(),this._trigger("start",b)===!1?(this._clear(),!1):(this._cacheHelperProportions(),a.ui.ddmanager&&!c.dropBehaviour&&a.ui.ddmanager.prepareOffsets(this,b),this._mouseDrag(b,!0),a.ui.ddmanager&&a.ui.ddmanager.dragStart(this,b),!0)},_refreshOffsets:function(a){this.offset={top:this.positionAbs.top-this.margins.top,left:this.positionAbs.left-this.margins.left,scroll:!1,parent:this._getParentOffset(),relative:this._getRelativeOffset()},this.offset.click={left:a.pageX-this.offset.left,top:a.pageY-this.offset.top}},_mouseDrag:function(b,c){if(this.hasFixedAncestor&&(this.offset.parent=this._getParentOffset()),this.position=this._generatePosition(b,!0),this.positionAbs=this._convertPositionTo("absolute"),!c){var d=this._uiHash();if(this._trigger("drag",b,d)===!1)return this._mouseUp(new a.Event("mouseup",b)),!1;this.position=d.position}return this.helper[0].style.left=this.position.left+"px",this.helper[0].style.top=this.position.top+"px",a.ui.ddmanager&&a.ui.ddmanager.drag(this,b),!1},_mouseStop:function(b){var c=this,d=!1;return a.ui.ddmanager&&!this.options.dropBehaviour&&(d=a.ui.ddmanager.drop(this,b)),this.dropped&&(d=this.dropped,this.dropped=!1),"invalid"===this.options.revert&&!d||"valid"===this.options.revert&&d||this.options.revert===!0||a.isFunction(this.options.revert)&&this.options.revert.call(this.element,d)?a(this.helper).animate(this.originalPosition,parseInt(this.options.revertDuration,10),function(){c._trigger("stop",b)!==!1&&c._clear()}):this._trigger("stop",b)!==!1&&this._clear(),!1},_mouseUp:function(b){return this._unblockFrames(),a.ui.ddmanager&&a.ui.ddmanager.dragStop(this,b),this.handleElement.is(b.target)&&this.element.trigger("focus"),a.ui.mouse.prototype._mouseUp.call(this,b)},cancel:function(){return this.helper.is(".ui-draggable-dragging")?this._mouseUp(new a.Event("mouseup",{target:this.element[0]})):this._clear(),this},_getHandle:function(b){return!this.options.handle||!!a(b.target).closest(this.element.find(this.options.handle)).length},_setHandleClassName:function(){this.handleElement=this.options.handle?this.element.find(this.options.handle):this.element,this._addClass(this.handleElement,"ui-draggable-handle")},_removeHandleClassName:function(){this._removeClass(this.handleElement,"ui-draggable-handle")},_createHelper:function(b){var c=this.options,d=a.isFunction(c.helper),e=d?a(c.helper.apply(this.element[0],[b])):"clone"===c.helper?this.element.clone().removeAttr("id"):this.element;return e.parents("body").length||e.appendTo("parent"===c.appendTo?this.element[0].parentNode:c.appendTo),d&&e[0]===this.element[0]&&this._setPositionRelative(),e[0]===this.element[0]||/(fixed|absolute)/.test(e.css("position"))||e.css("position","absolute"),e},_setPositionRelative:function(){/^(?:r|a|f)/.test(this.element.css("position"))||(this.element[0].style.position="relative")},_adjustOffsetFromHelper:function(b){"string"==typeof b&&(b=b.split(" ")),a.isArray(b)&&(b={left:+b[0],top:+b[1]||0}),"left"in b&&(this.offset.click.left=b.left+this.margins.left),"right"in b&&(this.offset.click.left=this.helperProportions.width-b.right+this.margins.left),"top"in b&&(this.offset.click.top=b.top+this.margins.top),"bottom"in b&&(this.offset.click.top=this.helperProportions.height-b.bottom+this.margins.top)},_isRootNode:function(a){return/(html|body)/i.test(a.tagName)||a===this.document[0]},_getParentOffset:function(){var b=this.offsetParent.offset(),c=this.document[0];return"absolute"===this.cssPosition&&this.scrollParent[0]!==c&&a.contains(this.scrollParent[0],this.offsetParent[0])&&(b.left+=this.scrollParent.scrollLeft(),b.top+=this.scrollParent.scrollTop()),this._isRootNode(this.offsetParent[0])&&(b={top:0,left:0}),{top:b.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:b.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if("relative"!==this.cssPosition)return{top:0,left:0};var a=this.element.position(),b=this._isRootNode(this.scrollParent[0]);return{top:a.top-(parseInt(this.helper.css("top"),10)||0)+(b?0:this.scrollParent.scrollTop()),left:a.left-(parseInt(this.helper.css("left"),10)||0)+(b?0:this.scrollParent.scrollLeft())}},_cacheMargins:function(){this.margins={left:parseInt(this.element.css("marginLeft"),10)||0,top:parseInt(this.element.css("marginTop"),10)||0,right:parseInt(this.element.css("marginRight"),10)||0,bottom:parseInt(this.element.css("marginBottom"),10)||0}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var b,c,d,e=this.options,f=this.document[0];return this.relativeContainer=null,e.containment?"window"===e.containment?void(this.containment=[a(window).scrollLeft()-this.offset.relative.left-this.offset.parent.left,a(window).scrollTop()-this.offset.relative.top-this.offset.parent.top,a(window).scrollLeft()+a(window).width()-this.helperProportions.width-this.margins.left,a(window).scrollTop()+(a(window).height()||f.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]):"document"===e.containment?void(this.containment=[0,0,a(f).width()-this.helperProportions.width-this.margins.left,(a(f).height()||f.body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]):e.containment.constructor===Array?void(this.containment=e.containment):("parent"===e.containment&&(e.containment=this.helper[0].parentNode),c=a(e.containment),d=c[0],void(d&&(b=/(scroll|auto)/.test(c.css("overflow")),this.containment=[(parseInt(c.css("borderLeftWidth"),10)||0)+(parseInt(c.css("paddingLeft"),10)||0),(parseInt(c.css("borderTopWidth"),10)||0)+(parseInt(c.css("paddingTop"),10)||0),(b?Math.max(d.scrollWidth,d.offsetWidth):d.offsetWidth)-(parseInt(c.css("borderRightWidth"),10)||0)-(parseInt(c.css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left-this.margins.right,(b?Math.max(d.scrollHeight,d.offsetHeight):d.offsetHeight)-(parseInt(c.css("borderBottomWidth"),10)||0)-(parseInt(c.css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top-this.margins.bottom],this.relativeContainer=c))):void(this.containment=null)},_convertPositionTo:function(a,b){b||(b=this.position);var c="absolute"===a?1:-1,d=this._isRootNode(this.scrollParent[0]);return{top:b.top+this.offset.relative.top*c+this.offset.parent.top*c-("fixed"===this.cssPosition?-this.offset.scroll.top:d?0:this.offset.scroll.top)*c,left:b.left+this.offset.relative.left*c+this.offset.parent.left*c-("fixed"===this.cssPosition?-this.offset.scroll.left:d?0:this.offset.scroll.left)*c}},_generatePosition:function(a,b){var c,d,e,f,g=this.options,h=this._isRootNode(this.scrollParent[0]),i=a.pageX,j=a.pageY;return h&&this.offset.scroll||(this.offset.scroll={top:this.scrollParent.scrollTop(),left:this.scrollParent.scrollLeft()}),b&&(this.containment&&(this.relativeContainer?(d=this.relativeContainer.offset(),c=[this.containment[0]+d.left,this.containment[1]+d.top,this.containment[2]+d.left,this.containment[3]+d.top]):c=this.containment,a.pageX-this.offset.click.left<c[0]&&(i=c[0]+this.offset.click.left),a.pageY-this.offset.click.top<c[1]&&(j=c[1]+this.offset.click.top),a.pageX-this.offset.click.left>c[2]&&(i=c[2]+this.offset.click.left),a.pageY-this.offset.click.top>c[3]&&(j=c[3]+this.offset.click.top)),g.grid&&(e=g.grid[1]?this.originalPageY+Math.round((j-this.originalPageY)/g.grid[1])*g.grid[1]:this.originalPageY,j=c?e-this.offset.click.top>=c[1]||e-this.offset.click.top>c[3]?e:e-this.offset.click.top>=c[1]?e-g.grid[1]:e+g.grid[1]:e,f=g.grid[0]?this.originalPageX+Math.round((i-this.originalPageX)/g.grid[0])*g.grid[0]:this.originalPageX,i=c?f-this.offset.click.left>=c[0]||f-this.offset.click.left>c[2]?f:f-this.offset.click.left>=c[0]?f-g.grid[0]:f+g.grid[0]:f),"y"===g.axis&&(i=this.originalPageX),"x"===g.axis&&(j=this.originalPageY)),{top:j-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+("fixed"===this.cssPosition?-this.offset.scroll.top:h?0:this.offset.scroll.top),left:i-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+("fixed"===this.cssPosition?-this.offset.scroll.left:h?0:this.offset.scroll.left)}},_clear:function(){this._removeClass(this.helper,"ui-draggable-dragging"),this.helper[0]===this.element[0]||this.cancelHelperRemoval||this.helper.remove(),this.helper=null,this.cancelHelperRemoval=!1,this.destroyOnClear&&this.destroy()},_trigger:function(b,c,d){return d=d||this._uiHash(),a.ui.plugin.call(this,b,[c,d,this],!0),/^(drag|start|stop)/.test(b)&&(this.positionAbs=this._convertPositionTo("absolute"),d.offset=this.positionAbs),a.Widget.prototype._trigger.call(this,b,c,d)},plugins:{},_uiHash:function(){return{helper:this.helper,position:this.position,originalPosition:this.originalPosition,offset:this.positionAbs}}}),a.ui.plugin.add("draggable","connectToSortable",{start:function(b,c,d){var e=a.extend({},c,{item:d.element});d.sortables=[],a(d.options.connectToSortable).each(function(){var c=a(this).sortable("instance");c&&!c.options.disabled&&(d.sortables.push(c),c.refreshPositions(),c._trigger("activate",b,e))})},stop:function(b,c,d){var e=a.extend({},c,{item:d.element});d.cancelHelperRemoval=!1,a.each(d.sortables,function(){var a=this;a.isOver?(a.isOver=0,d.cancelHelperRemoval=!0,a.cancelHelperRemoval=!1,a._storedCSS={position:a.placeholder.css("position"),top:a.placeholder.css("top"),left:a.placeholder.css("left")},a._mouseStop(b),a.options.helper=a.options._helper):(a.cancelHelperRemoval=!0,a._trigger("deactivate",b,e))})},drag:function(b,c,d){a.each(d.sortables,function(){var e=!1,f=this;f.positionAbs=d.positionAbs,f.helperProportions=d.helperProportions,f.offset.click=d.offset.click,f._intersectsWith(f.containerCache)&&(e=!0,a.each(d.sortables,function(){return this.positionAbs=d.positionAbs,this.helperProportions=d.helperProportions,this.offset.click=d.offset.click,this!==f&&this._intersectsWith(this.containerCache)&&a.contains(f.element[0],this.element[0])&&(e=!1),e})),e?(f.isOver||(f.isOver=1,d._parent=c.helper.parent(),f.currentItem=c.helper.appendTo(f.element).data("ui-sortable-item",!0),f.options._helper=f.options.helper,f.options.helper=function(){return c.helper[0]},b.target=f.currentItem[0],f._mouseCapture(b,!0),f._mouseStart(b,!0,!0),f.offset.click.top=d.offset.click.top,f.offset.click.left=d.offset.click.left,f.offset.parent.left-=d.offset.parent.left-f.offset.parent.left,f.offset.parent.top-=d.offset.parent.top-f.offset.parent.top,d._trigger("toSortable",b),d.dropped=f.element,a.each(d.sortables,function(){this.refreshPositions()}),d.currentItem=d.element,f.fromOutside=d),f.currentItem&&(f._mouseDrag(b),c.position=f.position)):f.isOver&&(f.isOver=0,f.cancelHelperRemoval=!0,f.options._revert=f.options.revert,f.options.revert=!1,f._trigger("out",b,f._uiHash(f)),f._mouseStop(b,!0),f.options.revert=f.options._revert,f.options.helper=f.options._helper,f.placeholder&&f.placeholder.remove(),c.helper.appendTo(d._parent),d._refreshOffsets(b),c.position=d._generatePosition(b,!0),d._trigger("fromSortable",b),d.dropped=!1,a.each(d.sortables,function(){this.refreshPositions()}))})}}),a.ui.plugin.add("draggable","cursor",{start:function(b,c,d){var e=a("body"),f=d.options;e.css("cursor")&&(f._cursor=e.css("cursor")),e.css("cursor",f.cursor)},stop:function(b,c,d){var e=d.options;e._cursor&&a("body").css("cursor",e._cursor)}}),a.ui.plugin.add("draggable","opacity",{start:function(b,c,d){var e=a(c.helper),f=d.options;e.css("opacity")&&(f._opacity=e.css("opacity")),e.css("opacity",f.opacity)},stop:function(b,c,d){var e=d.options;e._opacity&&a(c.helper).css("opacity",e._opacity)}}),a.ui.plugin.add("draggable","scroll",{start:function(a,b,c){c.scrollParentNotHidden||(c.scrollParentNotHidden=c.helper.scrollParent(!1)),c.scrollParentNotHidden[0]!==c.document[0]&&"HTML"!==c.scrollParentNotHidden[0].tagName&&(c.overflowOffset=c.scrollParentNotHidden.offset())},drag:function(b,c,d){var e=d.options,f=!1,g=d.scrollParentNotHidden[0],h=d.document[0];g!==h&&"HTML"!==g.tagName?(e.axis&&"x"===e.axis||(d.overflowOffset.top+g.offsetHeight-b.pageY<e.scrollSensitivity?g.scrollTop=f=g.scrollTop+e.scrollSpeed:b.pageY-d.overflowOffset.top<e.scrollSensitivity&&(g.scrollTop=f=g.scrollTop-e.scrollSpeed)),e.axis&&"y"===e.axis||(d.overflowOffset.left+g.offsetWidth-b.pageX<e.scrollSensitivity?g.scrollLeft=f=g.scrollLeft+e.scrollSpeed:b.pageX-d.overflowOffset.left<e.scrollSensitivity&&(g.scrollLeft=f=g.scrollLeft-e.scrollSpeed))):(e.axis&&"x"===e.axis||(b.pageY-a(h).scrollTop()<e.scrollSensitivity?f=a(h).scrollTop(a(h).scrollTop()-e.scrollSpeed):a(window).height()-(b.pageY-a(h).scrollTop())<e.scrollSensitivity&&(f=a(h).scrollTop(a(h).scrollTop()+e.scrollSpeed))),e.axis&&"y"===e.axis||(b.pageX-a(h).scrollLeft()<e.scrollSensitivity?f=a(h).scrollLeft(a(h).scrollLeft()-e.scrollSpeed):a(window).width()-(b.pageX-a(h).scrollLeft())<e.scrollSensitivity&&(f=a(h).scrollLeft(a(h).scrollLeft()+e.scrollSpeed)))),f!==!1&&a.ui.ddmanager&&!e.dropBehaviour&&a.ui.ddmanager.prepareOffsets(d,b)}}),a.ui.plugin.add("draggable","snap",{start:function(b,c,d){var e=d.options;d.snapElements=[],a(e.snap.constructor!==String?e.snap.items||":data(ui-draggable)":e.snap).each(function(){var b=a(this),c=b.offset();this!==d.element[0]&&d.snapElements.push({item:this,width:b.outerWidth(),height:b.outerHeight(),top:c.top,left:c.left})})},drag:function(b,c,d){var e,f,g,h,i,j,k,l,m,n,o=d.options,p=o.snapTolerance,q=c.offset.left,r=q+d.helperProportions.width,s=c.offset.top,t=s+d.helperProportions.height;for(m=d.snapElements.length-1;m>=0;m--)i=d.snapElements[m].left-d.margins.left,j=i+d.snapElements[m].width,k=d.snapElements[m].top-d.margins.top,l=k+d.snapElements[m].height,r<i-p||q>j+p||t<k-p||s>l+p||!a.contains(d.snapElements[m].item.ownerDocument,d.snapElements[m].item)?(d.snapElements[m].snapping&&d.options.snap.release&&d.options.snap.release.call(d.element,b,a.extend(d._uiHash(),{snapItem:d.snapElements[m].item})),d.snapElements[m].snapping=!1):("inner"!==o.snapMode&&(e=Math.abs(k-t)<=p,f=Math.abs(l-s)<=p,g=Math.abs(i-r)<=p,h=Math.abs(j-q)<=p,e&&(c.position.top=d._convertPositionTo("relative",{top:k-d.helperProportions.height,left:0}).top),f&&(c.position.top=d._convertPositionTo("relative",{top:l,left:0}).top),g&&(c.position.left=d._convertPositionTo("relative",{top:0,left:i-d.helperProportions.width}).left),h&&(c.position.left=d._convertPositionTo("relative",{top:0,left:j}).left)),n=e||f||g||h,"outer"!==o.snapMode&&(e=Math.abs(k-s)<=p,f=Math.abs(l-t)<=p,g=Math.abs(i-q)<=p,h=Math.abs(j-r)<=p,e&&(c.position.top=d._convertPositionTo("relative",{top:k,left:0}).top),f&&(c.position.top=d._convertPositionTo("relative",{top:l-d.helperProportions.height,left:0}).top),g&&(c.position.left=d._convertPositionTo("relative",{top:0,left:i}).left),h&&(c.position.left=d._convertPositionTo("relative",{top:0,left:j-d.helperProportions.width}).left)),!d.snapElements[m].snapping&&(e||f||g||h||n)&&d.options.snap.snap&&d.options.snap.snap.call(d.element,b,a.extend(d._uiHash(),{snapItem:d.snapElements[m].item})),d.snapElements[m].snapping=e||f||g||h||n)}}),a.ui.plugin.add("draggable","stack",{start:function(b,c,d){var e,f=d.options,g=a.makeArray(a(f.stack)).sort(function(b,c){return(parseInt(a(b).css("zIndex"),10)||0)-(parseInt(a(c).css("zIndex"),10)||0)});g.length&&(e=parseInt(a(g[0]).css("zIndex"),10)||0,a(g).each(function(b){a(this).css("zIndex",e+b)}),this.css("zIndex",e+g.length))}}),a.ui.plugin.add("draggable","zIndex",{start:function(b,c,d){var e=a(c.helper),f=d.options;e.css("zIndex")&&(f._zIndex=e.css("zIndex")),e.css("zIndex",f.zIndex)},stop:function(b,c,d){var e=d.options;e._zIndex&&a(c.helper).css("zIndex",e._zIndex)}}),a.ui.draggable});;
/*! jQuery UI - v1.12.1 - 2017-03-31
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(a){"function"==typeof define&&define.amd?define(["jquery","./mouse","../disable-selection","../plugin","../version","../widget"],a):a(jQuery)}(function(a){return a.widget("ui.resizable",a.ui.mouse,{version:"1.12.1",widgetEventPrefix:"resize",options:{alsoResize:!1,animate:!1,animateDuration:"slow",animateEasing:"swing",aspectRatio:!1,autoHide:!1,classes:{"ui-resizable-se":"ui-icon ui-icon-gripsmall-diagonal-se"},containment:!1,ghost:!1,grid:!1,handles:"e,s,se",helper:!1,maxHeight:null,maxWidth:null,minHeight:10,minWidth:10,zIndex:90,resize:null,start:null,stop:null},_num:function(a){return parseFloat(a)||0},_isNumber:function(a){return!isNaN(parseFloat(a))},_hasScroll:function(b,c){if("hidden"===a(b).css("overflow"))return!1;var d=c&&"left"===c?"scrollLeft":"scrollTop",e=!1;return b[d]>0||(b[d]=1,e=b[d]>0,b[d]=0,e)},_create:function(){var b,c=this.options,d=this;this._addClass("ui-resizable"),a.extend(this,{_aspectRatio:!!c.aspectRatio,aspectRatio:c.aspectRatio,originalElement:this.element,_proportionallyResizeElements:[],_helper:c.helper||c.ghost||c.animate?c.helper||"ui-resizable-helper":null}),this.element[0].nodeName.match(/^(canvas|textarea|input|select|button|img)$/i)&&(this.element.wrap(a("<div class='ui-wrapper' style='overflow: hidden;'></div>").css({position:this.element.css("position"),width:this.element.outerWidth(),height:this.element.outerHeight(),top:this.element.css("top"),left:this.element.css("left")})),this.element=this.element.parent().data("ui-resizable",this.element.resizable("instance")),this.elementIsWrapper=!0,b={marginTop:this.originalElement.css("marginTop"),marginRight:this.originalElement.css("marginRight"),marginBottom:this.originalElement.css("marginBottom"),marginLeft:this.originalElement.css("marginLeft")},this.element.css(b),this.originalElement.css("margin",0),this.originalResizeStyle=this.originalElement.css("resize"),this.originalElement.css("resize","none"),this._proportionallyResizeElements.push(this.originalElement.css({position:"static",zoom:1,display:"block"})),this.originalElement.css(b),this._proportionallyResize()),this._setupHandles(),c.autoHide&&a(this.element).on("mouseenter",function(){c.disabled||(d._removeClass("ui-resizable-autohide"),d._handles.show())}).on("mouseleave",function(){c.disabled||d.resizing||(d._addClass("ui-resizable-autohide"),d._handles.hide())}),this._mouseInit()},_destroy:function(){this._mouseDestroy();var b,c=function(b){a(b).removeData("resizable").removeData("ui-resizable").off(".resizable").find(".ui-resizable-handle").remove()};return this.elementIsWrapper&&(c(this.element),b=this.element,this.originalElement.css({position:b.css("position"),width:b.outerWidth(),height:b.outerHeight(),top:b.css("top"),left:b.css("left")}).insertAfter(b),b.remove()),this.originalElement.css("resize",this.originalResizeStyle),c(this.originalElement),this},_setOption:function(a,b){switch(this._super(a,b),a){case"handles":this._removeHandles(),this._setupHandles()}},_setupHandles:function(){var b,c,d,e,f,g=this.options,h=this;if(this.handles=g.handles||(a(".ui-resizable-handle",this.element).length?{n:".ui-resizable-n",e:".ui-resizable-e",s:".ui-resizable-s",w:".ui-resizable-w",se:".ui-resizable-se",sw:".ui-resizable-sw",ne:".ui-resizable-ne",nw:".ui-resizable-nw"}:"e,s,se"),this._handles=a(),this.handles.constructor===String)for("all"===this.handles&&(this.handles="n,e,s,w,se,sw,ne,nw"),d=this.handles.split(","),this.handles={},c=0;c<d.length;c++)b=a.trim(d[c]),e="ui-resizable-"+b,f=a("<div>"),this._addClass(f,"ui-resizable-handle "+e),f.css({zIndex:g.zIndex}),this.handles[b]=".ui-resizable-"+b,this.element.append(f);this._renderAxis=function(b){var c,d,e,f;b=b||this.element;for(c in this.handles)this.handles[c].constructor===String?this.handles[c]=this.element.children(this.handles[c]).first().show():(this.handles[c].jquery||this.handles[c].nodeType)&&(this.handles[c]=a(this.handles[c]),this._on(this.handles[c],{mousedown:h._mouseDown})),this.elementIsWrapper&&this.originalElement[0].nodeName.match(/^(textarea|input|select|button)$/i)&&(d=a(this.handles[c],this.element),f=/sw|ne|nw|se|n|s/.test(c)?d.outerHeight():d.outerWidth(),e=["padding",/ne|nw|n/.test(c)?"Top":/se|sw|s/.test(c)?"Bottom":/^e$/.test(c)?"Right":"Left"].join(""),b.css(e,f),this._proportionallyResize()),this._handles=this._handles.add(this.handles[c])},this._renderAxis(this.element),this._handles=this._handles.add(this.element.find(".ui-resizable-handle")),this._handles.disableSelection(),this._handles.on("mouseover",function(){h.resizing||(this.className&&(f=this.className.match(/ui-resizable-(se|sw|ne|nw|n|e|s|w)/i)),h.axis=f&&f[1]?f[1]:"se")}),g.autoHide&&(this._handles.hide(),this._addClass("ui-resizable-autohide"))},_removeHandles:function(){this._handles.remove()},_mouseCapture:function(b){var c,d,e=!1;for(c in this.handles)d=a(this.handles[c])[0],(d===b.target||a.contains(d,b.target))&&(e=!0);return!this.options.disabled&&e},_mouseStart:function(b){var c,d,e,f=this.options,g=this.element;return this.resizing=!0,this._renderProxy(),c=this._num(this.helper.css("left")),d=this._num(this.helper.css("top")),f.containment&&(c+=a(f.containment).scrollLeft()||0,d+=a(f.containment).scrollTop()||0),this.offset=this.helper.offset(),this.position={left:c,top:d},this.size=this._helper?{width:this.helper.width(),height:this.helper.height()}:{width:g.width(),height:g.height()},this.originalSize=this._helper?{width:g.outerWidth(),height:g.outerHeight()}:{width:g.width(),height:g.height()},this.sizeDiff={width:g.outerWidth()-g.width(),height:g.outerHeight()-g.height()},this.originalPosition={left:c,top:d},this.originalMousePosition={left:b.pageX,top:b.pageY},this.aspectRatio="number"==typeof f.aspectRatio?f.aspectRatio:this.originalSize.width/this.originalSize.height||1,e=a(".ui-resizable-"+this.axis).css("cursor"),a("body").css("cursor","auto"===e?this.axis+"-resize":e),this._addClass("ui-resizable-resizing"),this._propagate("start",b),!0},_mouseDrag:function(b){var c,d,e=this.originalMousePosition,f=this.axis,g=b.pageX-e.left||0,h=b.pageY-e.top||0,i=this._change[f];return this._updatePrevProperties(),!!i&&(c=i.apply(this,[b,g,h]),this._updateVirtualBoundaries(b.shiftKey),(this._aspectRatio||b.shiftKey)&&(c=this._updateRatio(c,b)),c=this._respectSize(c,b),this._updateCache(c),this._propagate("resize",b),d=this._applyChanges(),!this._helper&&this._proportionallyResizeElements.length&&this._proportionallyResize(),a.isEmptyObject(d)||(this._updatePrevProperties(),this._trigger("resize",b,this.ui()),this._applyChanges()),!1)},_mouseStop:function(b){this.resizing=!1;var c,d,e,f,g,h,i,j=this.options,k=this;return this._helper&&(c=this._proportionallyResizeElements,d=c.length&&/textarea/i.test(c[0].nodeName),e=d&&this._hasScroll(c[0],"left")?0:k.sizeDiff.height,f=d?0:k.sizeDiff.width,g={width:k.helper.width()-f,height:k.helper.height()-e},h=parseFloat(k.element.css("left"))+(k.position.left-k.originalPosition.left)||null,i=parseFloat(k.element.css("top"))+(k.position.top-k.originalPosition.top)||null,j.animate||this.element.css(a.extend(g,{top:i,left:h})),k.helper.height(k.size.height),k.helper.width(k.size.width),this._helper&&!j.animate&&this._proportionallyResize()),a("body").css("cursor","auto"),this._removeClass("ui-resizable-resizing"),this._propagate("stop",b),this._helper&&this.helper.remove(),!1},_updatePrevProperties:function(){this.prevPosition={top:this.position.top,left:this.position.left},this.prevSize={width:this.size.width,height:this.size.height}},_applyChanges:function(){var a={};return this.position.top!==this.prevPosition.top&&(a.top=this.position.top+"px"),this.position.left!==this.prevPosition.left&&(a.left=this.position.left+"px"),this.size.width!==this.prevSize.width&&(a.width=this.size.width+"px"),this.size.height!==this.prevSize.height&&(a.height=this.size.height+"px"),this.helper.css(a),a},_updateVirtualBoundaries:function(a){var b,c,d,e,f,g=this.options;f={minWidth:this._isNumber(g.minWidth)?g.minWidth:0,maxWidth:this._isNumber(g.maxWidth)?g.maxWidth:1/0,minHeight:this._isNumber(g.minHeight)?g.minHeight:0,maxHeight:this._isNumber(g.maxHeight)?g.maxHeight:1/0},(this._aspectRatio||a)&&(b=f.minHeight*this.aspectRatio,d=f.minWidth/this.aspectRatio,c=f.maxHeight*this.aspectRatio,e=f.maxWidth/this.aspectRatio,b>f.minWidth&&(f.minWidth=b),d>f.minHeight&&(f.minHeight=d),c<f.maxWidth&&(f.maxWidth=c),e<f.maxHeight&&(f.maxHeight=e)),this._vBoundaries=f},_updateCache:function(a){this.offset=this.helper.offset(),this._isNumber(a.left)&&(this.position.left=a.left),this._isNumber(a.top)&&(this.position.top=a.top),this._isNumber(a.height)&&(this.size.height=a.height),this._isNumber(a.width)&&(this.size.width=a.width)},_updateRatio:function(a){var b=this.position,c=this.size,d=this.axis;return this._isNumber(a.height)?a.width=a.height*this.aspectRatio:this._isNumber(a.width)&&(a.height=a.width/this.aspectRatio),"sw"===d&&(a.left=b.left+(c.width-a.width),a.top=null),"nw"===d&&(a.top=b.top+(c.height-a.height),a.left=b.left+(c.width-a.width)),a},_respectSize:function(a){var b=this._vBoundaries,c=this.axis,d=this._isNumber(a.width)&&b.maxWidth&&b.maxWidth<a.width,e=this._isNumber(a.height)&&b.maxHeight&&b.maxHeight<a.height,f=this._isNumber(a.width)&&b.minWidth&&b.minWidth>a.width,g=this._isNumber(a.height)&&b.minHeight&&b.minHeight>a.height,h=this.originalPosition.left+this.originalSize.width,i=this.originalPosition.top+this.originalSize.height,j=/sw|nw|w/.test(c),k=/nw|ne|n/.test(c);return f&&(a.width=b.minWidth),g&&(a.height=b.minHeight),d&&(a.width=b.maxWidth),e&&(a.height=b.maxHeight),f&&j&&(a.left=h-b.minWidth),d&&j&&(a.left=h-b.maxWidth),g&&k&&(a.top=i-b.minHeight),e&&k&&(a.top=i-b.maxHeight),a.width||a.height||a.left||!a.top?a.width||a.height||a.top||!a.left||(a.left=null):a.top=null,a},_getPaddingPlusBorderDimensions:function(a){for(var b=0,c=[],d=[a.css("borderTopWidth"),a.css("borderRightWidth"),a.css("borderBottomWidth"),a.css("borderLeftWidth")],e=[a.css("paddingTop"),a.css("paddingRight"),a.css("paddingBottom"),a.css("paddingLeft")];b<4;b++)c[b]=parseFloat(d[b])||0,c[b]+=parseFloat(e[b])||0;return{height:c[0]+c[2],width:c[1]+c[3]}},_proportionallyResize:function(){if(this._proportionallyResizeElements.length)for(var a,b=0,c=this.helper||this.element;b<this._proportionallyResizeElements.length;b++)a=this._proportionallyResizeElements[b],this.outerDimensions||(this.outerDimensions=this._getPaddingPlusBorderDimensions(a)),a.css({height:c.height()-this.outerDimensions.height||0,width:c.width()-this.outerDimensions.width||0})},_renderProxy:function(){var b=this.element,c=this.options;this.elementOffset=b.offset(),this._helper?(this.helper=this.helper||a("<div style='overflow:hidden;'></div>"),this._addClass(this.helper,this._helper),this.helper.css({width:this.element.outerWidth(),height:this.element.outerHeight(),position:"absolute",left:this.elementOffset.left+"px",top:this.elementOffset.top+"px",zIndex:++c.zIndex}),this.helper.appendTo("body").disableSelection()):this.helper=this.element},_change:{e:function(a,b){return{width:this.originalSize.width+b}},w:function(a,b){var c=this.originalSize,d=this.originalPosition;return{left:d.left+b,width:c.width-b}},n:function(a,b,c){var d=this.originalSize,e=this.originalPosition;return{top:e.top+c,height:d.height-c}},s:function(a,b,c){return{height:this.originalSize.height+c}},se:function(b,c,d){return a.extend(this._change.s.apply(this,arguments),this._change.e.apply(this,[b,c,d]))},sw:function(b,c,d){return a.extend(this._change.s.apply(this,arguments),this._change.w.apply(this,[b,c,d]))},ne:function(b,c,d){return a.extend(this._change.n.apply(this,arguments),this._change.e.apply(this,[b,c,d]))},nw:function(b,c,d){return a.extend(this._change.n.apply(this,arguments),this._change.w.apply(this,[b,c,d]))}},_propagate:function(b,c){a.ui.plugin.call(this,b,[c,this.ui()]),"resize"!==b&&this._trigger(b,c,this.ui())},plugins:{},ui:function(){return{originalElement:this.originalElement,element:this.element,helper:this.helper,position:this.position,size:this.size,originalSize:this.originalSize,originalPosition:this.originalPosition}}}),a.ui.plugin.add("resizable","animate",{stop:function(b){var c=a(this).resizable("instance"),d=c.options,e=c._proportionallyResizeElements,f=e.length&&/textarea/i.test(e[0].nodeName),g=f&&c._hasScroll(e[0],"left")?0:c.sizeDiff.height,h=f?0:c.sizeDiff.width,i={width:c.size.width-h,height:c.size.height-g},j=parseFloat(c.element.css("left"))+(c.position.left-c.originalPosition.left)||null,k=parseFloat(c.element.css("top"))+(c.position.top-c.originalPosition.top)||null;c.element.animate(a.extend(i,k&&j?{top:k,left:j}:{}),{duration:d.animateDuration,easing:d.animateEasing,step:function(){var d={width:parseFloat(c.element.css("width")),height:parseFloat(c.element.css("height")),top:parseFloat(c.element.css("top")),left:parseFloat(c.element.css("left"))};e&&e.length&&a(e[0]).css({width:d.width,height:d.height}),c._updateCache(d),c._propagate("resize",b)}})}}),a.ui.plugin.add("resizable","containment",{start:function(){var b,c,d,e,f,g,h,i=a(this).resizable("instance"),j=i.options,k=i.element,l=j.containment,m=l instanceof a?l.get(0):/parent/.test(l)?k.parent().get(0):l;m&&(i.containerElement=a(m),/document/.test(l)||l===document?(i.containerOffset={left:0,top:0},i.containerPosition={left:0,top:0},i.parentData={element:a(document),left:0,top:0,width:a(document).width(),height:a(document).height()||document.body.parentNode.scrollHeight}):(b=a(m),c=[],a(["Top","Right","Left","Bottom"]).each(function(a,d){c[a]=i._num(b.css("padding"+d))}),i.containerOffset=b.offset(),i.containerPosition=b.position(),i.containerSize={height:b.innerHeight()-c[3],width:b.innerWidth()-c[1]},d=i.containerOffset,e=i.containerSize.height,f=i.containerSize.width,g=i._hasScroll(m,"left")?m.scrollWidth:f,h=i._hasScroll(m)?m.scrollHeight:e,i.parentData={element:m,left:d.left,top:d.top,width:g,height:h}))},resize:function(b){var c,d,e,f,g=a(this).resizable("instance"),h=g.options,i=g.containerOffset,j=g.position,k=g._aspectRatio||b.shiftKey,l={top:0,left:0},m=g.containerElement,n=!0;m[0]!==document&&/static/.test(m.css("position"))&&(l=i),j.left<(g._helper?i.left:0)&&(g.size.width=g.size.width+(g._helper?g.position.left-i.left:g.position.left-l.left),k&&(g.size.height=g.size.width/g.aspectRatio,n=!1),g.position.left=h.helper?i.left:0),j.top<(g._helper?i.top:0)&&(g.size.height=g.size.height+(g._helper?g.position.top-i.top:g.position.top),k&&(g.size.width=g.size.height*g.aspectRatio,n=!1),g.position.top=g._helper?i.top:0),e=g.containerElement.get(0)===g.element.parent().get(0),f=/relative|absolute/.test(g.containerElement.css("position")),e&&f?(g.offset.left=g.parentData.left+g.position.left,g.offset.top=g.parentData.top+g.position.top):(g.offset.left=g.element.offset().left,g.offset.top=g.element.offset().top),c=Math.abs(g.sizeDiff.width+(g._helper?g.offset.left-l.left:g.offset.left-i.left)),d=Math.abs(g.sizeDiff.height+(g._helper?g.offset.top-l.top:g.offset.top-i.top)),c+g.size.width>=g.parentData.width&&(g.size.width=g.parentData.width-c,k&&(g.size.height=g.size.width/g.aspectRatio,n=!1)),d+g.size.height>=g.parentData.height&&(g.size.height=g.parentData.height-d,k&&(g.size.width=g.size.height*g.aspectRatio,n=!1)),n||(g.position.left=g.prevPosition.left,g.position.top=g.prevPosition.top,g.size.width=g.prevSize.width,g.size.height=g.prevSize.height)},stop:function(){var b=a(this).resizable("instance"),c=b.options,d=b.containerOffset,e=b.containerPosition,f=b.containerElement,g=a(b.helper),h=g.offset(),i=g.outerWidth()-b.sizeDiff.width,j=g.outerHeight()-b.sizeDiff.height;b._helper&&!c.animate&&/relative/.test(f.css("position"))&&a(this).css({left:h.left-e.left-d.left,width:i,height:j}),b._helper&&!c.animate&&/static/.test(f.css("position"))&&a(this).css({left:h.left-e.left-d.left,width:i,height:j})}}),a.ui.plugin.add("resizable","alsoResize",{start:function(){var b=a(this).resizable("instance"),c=b.options;a(c.alsoResize).each(function(){var b=a(this);b.data("ui-resizable-alsoresize",{width:parseFloat(b.width()),height:parseFloat(b.height()),left:parseFloat(b.css("left")),top:parseFloat(b.css("top"))})})},resize:function(b,c){var d=a(this).resizable("instance"),e=d.options,f=d.originalSize,g=d.originalPosition,h={height:d.size.height-f.height||0,width:d.size.width-f.width||0,top:d.position.top-g.top||0,left:d.position.left-g.left||0};a(e.alsoResize).each(function(){var b=a(this),d=a(this).data("ui-resizable-alsoresize"),e={},f=b.parents(c.originalElement[0]).length?["width","height"]:["width","height","top","left"];a.each(f,function(a,b){var c=(d[b]||0)+(h[b]||0);c&&c>=0&&(e[b]=c||null)}),b.css(e)})},stop:function(){a(this).removeData("ui-resizable-alsoresize")}}),a.ui.plugin.add("resizable","ghost",{start:function(){var b=a(this).resizable("instance"),c=b.size;b.ghost=b.originalElement.clone(),b.ghost.css({opacity:.25,display:"block",position:"relative",height:c.height,width:c.width,margin:0,left:0,top:0}),b._addClass(b.ghost,"ui-resizable-ghost"),a.uiBackCompat!==!1&&"string"==typeof b.options.ghost&&b.ghost.addClass(this.options.ghost),b.ghost.appendTo(b.helper)},resize:function(){var b=a(this).resizable("instance");b.ghost&&b.ghost.css({position:"relative",height:b.size.height,width:b.size.width})},stop:function(){var b=a(this).resizable("instance");b.ghost&&b.helper&&b.helper.get(0).removeChild(b.ghost.get(0))}}),a.ui.plugin.add("resizable","grid",{resize:function(){var b,c=a(this).resizable("instance"),d=c.options,e=c.size,f=c.originalSize,g=c.originalPosition,h=c.axis,i="number"==typeof d.grid?[d.grid,d.grid]:d.grid,j=i[0]||1,k=i[1]||1,l=Math.round((e.width-f.width)/j)*j,m=Math.round((e.height-f.height)/k)*k,n=f.width+l,o=f.height+m,p=d.maxWidth&&d.maxWidth<n,q=d.maxHeight&&d.maxHeight<o,r=d.minWidth&&d.minWidth>n,s=d.minHeight&&d.minHeight>o;d.grid=i,r&&(n+=j),s&&(o+=k),p&&(n-=j),q&&(o-=k),/^(se|s|e)$/.test(h)?(c.size.width=n,c.size.height=o):/^(ne)$/.test(h)?(c.size.width=n,c.size.height=o,c.position.top=g.top-m):/^(sw)$/.test(h)?(c.size.width=n,c.size.height=o,c.position.left=g.left-l):((o-k<=0||n-j<=0)&&(b=c._getPaddingPlusBorderDimensions(this)),o-k>0?(c.size.height=o,c.position.top=g.top-m):(o=k-b.height,c.size.height=o,c.position.top=g.top+f.height-o),n-j>0?(c.size.width=n,c.position.left=g.left-l):(n=j-b.width,c.size.width=n,c.position.left=g.left+f.width-n))}}),a.ui.resizable});;
/**
 * @file
 * Bootstrap Modals.
 */
(function ($, Drupal, Bootstrap, Attributes, drupalSettings) {
  'use strict';

  /**
   * Only process this once.
   */
  Bootstrap.once('modal.jquery.ui.bridge', function (settings) {
    // RTL support.
    var rtl = document.documentElement.getAttribute('dir').toLowerCase() === 'rtl';

    // Override drupal.dialog button classes. This must be done on DOM ready
    // since core/drupal.dialog technically depends on this file and has not
    // yet set their default settings.
    $(function () {
      drupalSettings.dialog.buttonClass = 'btn';
      drupalSettings.dialog.buttonPrimaryClass = 'btn-primary';
    });

    var relayEvent = function ($element, name, stopPropagation) {
      return function (e) {
        if (stopPropagation === void 0 || stopPropagation) {
          e.stopPropagation();
        }
        var parts = name.split('.').filter(Boolean);
        var type = parts.shift();
        e.target = $element[0];
        e.currentTarget = $element[0];
        e.namespace = parts.join('.');
        e.type = type;
        $element.trigger(e);
      };
    };

    /**
     * Proxy $.fn.dialog to $.fn.modal.
     */
    Bootstrap.createPlugin('dialog', function (options) {
      // When only options are passed, jQuery UI dialog treats this like a
      // initialization method. Destroy any existing Bootstrap modal and
      // recreate it using the contents of the dialog HTML.
      if (arguments.length === 1 && typeof options === 'object') {
        this.each(function () {
          // This part gets a little tricky. Core can potentially already
          // semi-process this "dialog" if was created using an Ajax command
          // (i.e. prepareDialogButtons in drupal.ajax.js). Because of this,
          // we cannot simply dump the existing dialog content into a newly
          // created modal because that would destroy any existing event
          // bindings. Instead, we have to create this in steps and "move"
          // (append) the existing content as needed.
          var $this = $(this);

          // Create a new modal to get a complete template.
          var $modal = $(Drupal.theme('bootstrapModal', {attributes: Attributes.create(this).remove('style')}));

          // Store a reference to the content inside the existing dialog.
          // This references the actual DOM node elements which will allow
          // jQuery to "move" then when appending below. Using $.fn.children()
          // does not return any text nodes present and $.fn.html() only returns
          // a string representation of the content, which effectively destroys
          // any prior event bindings or processing.
          var $existing = $this.contents();

          // Destroy any existing Bootstrap Modal data that may have been saved.
          $this.removeData('bs.modal');

          // Set the attributes of the dialog to that of the newly created modal.
          $this.attr(Attributes.create($modal).toPlainObject());

          // Append the newly created modal markup.
          $this.append($modal.html());

          // Move the existing HTML into the modal markup that was just appended.
          $this.find('.modal-body').append($existing);
        });

        // Indicate that the modal is a jQuery UI dialog bridge.
        options.jQueryUiBridge = true;

        // Proxy just the options to the Bootstrap Modal plugin.
        return $.fn.modal.apply(this, [options]);
      }

      // Otherwise, proxy all arguments to the Bootstrap Modal plugin.
      return $.fn.modal.apply(this, arguments);
    });

    /**
     * Extend the Bootstrap Modal plugin constructor class.
     */
    Bootstrap.extendPlugin('modal', function () {
      var Modal = this;

      return {
        DEFAULTS: {
          // By default, this option is disabled. It's only flagged when a modal
          // was created using $.fn.dialog above.
          jQueryUiBridge: false
        },
        prototype: {

          /**
           * Handler for $.fn.dialog('close').
           */
          close: function () {
            var _this = this;

            this.hide.apply(this, arguments);

            // For some reason (likely due to the transition event not being
            // registered properly), the backdrop doesn't always get removed
            // after the above "hide" method is invoked . Instead, ensure the
            // backdrop is removed after the transition duration by manually
            // invoking the internal "hideModal" method shortly thereafter.
            setTimeout(function () {
              if (!_this.isShown && _this.$backdrop) {
                _this.hideModal();
              }
            }, (Modal.TRANSITION_DURATION !== void 0 ? Modal.TRANSITION_DURATION : 300) + 10);
          },

          /**
           * Creates any necessary buttons from dialog options.
           */
          createButtons: function () {
            this.$footer.find('.modal-buttons').remove();

            // jQuery UI supports both objects and arrays. Unfortunately
            // developers have misunderstood and abused this by simply placing
            // the objects that should be in an array inside an object with
            // arbitrary keys (likely to target specific buttons as a hack).
            var buttons = this.options.dialogOptions && this.options.dialogOptions.buttons || [];
            if (!Array.isArray(buttons)) {
              var array = [];
              for (var k in buttons) {
                // Support the proper object values: label => click callback.
                if (typeof buttons[k] === 'function') {
                  array.push({
                    label: k,
                    click: buttons[k],
                  });
                }
                // Support nested objects, but log a warning.
                else if (buttons[k].text || buttons[k].label) {
                  Bootstrap.warn('Malformed jQuery UI dialog button: @key. The button object should be inside an array.', {
                    '@key': k
                  });
                  array.push(buttons[k]);
                }
                else {
                  Bootstrap.unsupported('button', k, buttons[k]);
                }
              }
              buttons = array;
            }

            if (buttons.length) {
              var $buttons = $('<div class="modal-buttons"/>').appendTo(this.$footer);
              for (var i = 0, l = buttons.length; i < l; i++) {
                var button = buttons[i];
                var $button = $(Drupal.theme('bootstrapModalDialogButton', button));

                // Invoke the "create" method for jQuery UI buttons.
                if (typeof button.create === 'function') {
                  button.create.call($button[0]);
                }

                // Bind the "click" method for jQuery UI buttons to the modal.
                if (typeof button.click === 'function') {
                  $button.on('click', button.click.bind(this.$element));
                }

                $buttons.append($button);
              }
            }

            // Toggle footer visibility based on whether it has child elements.
            this.$footer[this.$footer.children()[0] ? 'show' : 'hide']();
          },

          /**
           * Initializes the Bootstrap Modal.
           */
          init: function () {
            // Relay necessary events.
            if (this.options.jQueryUiBridge) {
              this.$element.on('hide.bs.modal',   relayEvent(this.$element, 'dialogbeforeclose', false));
              this.$element.on('hidden.bs.modal', relayEvent(this.$element, 'dialogclose', false));
              this.$element.on('show.bs.modal',   relayEvent(this.$element, 'dialogcreate', false));
              this.$element.on('shown.bs.modal',  relayEvent(this.$element, 'dialogopen', false));
            }

            // Create a footer if one doesn't exist.
            // This is necessary in case dialog.ajax.js decides to add buttons.
            if (!this.$footer[0]) {
              this.$footer = $(Drupal.theme('bootstrapModalFooter', {}, true)).insertAfter(this.$dialogBody);
            }

            // Now call the parent init method.
            this.super();

            // Handle autoResize option (this is a drupal.dialog option).
            if (this.options.dialogOptions && this.options.dialogOptions.autoResize && this.options.dialogOptions.position) {
              this.position(this.options.dialogOptions.position);
            }

            // If show is enabled and currently not shown, show it.
            if (this.options.show && !this.isShown) {
              this.show();
            }
          },

          /**
           * Handler for $.fn.dialog('instance').
           */
          instance: function () {
            Bootstrap.unsupported('method', 'instance', arguments);
          },

          /**
           * Handler for $.fn.dialog('isOpen').
           */
          isOpen: function () {
            return !!this.isShown;
          },

          /**
           * Maps dialog options to the modal.
           *
           * @param {Object} options
           *   The options to map.
           */
          mapDialogOptions: function (options) {
            var dialogOptions = {};
            var mappedOptions = {};

            // Handle CSS properties.
            var cssUnitRegExp = /^([+-]?(?:\d+|\d*\.\d+))([a-z]*|%)?$/;
            var parseCssUnit = function (value, defaultUnit) {
              var parts = ('' + value).match(cssUnitRegExp);
              return parts && parts[1] !== void 0 ? parts[1] + (parts[2] || defaultUnit || 'px') : null;
            };
            var styles = {};
            var cssProperties = ['height', 'maxHeight', 'maxWidth', 'minHeight', 'minWidth', 'width'];
            for (var i = 0, l = cssProperties.length; i < l; i++) {
              var prop = cssProperties[i];
              if (options[prop] !== void 0) {
                var value = parseCssUnit(options[prop]);
                if (value) {
                  dialogOptions[prop] = value;
                  styles[prop] = value;

                  // If there's a defined height of some kind, enforce the modal
                  // to use flex (on modern browsers). This will ensure that
                  // the core autoResize calculations don't cause the content
                  // to overflow.
                  if (options.autoResize && (prop === 'height' || prop === 'maxHeight')) {
                    styles.display = 'flex';
                    styles.flexDirection = 'column';
                    this.$dialogBody.css('overflow', 'scroll');
                  }
                }
              }
            }

            // Apply mapped CSS styles to the modal-content container.
            this.$content.css(styles);

            // Handle deprecated "dialogClass" option by merging it with "classes".
            var classesMap = {
              'ui-dialog': 'modal-content',
              'ui-dialog-titlebar': 'modal-header',
              'ui-dialog-title': 'modal-title',
              'ui-dialog-titlebar-close': 'close',
              'ui-dialog-content': 'modal-body',
              'ui-dialog-buttonpane': 'modal-footer'
            };
            if (options.dialogClass) {
              if (options.classes === void 0) {
                options.classes = {};
              }
              if (options.classes['ui-dialog'] === void 0) {
                options.classes['ui-dialog'] = '';
              }
              var dialogClass = options.classes['ui-dialog'].split(' ');
              dialogClass.push(options.dialogClass);
              options.classes['ui-dialog'] = dialogClass.join(' ');
              delete options.dialogClass;
            }

            // Add jQuery UI classes to elements in case developers target them
            // in callbacks.
            for (var k in classesMap) {
              this.$element.find('.' + classesMap[k]).addClass(k);
            }

            // Bind events.
            var events = [
              'beforeClose', 'close',
              'create',
              'drag', 'dragStart', 'dragStop',
              'focus',
              'open',
              'resize', 'resizeStart', 'resizeStop'
            ];
            for (i = 0, l = events.length; i < l; i++) {
              var event = events[i].toLowerCase();
              if (options[event] === void 0 || typeof options[event] !== 'function') continue;
              this.$element.on('dialog' + event, options[event]);
            }

            // Support title attribute on the modal.
            var title;
            if ((options.title === null || options.title === void 0) && (title = this.$element.attr('title'))) {
              options.title = title;
            }

            // Handle the reset of the options.
            for (var name in options) {
              if (!options.hasOwnProperty(name) || options[name] === void 0) continue;

              switch (name) {
                case 'appendTo':
                  Bootstrap.unsupported('option', name, options.appendTo);
                  break;

                case 'autoOpen':
                  mappedOptions.show = !!options.autoOpen;
                  break;

                // This is really a drupal.dialog option, not jQuery UI.
                case 'autoResize':
                  dialogOptions.autoResize = !!options.autoResize;
                  break;

                case 'buttons':
                  dialogOptions.buttons = options.buttons;
                  break;

                case 'classes':
                  dialogOptions.classes = options.classes;
                  for (var key in options.classes) {
                    if (options.classes.hasOwnProperty(key) && classesMap[key] !== void 0) {
                      // Run through Attributes to sanitize classes.
                      var attributes = Attributes.create().addClass(options.classes[key]).toPlainObject();
                      var selector = '.' + classesMap[key];
                      this.$element.find(selector).addClass(attributes['class']);
                    }
                  }
                  break;

                case 'closeOnEscape':
                  dialogOptions.closeOnEscape = options.closeOnEscape;
                  mappedOptions.keyboard = !!options.closeOnEscape;
                  this.$close[options.closeOnEscape ? 'show' : 'hide']();
                  if (!options.closeOnEscape && options.modal) {
                    mappedOptions.backdrop = options.modal = 'static';
                  }
                  break;

                case 'closeText':
                  Bootstrap.unsupported('option', name, options.closeText);
                  break;

                case 'draggable':
                  dialogOptions.draggable = options.draggable;
                  this.$content
                    .draggable({
                      handle: '.modal-header',
                      drag: relayEvent(this.$element, 'dialogdrag'),
                      start: relayEvent(this.$element, 'dialogdragstart'),
                      end: relayEvent(this.$element, 'dialogdragend')
                    })
                    .draggable(options.draggable ? 'enable' : 'disable');
                  break;

                case 'hide':
                  if (options.hide === false || options.hide === true) {
                    this.$element[options.hide ? 'addClass' : 'removeClass']('fade');
                    mappedOptions.animation = options.hide;
                  }
                  else {
                    Bootstrap.unsupported('option', name + ' (complex animation)', options.hide);
                  }
                  break;

                case 'modal':
                  mappedOptions.backdrop = options.modal;
                  dialogOptions.modal = !!options.modal;

                  // If not a modal and no initial position, center it.
                  if (!options.modal && !options.position) {
                    this.position({ my: 'center', of: window });
                  }
                  break;

                case 'position':
                  dialogOptions.position = options.position;
                  this.position(options.position);
                  break;

                // Resizable support (must initialize first).
                case 'resizable':
                  dialogOptions.resizeable = options.resizable;
                  this.$content
                    .resizable({
                      resize: relayEvent(this.$element, 'dialogresize'),
                      start: relayEvent(this.$element, 'dialogresizestart'),
                      end: relayEvent(this.$element, 'dialogresizeend')
                    })
                    .resizable(options.resizable ? 'enable' : 'disable');
                  break;

                case 'show':
                  if (options.show === false || options.show === true) {
                    this.$element[options.show ? 'addClass' : 'removeClass']('fade');
                    mappedOptions.animation = options.show;
                  }
                  else {
                    Bootstrap.unsupported('option', name + ' (complex animation)', options.show);
                  }
                  break;

                case 'title':
                  dialogOptions.title = options.title;
                  this.$dialog.find('.modal-title').text(options.title);
                  break;

              }
            }

            // Add the supported dialog options to the mapped options.
            mappedOptions.dialogOptions = dialogOptions;

            return mappedOptions;
          },

          /**
           * Handler for $.fn.dialog('moveToTop').
           */
          moveToTop: function () {
            Bootstrap.unsupported('method', 'moveToTop', arguments);
          },

          /**
           * Handler for $.fn.dialog('option').
           */
          option: function () {
            var clone = {options: $.extend({}, this.options)};

            // Apply the parent option method to the clone of current options.
            this.super.apply(clone, arguments);

            // Merge in the cloned mapped options.
            $.extend(true, this.options, this.mapDialogOptions(clone.options));

            // Update buttons.
            this.createButtons();
          },

          position: function(position) {
            // Reset modal styling.
            this.$element.css({
              bottom: 'initial',
              overflow: 'visible',
              right: 'initial'
            });

            // Position the modal.
            this.$element.position(position);
          },

          /**
           * Handler for $.fn.dialog('open').
           */
          open: function () {
            this.show.apply(this, arguments);
          },

          /**
           * Handler for $.fn.dialog('widget').
           */
          widget: function () {
            return this.$element;
          }
        }
      };
    });

    /**
     * Extend Drupal theming functions.
     */
    $.extend(Drupal.theme, /** @lend Drupal.theme */ {

      /**
       * Renders a jQuery UI Dialog compatible button element.
       *
       * @param {Object} button
       *   The button object passed in the dialog options.
       *
       * @return {String}
       *   The modal dialog button markup.
       *
       * @see http://api.jqueryui.com/dialog/#option-buttons
       * @see http://api.jqueryui.com/button/
       */
      bootstrapModalDialogButton: function (button) {
        var attributes = Attributes.create();

        var icon = '';
        var iconPosition = button.iconPosition || 'beginning';
        iconPosition = (iconPosition === 'end' && !rtl) || (iconPosition === 'beginning' && rtl) ? 'after' : 'before';

        // Handle Bootstrap icons differently.
        if (button.bootstrapIcon) {
          icon = Drupal.theme('icon', 'bootstrap', button.icon);
        }
        // Otherwise, assume it's a jQuery UI icon.
        // @todo Map jQuery UI icons to Bootstrap icons?
        else if (button.icon) {
          var iconAttributes = Attributes.create()
            .addClass(['ui-icon', button.icon])
            .set('aria-hidden', 'true');
          icon = '<span' + iconAttributes + '></span>';
        }

        // Label. Note: jQuery UI dialog has an inconsistency where it uses
        // "text" instead of "label", so both need to be supported.
        var value = button.label || button.text;

        // Show/hide label.
        if (icon && ((button.showLabel !== void 0 && !button.showLabel) || (button.text !== void 0 && !button.text))) {
          value = '<span' + Attributes.create().addClass('sr-only') + '>' + value + '</span>';
        }
        attributes.set('value', iconPosition === 'before' ? icon + value : value + icon);

        // Handle disabled.
        attributes[button.disabled ? 'set' :'remove']('disabled', 'disabled');

        if (button.classes) {
          attributes.addClass(Object.keys(button.classes).map(function(key) { return button.classes[key]; }));
        }
        if (button['class']) {
          attributes.addClass(button['class']);
        }
        if (button.primary) {
          attributes.addClass('btn-primary');
        }

        return Drupal.theme('button', attributes);
      }

    });

  });


})(window.jQuery, window.Drupal, window.Drupal.bootstrap, window.Attributes, window.drupalSettings);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  drupalSettings.dialog = {
    autoOpen: true,
    dialogClass: '',

    buttonClass: 'button',
    buttonPrimaryClass: 'button--primary',
    close: function close(event) {
      Drupal.dialog(event.target).close();
      Drupal.detachBehaviors(event.target, null, 'unload');
    }
  };

  Drupal.dialog = function (element, options) {
    var undef = void 0;
    var $element = $(element);
    var dialog = {
      open: false,
      returnValue: undef
    };

    function openDialog(settings) {
      settings = $.extend({}, drupalSettings.dialog, options, settings);

      $(window).trigger('dialog:beforecreate', [dialog, $element, settings]);
      $element.dialog(settings);
      dialog.open = true;
      $(window).trigger('dialog:aftercreate', [dialog, $element, settings]);
    }

    function closeDialog(value) {
      $(window).trigger('dialog:beforeclose', [dialog, $element]);
      $element.dialog('close');
      dialog.returnValue = value;
      dialog.open = false;
      $(window).trigger('dialog:afterclose', [dialog, $element]);
    }

    dialog.show = function () {
      openDialog({ modal: false });
    };
    dialog.showModal = function () {
      openDialog({ modal: true });
    };
    dialog.close = closeDialog;

    return dialog;
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings, debounce, displace) {
  drupalSettings.dialog = $.extend({ autoResize: true, maxHeight: '95%' }, drupalSettings.dialog);

  function resetPosition(options) {
    var offsets = displace.offsets;
    var left = offsets.left - offsets.right;
    var top = offsets.top - offsets.bottom;

    var leftString = (left > 0 ? '+' : '-') + Math.abs(Math.round(left / 2)) + 'px';
    var topString = (top > 0 ? '+' : '-') + Math.abs(Math.round(top / 2)) + 'px';
    options.position = {
      my: 'center' + (left !== 0 ? leftString : '') + ' center' + (top !== 0 ? topString : ''),
      of: window
    };
    return options;
  }

  function resetSize(event) {
    var positionOptions = ['width', 'height', 'minWidth', 'minHeight', 'maxHeight', 'maxWidth', 'position'];
    var adjustedOptions = {};
    var windowHeight = $(window).height();
    var option = void 0;
    var optionValue = void 0;
    var adjustedValue = void 0;
    for (var n = 0; n < positionOptions.length; n++) {
      option = positionOptions[n];
      optionValue = event.data.settings[option];
      if (optionValue) {
        if (typeof optionValue === 'string' && /%$/.test(optionValue) && /height/i.test(option)) {
          windowHeight -= displace.offsets.top + displace.offsets.bottom;
          adjustedValue = parseInt(0.01 * parseInt(optionValue, 10) * windowHeight, 10);

          if (option === 'height' && event.data.$element.parent().outerHeight() < adjustedValue) {
            adjustedValue = 'auto';
          }
          adjustedOptions[option] = adjustedValue;
        }
      }
    }

    if (!event.data.settings.modal) {
      adjustedOptions = resetPosition(adjustedOptions);
    }
    event.data.$element.dialog('option', adjustedOptions).trigger('dialogContentResize');
  }

  $(window).on({
    'dialog:aftercreate': function dialogAftercreate(event, dialog, $element, settings) {
      var autoResize = debounce(resetSize, 20);
      var eventData = { settings: settings, $element: $element };
      if (settings.autoResize === true || settings.autoResize === 'true') {
        $element.dialog('option', { resizable: false, draggable: false }).dialog('widget').css('position', 'fixed');
        $(window).on('resize.dialogResize scroll.dialogResize', eventData, autoResize).trigger('resize.dialogResize');
        $(document).on('drupalViewportOffsetChange.dialogResize', eventData, autoResize);
      }
    },
    'dialog:beforeclose': function dialogBeforeclose(event, dialog, $element) {
      $(window).off('.dialogResize');
      $(document).off('.dialogResize');
    }
  });
})(jQuery, Drupal, drupalSettings, Drupal.debounce, Drupal.displace);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, _, Backbone, Drupal, drupalSettings, JSON, storage) {
  var options = $.extend(drupalSettings.quickedit, {
    strings: {
      quickEdit: Drupal.t('Quick edit')
    }
  });

  var fieldsMetadataQueue = [];

  var fieldsAvailableQueue = [];

  var contextualLinksQueue = [];

  var entityInstancesTracker = {};

  function initQuickEdit(bodyElement) {
    Drupal.quickedit.collections.entities = new Drupal.quickedit.EntityCollection();
    Drupal.quickedit.collections.fields = new Drupal.quickedit.FieldCollection();

    Drupal.quickedit.app = new Drupal.quickedit.AppView({
      el: bodyElement,
      model: new Drupal.quickedit.AppModel(),
      entitiesCollection: Drupal.quickedit.collections.entities,
      fieldsCollection: Drupal.quickedit.collections.fields
    });
  }

  function processEntity(entityElement) {
    var entityID = entityElement.getAttribute('data-quickedit-entity-id');
    if (!entityInstancesTracker.hasOwnProperty(entityID)) {
      entityInstancesTracker[entityID] = 0;
    } else {
      entityInstancesTracker[entityID]++;
    }

    var entityInstanceID = entityInstancesTracker[entityID];
    entityElement.setAttribute('data-quickedit-entity-instance-id', entityInstanceID);
  }

  function initializeField(fieldElement, fieldID, entityID, entityInstanceID) {
    var entity = Drupal.quickedit.collections.entities.findWhere({
      entityID: entityID,
      entityInstanceID: entityInstanceID
    });

    $(fieldElement).addClass('quickedit-field');

    var field = new Drupal.quickedit.FieldModel({
      el: fieldElement,
      fieldID: fieldID,
      id: fieldID + '[' + entity.get('entityInstanceID') + ']',
      entity: entity,
      metadata: Drupal.quickedit.metadata.get(fieldID),
      acceptStateChange: _.bind(Drupal.quickedit.app.acceptEditorStateChange, Drupal.quickedit.app)
    });

    Drupal.quickedit.collections.fields.add(field);
  }

  function loadMissingEditors(callback) {
    var loadedEditors = _.keys(Drupal.quickedit.editors);
    var missingEditors = [];
    Drupal.quickedit.collections.fields.each(function (fieldModel) {
      var metadata = Drupal.quickedit.metadata.get(fieldModel.get('fieldID'));
      if (metadata.access && _.indexOf(loadedEditors, metadata.editor) === -1) {
        missingEditors.push(metadata.editor);

        Drupal.quickedit.editors[metadata.editor] = false;
      }
    });
    missingEditors = _.uniq(missingEditors);
    if (missingEditors.length === 0) {
      callback();
      return;
    }

    var loadEditorsAjax = Drupal.ajax({
      url: Drupal.url('quickedit/attachments'),
      submit: { 'editors[]': missingEditors }
    });

    var realInsert = Drupal.AjaxCommands.prototype.insert;
    loadEditorsAjax.commands.insert = function (ajax, response, status) {
      _.defer(callback);
      realInsert(ajax, response, status);
    };

    loadEditorsAjax.execute();
  }

  function initializeEntityContextualLink(contextualLink) {
    var metadata = Drupal.quickedit.metadata;

    function hasFieldWithPermission(fieldIDs) {
      for (var i = 0; i < fieldIDs.length; i++) {
        var fieldID = fieldIDs[i];
        if (metadata.get(fieldID, 'access') === true) {
          return true;
        }
      }
      return false;
    }

    function allMetadataExists(fieldIDs) {
      return fieldIDs.length === metadata.intersection(fieldIDs).length;
    }

    var fields = _.where(fieldsAvailableQueue, {
      entityID: contextualLink.entityID,
      entityInstanceID: contextualLink.entityInstanceID
    });
    var fieldIDs = _.pluck(fields, 'fieldID');

    if (fieldIDs.length === 0) {
      return false;
    }

    if (hasFieldWithPermission(fieldIDs)) {
      var entityModel = new Drupal.quickedit.EntityModel({
        el: contextualLink.region,
        entityID: contextualLink.entityID,
        entityInstanceID: contextualLink.entityInstanceID,
        id: contextualLink.entityID + '[' + contextualLink.entityInstanceID + ']',
        label: Drupal.quickedit.metadata.get(contextualLink.entityID, 'label')
      });
      Drupal.quickedit.collections.entities.add(entityModel);

      var entityDecorationView = new Drupal.quickedit.EntityDecorationView({
        el: contextualLink.region,
        model: entityModel
      });
      entityModel.set('entityDecorationView', entityDecorationView);

      _.each(fields, function (field) {
        initializeField(field.el, field.fieldID, contextualLink.entityID, contextualLink.entityInstanceID);
      });
      fieldsAvailableQueue = _.difference(fieldsAvailableQueue, fields);

      var initContextualLink = _.once(function () {
        var $links = $(contextualLink.el).find('.contextual-links');
        var contextualLinkView = new Drupal.quickedit.ContextualLinkView($.extend({
          el: $('<li class="quickedit"><a href="" role="button" aria-pressed="false"></a></li>').prependTo($links),
          model: entityModel,
          appModel: Drupal.quickedit.app.model
        }, options));
        entityModel.set('contextualLinkView', contextualLinkView);
      });

      loadMissingEditors(initContextualLink);

      return true;
    }

    if (allMetadataExists(fieldIDs)) {
      return true;
    }

    return false;
  }

  function extractEntityID(fieldID) {
    return fieldID.split('/').slice(0, 2).join('/');
  }

  function processField(fieldElement) {
    var metadata = Drupal.quickedit.metadata;
    var fieldID = fieldElement.getAttribute('data-quickedit-field-id');
    var entityID = extractEntityID(fieldID);

    var entityElementSelector = '[data-quickedit-entity-id="' + entityID + '"]';
    var $entityElement = $(entityElementSelector);

    if (!$entityElement.length) {
      throw new Error('Quick Edit could not associate the rendered entity field markup (with [data-quickedit-field-id="' + fieldID + '"]) with the corresponding rendered entity markup: no parent DOM node found with [data-quickedit-entity-id="' + entityID + '"]. This is typically caused by the theme\'s template for this entity type forgetting to print the attributes.');
    }
    var entityElement = $(fieldElement).closest($entityElement);

    if (entityElement.length === 0) {
      var $lowestCommonParent = $entityElement.parents().has(fieldElement).first();
      entityElement = $lowestCommonParent.find($entityElement);
    }
    var entityInstanceID = entityElement.get(0).getAttribute('data-quickedit-entity-instance-id');

    if (!metadata.has(fieldID)) {
      fieldsMetadataQueue.push({
        el: fieldElement,
        fieldID: fieldID,
        entityID: entityID,
        entityInstanceID: entityInstanceID
      });
      return;
    }

    if (metadata.get(fieldID, 'access') !== true) {
      return;
    }

    if (Drupal.quickedit.collections.entities.findWhere({
      entityID: entityID,
      entityInstanceID: entityInstanceID
    })) {
      initializeField(fieldElement, fieldID, entityID, entityInstanceID);
    } else {
        fieldsAvailableQueue.push({
          el: fieldElement,
          fieldID: fieldID,
          entityID: entityID,
          entityInstanceID: entityInstanceID
        });
      }
  }

  function deleteContainedModelsAndQueues($context) {
    $context.find('[data-quickedit-entity-id]').addBack('[data-quickedit-entity-id]').each(function (index, entityElement) {
      var entityModel = Drupal.quickedit.collections.entities.findWhere({
        el: entityElement
      });
      if (entityModel) {
        var contextualLinkView = entityModel.get('contextualLinkView');
        contextualLinkView.undelegateEvents();
        contextualLinkView.remove();

        entityModel.get('entityDecorationView').remove();

        entityModel.destroy();
      }

      function hasOtherRegion(contextualLink) {
        return contextualLink.region !== entityElement;
      }

      contextualLinksQueue = _.filter(contextualLinksQueue, hasOtherRegion);
    });

    $context.find('[data-quickedit-field-id]').addBack('[data-quickedit-field-id]').each(function (index, fieldElement) {
      Drupal.quickedit.collections.fields.chain().filter(function (fieldModel) {
        return fieldModel.get('el') === fieldElement;
      }).invoke('destroy');

      function hasOtherFieldElement(field) {
        return field.el !== fieldElement;
      }

      fieldsMetadataQueue = _.filter(fieldsMetadataQueue, hasOtherFieldElement);
      fieldsAvailableQueue = _.filter(fieldsAvailableQueue, hasOtherFieldElement);
    });
  }

  function fetchMissingMetadata(callback) {
    if (fieldsMetadataQueue.length) {
      var fieldIDs = _.pluck(fieldsMetadataQueue, 'fieldID');
      var fieldElementsWithoutMetadata = _.pluck(fieldsMetadataQueue, 'el');
      var entityIDs = _.uniq(_.pluck(fieldsMetadataQueue, 'entityID'), true);

      entityIDs = _.difference(entityIDs, Drupal.quickedit.metadata.intersection(entityIDs));
      fieldsMetadataQueue = [];

      $.ajax({
        url: Drupal.url('quickedit/metadata'),
        type: 'POST',
        data: {
          'fields[]': fieldIDs,
          'entities[]': entityIDs
        },
        dataType: 'json',
        success: function success(results) {
          _.each(results, function (fieldMetadata, fieldID) {
            Drupal.quickedit.metadata.add(fieldID, fieldMetadata);
          });

          callback(fieldElementsWithoutMetadata);
        }
      });
    }
  }

  Drupal.behaviors.quickedit = {
    attach: function attach(context) {
      $('body').once('quickedit-init').each(initQuickEdit);

      var $fields = $(context).find('[data-quickedit-field-id]').once('quickedit');
      if ($fields.length === 0) {
        return;
      }

      $(context).find('[data-quickedit-entity-id]').once('quickedit').each(function (index, entityElement) {
        processEntity(entityElement);
      });

      $fields.each(function (index, fieldElement) {
        processField(fieldElement);
      });

      contextualLinksQueue = _.filter(contextualLinksQueue, function (contextualLink) {
        return !initializeEntityContextualLink(contextualLink);
      });

      fetchMissingMetadata(function (fieldElementsWithFreshMetadata) {
        _.each(fieldElementsWithFreshMetadata, processField);

        contextualLinksQueue = _.filter(contextualLinksQueue, function (contextualLink) {
          return !initializeEntityContextualLink(contextualLink);
        });
      });
    },
    detach: function detach(context, settings, trigger) {
      if (trigger === 'unload') {
        deleteContainedModelsAndQueues($(context));
      }
    }
  };

  Drupal.quickedit = {
    app: null,

    collections: {
      entities: null,

      fields: null
    },

    editors: {},

    metadata: {
      has: function has(fieldID) {
        return storage.getItem(this._prefixFieldID(fieldID)) !== null;
      },
      add: function add(fieldID, metadata) {
        storage.setItem(this._prefixFieldID(fieldID), JSON.stringify(metadata));
      },
      get: function get(fieldID, key) {
        var metadata = JSON.parse(storage.getItem(this._prefixFieldID(fieldID)));
        return typeof key === 'undefined' ? metadata : metadata[key];
      },
      _prefixFieldID: function _prefixFieldID(fieldID) {
        return 'Drupal.quickedit.metadata.' + fieldID;
      },
      _unprefixFieldID: function _unprefixFieldID(fieldID) {
        return fieldID.substring(26);
      },
      intersection: function intersection(fieldIDs) {
        var prefixedFieldIDs = _.map(fieldIDs, this._prefixFieldID);
        var intersection = _.intersection(prefixedFieldIDs, _.keys(sessionStorage));
        return _.map(intersection, this._unprefixFieldID);
      }
    }
  };

  var permissionsHashKey = Drupal.quickedit.metadata._prefixFieldID('permissionsHash');
  var permissionsHashValue = storage.getItem(permissionsHashKey);
  var permissionsHash = drupalSettings.user.permissionsHash;
  if (permissionsHashValue !== permissionsHash) {
    if (typeof permissionsHash === 'string') {
      _.chain(storage).keys().each(function (key) {
        if (key.substring(0, 26) === 'Drupal.quickedit.metadata.') {
          storage.removeItem(key);
        }
      });
    }
    storage.setItem(permissionsHashKey, permissionsHash);
  }

  $(document).on('drupalContextualLinkAdded', function (event, data) {
    if (data.$region.is('[data-quickedit-entity-id]')) {
      if (!data.$region.is('[data-quickedit-entity-instance-id]')) {
        data.$region.once('quickedit');
        processEntity(data.$region.get(0));
      }
      var contextualLink = {
        entityID: data.$region.attr('data-quickedit-entity-id'),
        entityInstanceID: data.$region.attr('data-quickedit-entity-instance-id'),
        el: data.$el[0],
        region: data.$region[0]
      };

      if (!initializeEntityContextualLink(contextualLink)) {
        contextualLinksQueue.push(contextualLink);
      }
    }
  });
})(jQuery, _, Backbone, Drupal, drupalSettings, window.JSON, window.sessionStorage);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal) {
  Drupal.quickedit.util = Drupal.quickedit.util || {};

  Drupal.quickedit.util.constants = {};

  Drupal.quickedit.util.constants.transitionEnd = 'transitionEnd.quickedit webkitTransitionEnd.quickedit transitionend.quickedit msTransitionEnd.quickedit oTransitionEnd.quickedit';

  Drupal.quickedit.util.buildUrl = function (id, urlFormat) {
    var parts = id.split('/');
    return Drupal.formatString(decodeURIComponent(urlFormat), {
      '!entity_type': parts[0],
      '!id': parts[1],
      '!field_name': parts[2],
      '!langcode': parts[3],
      '!view_mode': parts[4]
    });
  };

  Drupal.quickedit.util.networkErrorModal = function (title, message) {
    var $message = $('<div>' + message + '</div>');
    var networkErrorModal = Drupal.dialog($message.get(0), {
      title: title,
      dialogClass: 'quickedit-network-error',
      buttons: [{
        text: Drupal.t('OK'),
        click: function click() {
          networkErrorModal.close();
        },

        primary: true
      }],
      create: function create() {
        $(this).parent().find('.ui-dialog-titlebar-close').remove();
      },
      close: function close(event) {
        $(event.target).remove();
      }
    });
    networkErrorModal.showModal();
  };

  Drupal.quickedit.util.form = {
    load: function load(options, callback) {
      var fieldID = options.fieldID;

      var formLoaderAjax = Drupal.ajax({
        url: Drupal.quickedit.util.buildUrl(fieldID, Drupal.url('quickedit/form/!entity_type/!id/!field_name/!langcode/!view_mode')),
        submit: {
          nocssjs: options.nocssjs,
          reset: options.reset
        },
        error: function error(xhr, url) {
          var fieldLabel = Drupal.quickedit.metadata.get(fieldID, 'label');
          var message = Drupal.t('Could not load the form for <q>@field-label</q>, either due to a website problem or a network connection problem.<br>Please try again.', { '@field-label': fieldLabel });
          Drupal.quickedit.util.networkErrorModal(Drupal.t('Network problem!'), message);

          var fieldModel = Drupal.quickedit.app.model.get('activeField');
          fieldModel.set('state', 'candidate');
        }
      });

      formLoaderAjax.commands.quickeditFieldForm = function (ajax, response, status) {
        callback(response.data, ajax);
        Drupal.ajax.instances[this.instanceIndex] = null;
      };

      formLoaderAjax.execute();
    },
    ajaxifySaving: function ajaxifySaving(options, $submit) {
      var settings = {
        url: $submit.closest('form').attr('action'),
        setClick: true,
        event: 'click.quickedit',
        progress: false,
        submit: {
          nocssjs: options.nocssjs,
          other_view_modes: options.other_view_modes
        },

        success: function success(response, status) {
          var _this = this;

          Object.keys(response || {}).forEach(function (i) {
            if (response[i].command && _this.commands[response[i].command]) {
              _this.commands[response[i].command](_this, response[i], status);
            }
          });
        },

        base: $submit.attr('id'),
        element: $submit[0]
      };

      return Drupal.ajax(settings);
    },
    unajaxifySaving: function unajaxifySaving(ajax) {
      $(ajax.element).off('click.quickedit');
    }
  };
})(jQuery, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

(function (Drupal, Backbone) {
  Drupal.quickedit.BaseModel = Backbone.Model.extend({
    initialize: function initialize(options) {
      this.__initialized = true;
      return Backbone.Model.prototype.initialize.call(this, options);
    },
    set: function set(key, val, options) {
      if (this.__initialized) {
        if ((typeof key === 'undefined' ? 'undefined' : _typeof(key)) === 'object') {
          key.validate = true;
        } else {
          if (!options) {
            options = {};
          }
          options.validate = true;
        }
      }
      return Backbone.Model.prototype.set.call(this, key, val, options);
    }
  });
})(Drupal, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.quickedit.AppModel = Backbone.Model.extend({
    defaults: {
      highlightedField: null,

      activeField: null,

      activeModal: null
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (_, $, Backbone, Drupal) {
  Drupal.quickedit.EntityModel = Drupal.quickedit.BaseModel.extend({
    defaults: {
      el: null,

      entityID: null,

      entityInstanceID: null,

      id: null,

      label: null,

      fields: null,

      isActive: false,

      inTempStore: false,

      isDirty: false,

      isCommitting: false,

      state: 'closed',

      fieldsInTempStore: [],

      reload: false
    },

    initialize: function initialize() {
      this.set('fields', new Drupal.quickedit.FieldCollection());

      this.listenTo(this, 'change:state', this.stateChange);

      this.listenTo(this.get('fields'), 'change:state', this.fieldStateChange);

      Drupal.quickedit.BaseModel.prototype.initialize.call(this);
    },
    stateChange: function stateChange(entityModel, state, options) {
      var to = state;
      switch (to) {
        case 'closed':
          this.set({
            isActive: false,
            inTempStore: false,
            isDirty: false
          });
          break;

        case 'launching':
          break;

        case 'opening':
          entityModel.get('fields').each(function (fieldModel) {
            fieldModel.set('state', 'candidate', options);
          });
          break;

        case 'opened':
          this.set('isActive', true);
          break;

        case 'committing':
          {
            var fields = this.get('fields');

            fields.chain().filter(function (fieldModel) {
              return _.intersection([fieldModel.get('state')], ['active']).length;
            }).each(function (fieldModel) {
              fieldModel.set('state', 'candidate');
            });

            fields.chain().filter(function (fieldModel) {
              return _.intersection([fieldModel.get('state')], Drupal.quickedit.app.changedFieldStates).length;
            }).each(function (fieldModel) {
              fieldModel.set('state', 'saving');
            });
            break;
          }

        case 'deactivating':
          {
            var changedFields = this.get('fields').filter(function (fieldModel) {
              return _.intersection([fieldModel.get('state')], ['changed', 'invalid']).length;
            });

            if ((changedFields.length || this.get('fieldsInTempStore').length) && !options.saved && !options.confirmed) {
              this.set('state', 'opened', { confirming: true });

              _.defer(function () {
                Drupal.quickedit.app.confirmEntityDeactivation(entityModel);
              });
            } else {
              var invalidFields = this.get('fields').filter(function (fieldModel) {
                return _.intersection([fieldModel.get('state')], ['invalid']).length;
              });

              entityModel.set('reload', this.get('fieldsInTempStore').length || invalidFields.length);

              entityModel.get('fields').each(function (fieldModel) {
                if (_.intersection([fieldModel.get('state')], ['candidate', 'highlighted']).length) {
                  fieldModel.trigger('change:state', fieldModel, fieldModel.get('state'), options);
                } else {
                  fieldModel.set('state', 'candidate', options);
                }
              });
            }
            break;
          }

        case 'closing':
          options.reason = 'stop';
          this.get('fields').each(function (fieldModel) {
            fieldModel.set({
              inTempStore: false,
              state: 'inactive'
            }, options);
          });
          break;
      }
    },
    _updateInTempStoreAttributes: function _updateInTempStoreAttributes(entityModel, fieldModel) {
      var current = fieldModel.get('state');
      var previous = fieldModel.previous('state');
      var fieldsInTempStore = entityModel.get('fieldsInTempStore');

      if (current === 'saved') {
        entityModel.set('inTempStore', true);

        fieldModel.set('inTempStore', true);

        fieldsInTempStore.push(fieldModel.get('fieldID'));
        fieldsInTempStore = _.uniq(fieldsInTempStore);
        entityModel.set('fieldsInTempStore', fieldsInTempStore);
      } else if (current === 'candidate' && previous === 'inactive') {
          fieldModel.set('inTempStore', _.intersection([fieldModel.get('fieldID')], fieldsInTempStore).length > 0);
        }
    },
    fieldStateChange: function fieldStateChange(fieldModel, state) {
      var entityModel = this;
      var fieldState = state;

      switch (this.get('state')) {
        case 'closed':
        case 'launching':
          break;

        case 'opening':
          _.defer(function () {
            entityModel.set('state', 'opened', {
              'accept-field-states': Drupal.quickedit.app.readyFieldStates
            });
          });
          break;

        case 'opened':
          if (fieldState === 'changed') {
            entityModel.set('isDirty', true);
          } else {
            this._updateInTempStoreAttributes(entityModel, fieldModel);
          }
          break;

        case 'committing':
          {
            if (fieldState === 'invalid') {
              _.defer(function () {
                entityModel.set('state', 'opened', { reason: 'invalid' });
              });
            } else {
              this._updateInTempStoreAttributes(entityModel, fieldModel);
            }

            var options = {
              'accept-field-states': Drupal.quickedit.app.readyFieldStates
            };
            if (entityModel.set('isCommitting', true, options)) {
              entityModel.save({
                success: function success() {
                  entityModel.set({
                    state: 'deactivating',
                    isCommitting: false
                  }, { saved: true });
                },
                error: function error() {
                  entityModel.set('isCommitting', false);

                  entityModel.set('state', 'opened', {
                    reason: 'networkerror'
                  });

                  var message = Drupal.t('Your changes to <q>@entity-title</q> could not be saved, either due to a website problem or a network connection problem.<br>Please try again.', { '@entity-title': entityModel.get('label') });
                  Drupal.quickedit.util.networkErrorModal(Drupal.t('Network problem!'), message);
                }
              });
            }
            break;
          }

        case 'deactivating':
          _.defer(function () {
            entityModel.set('state', 'closing', {
              'accept-field-states': Drupal.quickedit.app.readyFieldStates
            });
          });
          break;

        case 'closing':
          _.defer(function () {
            entityModel.set('state', 'closed', {
              'accept-field-states': ['inactive']
            });
          });
          break;
      }
    },
    save: function save(options) {
      var entityModel = this;

      var entitySaverAjax = Drupal.ajax({
        url: Drupal.url('quickedit/entity/' + entityModel.get('entityID')),
        error: function error() {
          options.error.call(entityModel);
        }
      });

      entitySaverAjax.commands.quickeditEntitySaved = function (ajax, response, status) {
        entityModel.get('fields').each(function (fieldModel) {
          fieldModel.set('inTempStore', false);
        });
        entityModel.set('inTempStore', false);
        entityModel.set('fieldsInTempStore', []);

        if (options.success) {
          options.success.call(entityModel);
        }
      };

      entitySaverAjax.execute();
    },
    validate: function validate(attrs, options) {
      var acceptedFieldStates = options['accept-field-states'] || [];

      var currentState = this.get('state');
      var nextState = attrs.state;
      if (currentState !== nextState) {
        if (_.indexOf(this.constructor.states, nextState) === -1) {
          return '"' + nextState + '" is an invalid state';
        }

        if (!this._acceptStateChange(currentState, nextState, options)) {
          return 'state change not accepted';
        }

        if (!this._fieldsHaveAcceptableStates(acceptedFieldStates)) {
          return 'state change not accepted because fields are not in acceptable state';
        }
      }

      var currentIsCommitting = this.get('isCommitting');
      var nextIsCommitting = attrs.isCommitting;
      if (currentIsCommitting === false && nextIsCommitting === true) {
        if (!this._fieldsHaveAcceptableStates(acceptedFieldStates)) {
          return 'isCommitting change not accepted because fields are not in acceptable state';
        }
      } else if (currentIsCommitting === true && nextIsCommitting === true) {
        return 'isCommitting is a mutex, hence only changes are allowed';
      }
    },
    _acceptStateChange: function _acceptStateChange(from, to, context) {
      var accept = true;

      if (!this.constructor.followsStateSequence(from, to)) {
        accept = false;

        if (from === 'closing' && to === 'closed') {
          accept = true;
        } else if (from === 'committing' && to === 'opened' && context.reason && (context.reason === 'invalid' || context.reason === 'networkerror')) {
            accept = true;
          } else if (from === 'deactivating' && to === 'opened' && context.confirming) {
              accept = true;
            } else if (from === 'opened' && to === 'deactivating' && context.confirmed) {
                accept = true;
              }
      }

      return accept;
    },
    _fieldsHaveAcceptableStates: function _fieldsHaveAcceptableStates(acceptedFieldStates) {
      var accept = true;

      if (acceptedFieldStates.length > 0) {
        var fieldStates = this.get('fields').pluck('state') || [];

        if (_.difference(fieldStates, acceptedFieldStates).length) {
          accept = false;
        }
      }

      return accept;
    },
    destroy: function destroy(options) {
      Drupal.quickedit.BaseModel.prototype.destroy.call(this, options);

      this.stopListening();

      this.get('fields').reset();
    },
    sync: function sync() {}
  }, {
    states: ['closed', 'launching', 'opening', 'opened', 'committing', 'deactivating', 'closing'],

    followsStateSequence: function followsStateSequence(from, to) {
      return _.indexOf(this.states, from) < _.indexOf(this.states, to);
    }
  });

  Drupal.quickedit.EntityCollection = Backbone.Collection.extend({
    model: Drupal.quickedit.EntityModel
  });
})(_, jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (_, Backbone, Drupal) {
  Drupal.quickedit.FieldModel = Drupal.quickedit.BaseModel.extend({
    defaults: {
      el: null,

      fieldID: null,

      id: null,

      entity: null,

      metadata: null,

      acceptStateChange: null,

      logicalFieldID: null,

      state: 'inactive',

      isChanged: false,

      inTempStore: false,

      html: null,

      htmlForOtherViewModes: null
    },

    initialize: function initialize(options) {
      this.set('html', options.el.outerHTML);

      this.get('entity').get('fields').add(this);

      this.set('logicalFieldID', this.get('fieldID').split('/').slice(0, 4).join('/'));

      Drupal.quickedit.BaseModel.prototype.initialize.call(this, options);
    },
    destroy: function destroy(options) {
      if (this.get('state') !== 'inactive') {
        throw new Error('FieldModel cannot be destroyed if it is not inactive state.');
      }
      Drupal.quickedit.BaseModel.prototype.destroy.call(this, options);
    },
    sync: function sync() {},
    validate: function validate(attrs, options) {
      var current = this.get('state');
      var next = attrs.state;
      if (current !== next) {
        if (_.indexOf(this.constructor.states, next) === -1) {
          return '"' + next + '" is an invalid state';
        }

        if (!this.get('acceptStateChange')(current, next, options, this)) {
          return 'state change not accepted';
        }
      }
    },
    getEntityID: function getEntityID() {
      return this.get('fieldID').split('/').slice(0, 2).join('/');
    },
    getViewMode: function getViewMode() {
      return this.get('fieldID').split('/').pop();
    },
    findOtherViewModes: function findOtherViewModes() {
      var currentField = this;
      var otherViewModes = [];
      Drupal.quickedit.collections.fields.where({ logicalFieldID: currentField.get('logicalFieldID') }).forEach(function (field) {
        if (field !== currentField && field.get('fieldID') !== currentField.get('fieldID')) {
          otherViewModes.push(field.getViewMode());
        }
      });
      return otherViewModes;
    }
  }, {
    states: ['inactive', 'candidate', 'highlighted', 'activating', 'active', 'changed', 'saving', 'saved', 'invalid'],

    followsStateSequence: function followsStateSequence(from, to) {
      return _.indexOf(this.states, from) < _.indexOf(this.states, to);
    }
  });

  Drupal.quickedit.FieldCollection = Backbone.Collection.extend({
    model: Drupal.quickedit.FieldModel
  });
})(_, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.quickedit.EditorModel = Backbone.Model.extend({
    defaults: {
      originalValue: null,

      currentValue: null,

      validationErrors: null
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, _, Backbone, Drupal) {
  var reload = false;

  Drupal.quickedit.AppView = Backbone.View.extend({
    initialize: function initialize(options) {
      this.activeFieldStates = ['activating', 'active'];
      this.singleFieldStates = ['highlighted', 'activating', 'active'];
      this.changedFieldStates = ['changed', 'saving', 'saved', 'invalid'];
      this.readyFieldStates = ['candidate', 'highlighted'];

      this.listenTo(options.entitiesCollection, 'change:state', this.appStateChange);
      this.listenTo(options.entitiesCollection, 'change:isActive', this.enforceSingleActiveEntity);

      this.listenTo(options.fieldsCollection, 'change:state', this.editorStateChange);

      this.listenTo(options.fieldsCollection, 'change:html', this.renderUpdatedField);
      this.listenTo(options.fieldsCollection, 'change:html', this.propagateUpdatedField);

      this.listenTo(options.fieldsCollection, 'add', this.rerenderedFieldToCandidate);

      this.listenTo(options.fieldsCollection, 'destroy', this.teardownEditor);
    },
    appStateChange: function appStateChange(entityModel, state) {
      var app = this;
      var entityToolbarView = void 0;
      switch (state) {
        case 'launching':
          reload = false;

          entityToolbarView = new Drupal.quickedit.EntityToolbarView({
            model: entityModel,
            appModel: this.model
          });
          entityModel.toolbarView = entityToolbarView;

          entityModel.get('fields').each(function (fieldModel) {
            app.setupEditor(fieldModel);
          });

          _.defer(function () {
            entityModel.set('state', 'opening');
          });
          break;

        case 'closed':
          entityToolbarView = entityModel.toolbarView;

          entityModel.get('fields').each(function (fieldModel) {
            app.teardownEditor(fieldModel);
          });

          if (entityToolbarView) {
            entityToolbarView.remove();
            delete entityModel.toolbarView;
          }

          if (reload) {
            reload = false;
            window.location.reload();
          }
          break;
      }
    },
    acceptEditorStateChange: function acceptEditorStateChange(from, to, context, fieldModel) {
      var accept = true;

      if (context && (context.reason === 'stop' || context.reason === 'rerender')) {
        if (from === 'candidate' && to === 'inactive') {
          accept = true;
        }
      } else {
          if (!Drupal.quickedit.FieldModel.followsStateSequence(from, to)) {
            accept = false;

            if (_.indexOf(this.activeFieldStates, from) !== -1 && to === 'candidate') {
              accept = true;
            } else if ((from === 'changed' || from === 'invalid') && to === 'candidate') {
                accept = true;
              } else if (from === 'highlighted' && to === 'candidate') {
                  accept = true;
                } else if (from === 'saved' && to === 'candidate') {
                    accept = true;
                  } else if (from === 'invalid' && to === 'saving') {
                      accept = true;
                    } else if (from === 'invalid' && to === 'activating') {
                        accept = true;
                      }
          }

          if (accept) {
            var activeField = void 0;
            var activeFieldState = void 0;

            if ((this.readyFieldStates.indexOf(from) !== -1 || from === 'invalid') && this.activeFieldStates.indexOf(to) !== -1) {
              activeField = this.model.get('activeField');
              if (activeField && activeField !== fieldModel) {
                activeFieldState = activeField.get('state');

                if (this.activeFieldStates.indexOf(activeFieldState) !== -1) {
                  activeField.set('state', 'candidate');
                } else if (activeFieldState === 'changed' || activeFieldState === 'invalid') {
                  activeField.set('state', 'saving');
                }

                if (from === 'invalid') {
                  this.model.set('activeField', fieldModel);
                  accept = false;
                }
              }
            } else if (_.indexOf(this.activeFieldStates, from) !== -1 && to === 'candidate') {
                if (context && context.reason === 'mouseleave') {
                  accept = false;
                }
              } else if ((from === 'changed' || from === 'invalid') && to === 'candidate') {
                  if (context && context.reason === 'mouseleave') {
                    accept = false;
                  } else if (context && context.confirmed) {
                      accept = true;
                    }
                }
          }
        }

      return accept;
    },
    setupEditor: function setupEditor(fieldModel) {
      var entityModel = fieldModel.get('entity');
      var entityToolbarView = entityModel.toolbarView;

      var fieldToolbarRoot = entityToolbarView.getToolbarRoot();

      var editorName = fieldModel.get('metadata').editor;
      var editorModel = new Drupal.quickedit.EditorModel();
      var editorView = new Drupal.quickedit.editors[editorName]({
        el: $(fieldModel.get('el')),
        model: editorModel,
        fieldModel: fieldModel
      });

      var toolbarView = new Drupal.quickedit.FieldToolbarView({
        el: fieldToolbarRoot,
        model: fieldModel,
        $editedElement: $(editorView.getEditedElement()),
        editorView: editorView,
        entityModel: entityModel
      });

      var decorationView = new Drupal.quickedit.FieldDecorationView({
        el: $(editorView.getEditedElement()),
        model: fieldModel,
        editorView: editorView
      });

      fieldModel.editorView = editorView;
      fieldModel.toolbarView = toolbarView;
      fieldModel.decorationView = decorationView;
    },
    teardownEditor: function teardownEditor(fieldModel) {
      if (typeof fieldModel.editorView === 'undefined') {
        return;
      }

      fieldModel.toolbarView.remove();
      delete fieldModel.toolbarView;

      fieldModel.decorationView.remove();
      delete fieldModel.decorationView;

      fieldModel.editorView.remove();
      delete fieldModel.editorView;
    },
    confirmEntityDeactivation: function confirmEntityDeactivation(entityModel) {
      var that = this;
      var discardDialog = void 0;

      function closeDiscardDialog(action) {
        discardDialog.close(action);

        that.model.set('activeModal', null);

        if (action === 'save') {
          entityModel.set('state', 'committing', { confirmed: true });
        } else {
          entityModel.set('state', 'deactivating', { confirmed: true });

          if (entityModel.get('reload')) {
            reload = true;
            entityModel.set('reload', false);
          }
        }
      }

      if (!this.model.get('activeModal')) {
        var $unsavedChanges = $('<div>' + Drupal.t('You have unsaved changes') + '</div>');
        discardDialog = Drupal.dialog($unsavedChanges.get(0), {
          title: Drupal.t('Discard changes?'),
          dialogClass: 'quickedit-discard-modal',
          resizable: false,
          buttons: [{
            text: Drupal.t('Save'),
            click: function click() {
              closeDiscardDialog('save');
            },

            primary: true
          }, {
            text: Drupal.t('Discard changes'),
            click: function click() {
              closeDiscardDialog('discard');
            }
          }],

          closeOnEscape: false,
          create: function create() {
            $(this).parent().find('.ui-dialog-titlebar-close').remove();
          },

          beforeClose: false,
          close: function close(event) {
            $(event.target).remove();
          }
        });
        this.model.set('activeModal', discardDialog);

        discardDialog.showModal();
      }
    },
    editorStateChange: function editorStateChange(fieldModel, state) {
      var from = fieldModel.previous('state');
      var to = state;

      if (_.indexOf(this.singleFieldStates, to) !== -1 && this.model.get('highlightedField') !== fieldModel) {
        this.model.set('highlightedField', fieldModel);
      } else if (this.model.get('highlightedField') === fieldModel && to === 'candidate') {
        this.model.set('highlightedField', null);
      }

      if (_.indexOf(this.activeFieldStates, to) !== -1 && this.model.get('activeField') !== fieldModel) {
        this.model.set('activeField', fieldModel);
      } else if (this.model.get('activeField') === fieldModel && to === 'candidate') {
        if (from === 'changed' || from === 'invalid') {
          fieldModel.editorView.revert();
        }
        this.model.set('activeField', null);
      }
    },
    renderUpdatedField: function renderUpdatedField(fieldModel, html, options) {
      var $fieldWrapper = $(fieldModel.get('el'));
      var $context = $fieldWrapper.parent();

      var renderField = function renderField() {
        fieldModel.destroy();

        $fieldWrapper.replaceWith(html);

        Drupal.attachBehaviors($context.get(0));
      };

      if (!options.propagation) {
        _.defer(function () {
          fieldModel.set('state', 'candidate');

          _.defer(function () {
            fieldModel.set('state', 'inactive', { reason: 'rerender' });

            renderField();
          });
        });
      } else {
        renderField();
      }
    },
    propagateUpdatedField: function propagateUpdatedField(updatedField, html, options) {
      if (options.propagation) {
        return;
      }

      var htmlForOtherViewModes = updatedField.get('htmlForOtherViewModes');
      Drupal.quickedit.collections.fields.where({ logicalFieldID: updatedField.get('logicalFieldID') }).forEach(function (field) {
        if (field === updatedField) {} else if (field.getViewMode() === updatedField.getViewMode()) {
            field.set('html', updatedField.get('html'));
          } else if (field.getViewMode() in htmlForOtherViewModes) {
              field.set('html', htmlForOtherViewModes[field.getViewMode()], {
                propagation: true
              });
            }
      });
    },
    rerenderedFieldToCandidate: function rerenderedFieldToCandidate(fieldModel) {
      var activeEntity = Drupal.quickedit.collections.entities.findWhere({
        isActive: true
      });

      if (!activeEntity) {
        return;
      }

      if (fieldModel.get('entity') === activeEntity) {
        this.setupEditor(fieldModel);
        fieldModel.set('state', 'candidate');
      }
    },
    enforceSingleActiveEntity: function enforceSingleActiveEntity(changedEntityModel) {
      if (changedEntityModel.get('isActive') === false) {
        return;
      }

      changedEntityModel.collection.chain().filter(function (entityModel) {
        return entityModel.get('isActive') === true && entityModel !== changedEntityModel;
      }).each(function (entityModel) {
        entityModel.set('state', 'deactivating');
      });
    }
  });
})(jQuery, _, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal) {
  Drupal.quickedit.FieldDecorationView = Backbone.View.extend({
    _widthAttributeIsEmpty: null,

    events: {
      'mouseenter.quickedit': 'onMouseEnter',
      'mouseleave.quickedit': 'onMouseLeave',
      click: 'onClick',
      'tabIn.quickedit': 'onMouseEnter',
      'tabOut.quickedit': 'onMouseLeave'
    },

    initialize: function initialize(options) {
      this.editorView = options.editorView;

      this.listenTo(this.model, 'change:state', this.stateChange);
      this.listenTo(this.model, 'change:isChanged change:inTempStore', this.renderChanged);
    },
    remove: function remove() {
      this.setElement();
      Backbone.View.prototype.remove.call(this);
    },
    stateChange: function stateChange(model, state) {
      var from = model.previous('state');
      var to = state;
      switch (to) {
        case 'inactive':
          this.undecorate();
          break;

        case 'candidate':
          this.decorate();
          if (from !== 'inactive') {
            this.stopHighlight();
            if (from !== 'highlighted') {
              this.model.set('isChanged', false);
              this.stopEdit();
            }
          }
          this._unpad();
          break;

        case 'highlighted':
          this.startHighlight();
          break;

        case 'activating':
          this.prepareEdit();
          break;

        case 'active':
          if (from !== 'activating') {
            this.prepareEdit();
          }
          if (this.editorView.getQuickEditUISettings().padding) {
            this._pad();
          }
          break;

        case 'changed':
          this.model.set('isChanged', true);
          break;

        case 'saving':
          break;

        case 'saved':
          break;

        case 'invalid':
          break;
      }
    },
    renderChanged: function renderChanged() {
      this.$el.toggleClass('quickedit-changed', this.model.get('isChanged') || this.model.get('inTempStore'));
    },
    onMouseEnter: function onMouseEnter(event) {
      var that = this;
      that.model.set('state', 'highlighted');
      event.stopPropagation();
    },
    onMouseLeave: function onMouseLeave(event) {
      var that = this;
      that.model.set('state', 'candidate', { reason: 'mouseleave' });
      event.stopPropagation();
    },
    onClick: function onClick(event) {
      this.model.set('state', 'activating');
      event.preventDefault();
      event.stopPropagation();
    },
    decorate: function decorate() {
      this.$el.addClass('quickedit-candidate quickedit-editable');
    },
    undecorate: function undecorate() {
      this.$el.removeClass('quickedit-candidate quickedit-editable quickedit-highlighted quickedit-editing');
    },
    startHighlight: function startHighlight() {
      var that = this;

      that.$el.addClass('quickedit-highlighted');
    },
    stopHighlight: function stopHighlight() {
      this.$el.removeClass('quickedit-highlighted');
    },
    prepareEdit: function prepareEdit() {
      this.$el.addClass('quickedit-editing');

      if (this.editorView.getQuickEditUISettings().popup) {
        this.$el.addClass('quickedit-editor-is-popup');
      }
    },
    stopEdit: function stopEdit() {
      this.$el.removeClass('quickedit-highlighted quickedit-editing');

      if (this.editorView.getQuickEditUISettings().popup) {
        this.$el.removeClass('quickedit-editor-is-popup');
      }

      $('.quickedit-candidate').addClass('quickedit-editable');
    },
    _pad: function _pad() {
      if (this.$el.data('quickedit-padded')) {
        return;
      }
      var self = this;

      if (this.$el[0].style.width === '') {
        this._widthAttributeIsEmpty = true;
        this.$el.addClass('quickedit-animate-disable-width').css('width', this.$el.width());
      }

      var posProp = this._getPositionProperties(this.$el);
      setTimeout(function () {
        self.$el.removeClass('quickedit-animate-disable-width');

        self.$el.css({
          position: 'relative',
          top: posProp.top - 5 + 'px',
          left: posProp.left - 5 + 'px',
          'padding-top': posProp['padding-top'] + 5 + 'px',
          'padding-left': posProp['padding-left'] + 5 + 'px',
          'padding-right': posProp['padding-right'] + 5 + 'px',
          'padding-bottom': posProp['padding-bottom'] + 5 + 'px',
          'margin-bottom': posProp['margin-bottom'] - 10 + 'px'
        }).data('quickedit-padded', true);
      }, 0);
    },
    _unpad: function _unpad() {
      if (!this.$el.data('quickedit-padded')) {
        return;
      }
      var self = this;

      if (this._widthAttributeIsEmpty) {
        this.$el.addClass('quickedit-animate-disable-width').css('width', '');
      }

      var posProp = this._getPositionProperties(this.$el);
      setTimeout(function () {
        self.$el.removeClass('quickedit-animate-disable-width');

        self.$el.css({
          position: 'relative',
          top: posProp.top + 5 + 'px',
          left: posProp.left + 5 + 'px',
          'padding-top': posProp['padding-top'] - 5 + 'px',
          'padding-left': posProp['padding-left'] - 5 + 'px',
          'padding-right': posProp['padding-right'] - 5 + 'px',
          'padding-bottom': posProp['padding-bottom'] - 5 + 'px',
          'margin-bottom': posProp['margin-bottom'] + 10 + 'px'
        });
      }, 0);

      this.$el.removeData('quickedit-padded');
    },
    _getPositionProperties: function _getPositionProperties($e) {
      var p = void 0;
      var r = {};
      var props = ['top', 'left', 'bottom', 'right', 'padding-top', 'padding-left', 'padding-right', 'padding-bottom', 'margin-bottom'];

      var propCount = props.length;
      for (var i = 0; i < propCount; i++) {
        p = props[i];
        r[p] = parseInt(this._replaceBlankPosition($e.css(p)), 10);
      }
      return r;
    },
    _replaceBlankPosition: function _replaceBlankPosition(pos) {
      if (pos === 'auto' || !pos) {
        pos = '0px';
      }
      return pos;
    }
  });
})(jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, $, Backbone) {
  Drupal.quickedit.EntityDecorationView = Backbone.View.extend({
    initialize: function initialize() {
      this.listenTo(this.model, 'change', this.render);
    },
    render: function render() {
      this.$el.toggleClass('quickedit-entity-active', this.model.get('isActive'));
    },
    remove: function remove() {
      this.setElement(null);
      Backbone.View.prototype.remove.call(this);
    }
  });
})(Drupal, jQuery, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, _, Backbone, Drupal, debounce) {
  Drupal.quickedit.EntityToolbarView = Backbone.View.extend({
    _fieldToolbarRoot: null,

    events: function events() {
      var map = {
        'click button.action-save': 'onClickSave',
        'click button.action-cancel': 'onClickCancel',
        mouseenter: 'onMouseenter'
      };
      return map;
    },
    initialize: function initialize(options) {
      var that = this;
      this.appModel = options.appModel;
      this.$entity = $(this.model.get('el'));

      this.listenTo(this.model, 'change:isActive change:isDirty change:state', this.render);

      this.listenTo(this.appModel, 'change:highlightedField change:activeField', this.render);

      this.listenTo(this.model.get('fields'), 'change:state', this.fieldStateChange);

      $(window).on('resize.quickedit scroll.quickedit drupalViewportOffsetChange.quickedit', debounce($.proxy(this.windowChangeHandler, this), 150));

      $(document).on('drupalViewportOffsetChange.quickedit', function (event, offsets) {
        if (that.$fence) {
          that.$fence.css(offsets);
        }
      });

      var $toolbar = this.buildToolbarEl();
      this.setElement($toolbar);
      this._fieldToolbarRoot = $toolbar.find('.quickedit-toolbar-field').get(0);

      this.render();
    },
    render: function render() {
      if (this.model.get('isActive')) {
        var $body = $('body');
        if ($body.children('#quickedit-entity-toolbar').length === 0) {
          $body.append(this.$el);
        }

        if ($body.children('#quickedit-toolbar-fence').length === 0) {
          this.$fence = $(Drupal.theme('quickeditEntityToolbarFence')).css(Drupal.displace()).appendTo($body);
        }

        this.label();

        this.show('ops');

        this.position();
      }

      var $button = this.$el.find('.quickedit-button.action-save');
      var isDirty = this.model.get('isDirty');

      switch (this.model.get('state')) {
        case 'opened':
          $button.removeClass('action-saving icon-throbber icon-end').text(Drupal.t('Save')).removeAttr('disabled').attr('aria-hidden', !isDirty);
          break;

        case 'committing':
          $button.addClass('action-saving icon-throbber icon-end').text(Drupal.t('Saving')).attr('disabled', 'disabled');
          break;

        default:
          $button.attr('aria-hidden', true);
          break;
      }

      return this;
    },
    remove: function remove() {
      this.$fence.remove();

      $(window).off('resize.quickedit scroll.quickedit drupalViewportOffsetChange.quickedit');
      $(document).off('drupalViewportOffsetChange.quickedit');

      Backbone.View.prototype.remove.call(this);
    },
    windowChangeHandler: function windowChangeHandler(event) {
      this.position();
    },
    fieldStateChange: function fieldStateChange(model, state) {
      switch (state) {
        case 'active':
          this.render();
          break;

        case 'invalid':
          this.render();
          break;
      }
    },
    position: function position(element) {
      clearTimeout(this.timer);

      var that = this;

      var edge = document.documentElement.dir === 'rtl' ? 'right' : 'left';

      var delay = 0;

      var check = 0;

      var horizontalPadding = 0;
      var of = void 0;
      var activeField = void 0;
      var highlightedField = void 0;

      do {
        switch (check) {
          case 0:
            of = element;
            break;

          case 1:
            activeField = Drupal.quickedit.app.model.get('activeField');
            of = activeField && activeField.editorView && activeField.editorView.$formContainer && activeField.editorView.$formContainer.find('.quickedit-form');
            break;

          case 2:
            of = activeField && activeField.editorView && activeField.editorView.getEditedElement();
            if (activeField && activeField.editorView && activeField.editorView.getQuickEditUISettings().padding) {
              horizontalPadding = 5;
            }
            break;

          case 3:
            highlightedField = Drupal.quickedit.app.model.get('highlightedField');
            of = highlightedField && highlightedField.editorView && highlightedField.editorView.getEditedElement();
            delay = 250;
            break;

          default:
            {
              var fieldModels = this.model.get('fields').models;
              var topMostPosition = 1000000;
              var topMostField = null;

              for (var i = 0; i < fieldModels.length; i++) {
                var pos = fieldModels[i].get('el').getBoundingClientRect().top;
                if (pos < topMostPosition) {
                  topMostPosition = pos;
                  topMostField = fieldModels[i];
                }
              }
              of = topMostField.get('el');
              delay = 50;
              break;
            }
        }

        check++;
      } while (!of);

      function refinePosition(view, suggested, info) {
        var isBelow = suggested.top > info.target.top;
        info.element.element.toggleClass('quickedit-toolbar-pointer-top', isBelow);

        if (view.$entity[0] === info.target.element[0]) {
          var $field = view.$entity.find('.quickedit-editable').eq(isBelow ? -1 : 0);
          if ($field.length > 0) {
            suggested.top = isBelow ? $field.offset().top + $field.outerHeight(true) : $field.offset().top - info.element.element.outerHeight(true);
          }
        }

        var fenceTop = view.$fence.offset().top;
        var fenceHeight = view.$fence.height();
        var toolbarHeight = info.element.element.outerHeight(true);
        if (suggested.top < fenceTop) {
          suggested.top = fenceTop;
        } else if (suggested.top + toolbarHeight > fenceTop + fenceHeight) {
          suggested.top = fenceTop + fenceHeight - toolbarHeight;
        }

        info.element.element.css({
          left: Math.floor(suggested.left),
          top: Math.floor(suggested.top)
        });
      }

      function positionToolbar() {
        that.$el.position({
          my: edge + ' bottom',

          at: edge + '+' + (1 + horizontalPadding) + ' top',
          of: of,
          collision: 'flipfit',
          using: refinePosition.bind(null, that),
          within: that.$fence
        }).css({
          'max-width': document.documentElement.clientWidth < 450 ? document.documentElement.clientWidth : 450,

          'min-width': document.documentElement.clientWidth < 240 ? document.documentElement.clientWidth : 240,
          width: '100%'
        });
      }

      this.timer = setTimeout(function () {
        _.defer(positionToolbar);
      }, delay);
    },
    onClickSave: function onClickSave(event) {
      event.stopPropagation();
      event.preventDefault();

      this.model.set('state', 'committing');
    },
    onClickCancel: function onClickCancel(event) {
      event.preventDefault();
      this.model.set('state', 'deactivating');
    },
    onMouseenter: function onMouseenter(event) {
      clearTimeout(this.timer);
    },
    buildToolbarEl: function buildToolbarEl() {
      var $toolbar = $(Drupal.theme('quickeditEntityToolbar', {
        id: 'quickedit-entity-toolbar'
      }));

      $toolbar.find('.quickedit-toolbar-entity').prepend(Drupal.theme('quickeditToolgroup', {
        classes: ['ops'],
        buttons: [{
          label: Drupal.t('Save'),
          type: 'submit',
          classes: 'action-save quickedit-button icon',
          attributes: {
            'aria-hidden': true
          }
        }, {
          label: Drupal.t('Close'),
          classes: 'action-cancel quickedit-button icon icon-close icon-only'
        }]
      }));

      $toolbar.css({
        left: this.$entity.offset().left,
        top: this.$entity.offset().top
      });

      return $toolbar;
    },
    getToolbarRoot: function getToolbarRoot() {
      return this._fieldToolbarRoot;
    },
    label: function label() {
      var label = '';
      var entityLabel = this.model.get('label');

      var activeField = Drupal.quickedit.app.model.get('activeField');
      var activeFieldLabel = activeField && activeField.get('metadata').label;

      var highlightedField = Drupal.quickedit.app.model.get('highlightedField');
      var highlightedFieldLabel = highlightedField && highlightedField.get('metadata').label;

      if (activeFieldLabel) {
        label = Drupal.theme('quickeditEntityToolbarLabel', {
          entityLabel: entityLabel,
          fieldLabel: activeFieldLabel
        });
      } else if (highlightedFieldLabel) {
        label = Drupal.theme('quickeditEntityToolbarLabel', {
          entityLabel: entityLabel,
          fieldLabel: highlightedFieldLabel
        });
      } else {
        label = Drupal.checkPlain(entityLabel);
      }

      this.$el.find('.quickedit-toolbar-label').html(label);
    },
    addClass: function addClass(toolgroup, classes) {
      this._find(toolgroup).addClass(classes);
    },
    removeClass: function removeClass(toolgroup, classes) {
      this._find(toolgroup).removeClass(classes);
    },
    _find: function _find(toolgroup) {
      return this.$el.find('.quickedit-toolbar .quickedit-toolgroup.' + toolgroup);
    },
    show: function show(toolgroup) {
      this.$el.removeClass('quickedit-animate-invisible');
    }
  });
})(jQuery, _, Backbone, Drupal, Drupal.debounce);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal) {
  Drupal.quickedit.ContextualLinkView = Backbone.View.extend({
    events: function events() {
      function touchEndToClick(event) {
        event.preventDefault();
        event.target.click();
      }

      return {
        'click a': function clickA(event) {
          event.preventDefault();
          this.model.set('state', 'launching');
        },
        'touchEnd a': touchEndToClick
      };
    },
    initialize: function initialize(options) {
      this.$el.find('a').text(options.strings.quickEdit);

      this.render();

      this.listenTo(this.model, 'change:isActive', this.render);
    },
    render: function render(entityModel, isActive) {
      this.$el.find('a').attr('aria-pressed', isActive);

      this.$el.closest('.contextual').toggle(!isActive);

      return this;
    }
  });
})(jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, _, Backbone, Drupal) {
  Drupal.quickedit.FieldToolbarView = Backbone.View.extend({
    $editedElement: null,

    editorView: null,

    _id: null,

    initialize: function initialize(options) {
      this.$editedElement = options.$editedElement;
      this.editorView = options.editorView;

      this.$root = this.$el;

      this._id = 'quickedit-toolbar-for-' + this.model.id.replace(/[/[\]]/g, '_');

      this.listenTo(this.model, 'change:state', this.stateChange);
    },
    render: function render() {
      this.setElement($(Drupal.theme('quickeditFieldToolbar', {
        id: this._id
      })));

      this.$el.prependTo(this.$root);

      return this;
    },
    stateChange: function stateChange(model, state) {
      var from = model.previous('state');
      var to = state;
      switch (to) {
        case 'inactive':
          break;

        case 'candidate':
          if (from !== 'inactive' && from !== 'highlighted') {
            this.$el.remove();
            this.setElement();
          }
          break;

        case 'highlighted':
          break;

        case 'activating':
          this.render();

          if (this.editorView.getQuickEditUISettings().fullWidthToolbar) {
            this.$el.addClass('quickedit-toolbar-fullwidth');
          }

          if (this.editorView.getQuickEditUISettings().unifiedToolbar) {
            this.insertWYSIWYGToolGroups();
          }
          break;

        case 'active':
          break;

        case 'changed':
          break;

        case 'saving':
          break;

        case 'saved':
          break;

        case 'invalid':
          break;
      }
    },
    insertWYSIWYGToolGroups: function insertWYSIWYGToolGroups() {
      this.$el.append(Drupal.theme('quickeditToolgroup', {
        id: this.getFloatedWysiwygToolgroupId(),
        classes: ['wysiwyg-floated', 'quickedit-animate-slow', 'quickedit-animate-invisible', 'quickedit-animate-delay-veryfast'],
        buttons: []
      })).append(Drupal.theme('quickeditToolgroup', {
        id: this.getMainWysiwygToolgroupId(),
        classes: ['wysiwyg-main', 'quickedit-animate-slow', 'quickedit-animate-invisible', 'quickedit-animate-delay-veryfast'],
        buttons: []
      }));

      this.show('wysiwyg-floated');
      this.show('wysiwyg-main');
    },
    getId: function getId() {
      return 'quickedit-toolbar-for-' + this._id;
    },
    getFloatedWysiwygToolgroupId: function getFloatedWysiwygToolgroupId() {
      return 'quickedit-wysiwyg-floated-toolgroup-for-' + this._id;
    },
    getMainWysiwygToolgroupId: function getMainWysiwygToolgroupId() {
      return 'quickedit-wysiwyg-main-toolgroup-for-' + this._id;
    },
    _find: function _find(toolgroup) {
      return this.$el.find('.quickedit-toolgroup.' + toolgroup);
    },
    show: function show(toolgroup) {
      var $group = this._find(toolgroup);

      $group.on(Drupal.quickedit.util.constants.transitionEnd, function (event) {
        $group.off(Drupal.quickedit.util.constants.transitionEnd);
      });

      window.setTimeout(function () {
        $group.removeClass('quickedit-animate-invisible');
      }, 0);
    }
  });
})(jQuery, _, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal) {
  Drupal.quickedit.EditorView = Backbone.View.extend({
    initialize: function initialize(options) {
      this.fieldModel = options.fieldModel;
      this.listenTo(this.fieldModel, 'change:state', this.stateChange);
    },
    remove: function remove() {
      this.setElement();
      Backbone.View.prototype.remove.call(this);
    },
    getEditedElement: function getEditedElement() {
      return this.$el;
    },
    getQuickEditUISettings: function getQuickEditUISettings() {
      return {
        padding: false,
        unifiedToolbar: false,
        fullWidthToolbar: false,
        popup: false
      };
    },
    stateChange: function stateChange(fieldModel, state) {
      var from = fieldModel.previous('state');
      var to = state;
      switch (to) {
        case 'inactive':
          break;

        case 'candidate':
          if (from === 'invalid') {
            this.removeValidationErrors();
          }
          break;

        case 'highlighted':
          break;

        case 'activating':
          {
            var loadDependencies = function loadDependencies(callback) {
              callback();
            };
            loadDependencies(function () {
              fieldModel.set('state', 'active');
            });
            break;
          }

        case 'active':
          break;

        case 'changed':
          break;

        case 'saving':
          if (from === 'invalid') {
            this.removeValidationErrors();
          }
          this.save();
          break;

        case 'saved':
          break;

        case 'invalid':
          this.showValidationErrors();
          break;
      }
    },
    revert: function revert() {},
    save: function save() {
      var fieldModel = this.fieldModel;
      var editorModel = this.model;
      var backstageId = 'quickedit_backstage-' + this.fieldModel.id.replace(/[/[\]_\s]/g, '-');

      function fillAndSubmitForm(value) {
        var $form = $('#' + backstageId).find('form');

        $form.find(':input[type!="hidden"][type!="submit"]:not(select)').not('[name$="\\[summary\\]"]').val(value);

        $form.find('.quickedit-form-submit').trigger('click.quickedit');
      }

      var formOptions = {
        fieldID: this.fieldModel.get('fieldID'),
        $el: this.$el,
        nocssjs: true,
        other_view_modes: fieldModel.findOtherViewModes(),

        reset: !this.fieldModel.get('entity').get('inTempStore')
      };

      var self = this;
      Drupal.quickedit.util.form.load(formOptions, function (form, ajax) {
        var $backstage = $(Drupal.theme('quickeditBackstage', { id: backstageId })).appendTo('body');

        var $form = $(form).appendTo($backstage);

        $form.prop('novalidate', true);
        var $submit = $form.find('.quickedit-form-submit');
        self.formSaveAjax = Drupal.quickedit.util.form.ajaxifySaving(formOptions, $submit);

        function removeHiddenForm() {
          Drupal.quickedit.util.form.unajaxifySaving(self.formSaveAjax);
          delete self.formSaveAjax;
          $backstage.remove();
        }

        self.formSaveAjax.commands.quickeditFieldFormSaved = function (ajax, response, status) {
          removeHiddenForm();

          fieldModel.set('state', 'saved');

          fieldModel.set('htmlForOtherViewModes', response.other_view_modes);

          fieldModel.set('html', response.data);
        };

        self.formSaveAjax.commands.quickeditFieldFormValidationErrors = function (ajax, response, status) {
          removeHiddenForm();
          editorModel.set('validationErrors', response.data);
          fieldModel.set('state', 'invalid');
        };

        self.formSaveAjax.commands.quickeditFieldForm = function () {};

        fillAndSubmitForm(editorModel.get('currentValue'));
      });
    },
    showValidationErrors: function showValidationErrors() {
      var $errors = $('<div class="quickedit-validation-errors"></div>').append(this.model.get('validationErrors'));
      this.getEditedElement().addClass('quickedit-validation-error').after($errors);
    },
    removeValidationErrors: function removeValidationErrors() {
      this.getEditedElement().removeClass('quickedit-validation-error').next('.quickedit-validation-errors').remove();
    }
  });
})(jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal) {
  Drupal.theme.quickeditBackstage = function (settings) {
    var html = '';
    html += '<div id="' + settings.id + '" />';
    return html;
  };

  Drupal.theme.quickeditEntityToolbar = function (settings) {
    var html = '';
    html += '<div id="' + settings.id + '" class="quickedit quickedit-toolbar-container clearfix">';
    html += '<i class="quickedit-toolbar-pointer"></i>';
    html += '<div class="quickedit-toolbar-content">';
    html += '<div class="quickedit-toolbar quickedit-toolbar-entity clearfix icon icon-pencil">';
    html += '<div class="quickedit-toolbar-label" />';
    html += '</div>';
    html += '<div class="quickedit-toolbar quickedit-toolbar-field clearfix" />';
    html += '</div><div class="quickedit-toolbar-lining"></div></div>';
    return html;
  };

  Drupal.theme.quickeditEntityToolbarLabel = function (settings) {
    return '<span class="field">' + Drupal.checkPlain(settings.fieldLabel) + '</span>' + Drupal.checkPlain(settings.entityLabel);
  };

  Drupal.theme.quickeditEntityToolbarFence = function () {
    return '<div id="quickedit-toolbar-fence" />';
  };

  Drupal.theme.quickeditFieldToolbar = function (settings) {
    return '<div id="' + settings.id + '" />';
  };

  Drupal.theme.quickeditToolgroup = function (settings) {
    var classes = settings.classes || [];
    classes.unshift('quickedit-toolgroup');
    var html = '';
    html += '<div class="' + classes.join(' ') + '"';
    if (settings.id) {
      html += ' id="' + settings.id + '"';
    }
    html += '>';
    html += Drupal.theme('quickeditButtons', { buttons: settings.buttons });
    html += '</div>';
    return html;
  };

  Drupal.theme.quickeditButtons = function (settings) {
    var html = '';

    var _loop = function _loop(i) {
      var button = settings.buttons[i];
      if (!button.hasOwnProperty('type')) {
        button.type = 'button';
      }

      var attributes = [];
      var attrMap = settings.buttons[i].attributes || {};
      Object.keys(attrMap).forEach(function (attr) {
        attributes.push(attr + (attrMap[attr] ? '="' + attrMap[attr] + '"' : ''));
      });
      html += '<button type="' + button.type + '" class="' + button.classes + '" ' + attributes.join(' ') + '>' + button.label + '</button>';
    };

    for (var i = 0; i < settings.buttons.length; i++) {
      _loop(i);
    }
    return html;
  };

  Drupal.theme.quickeditFormContainer = function (settings) {
    var html = '';
    html += '<div id="' + settings.id + '" class="quickedit-form-container">';
    html += '  <div class="quickedit-form">';
    html += '    <div class="placeholder">';
    html += settings.loadingMsg;
    html += '    </div>';
    html += '  </div>';
    html += '</div>';
    return html;
  };
})(jQuery, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, drupalSettings) {
  Drupal.behaviors.activeLinks = {
    attach: function attach(context) {
      var path = drupalSettings.path;
      var queryString = JSON.stringify(path.currentQuery);
      var querySelector = path.currentQuery ? '[data-drupal-link-query=\'' + queryString + '\']' : ':not([data-drupal-link-query])';
      var originalSelectors = ['[data-drupal-link-system-path="' + path.currentPath + '"]'];
      var selectors = void 0;

      if (path.isFront) {
        originalSelectors.push('[data-drupal-link-system-path="<front>"]');
      }

      selectors = [].concat(originalSelectors.map(function (selector) {
        return selector + ':not([hreflang])';
      }), originalSelectors.map(function (selector) {
        return selector + '[hreflang="' + path.currentLanguage + '"]';
      }));

      selectors = selectors.map(function (current) {
        return current + querySelector;
      });

      var activeLinks = context.querySelectorAll(selectors.join(','));
      var il = activeLinks.length;
      for (var i = 0; i < il; i++) {
        activeLinks[i].classList.add('is-active');
      }
    },
    detach: function detach(context, settings, trigger) {
      if (trigger === 'unload') {
        var activeLinks = context.querySelectorAll('[data-drupal-link-system-path].is-active');
        var il = activeLinks.length;
        for (var i = 0; i < il; i++) {
          activeLinks[i].classList.remove('is-active');
        }
      }
    }
  };
})(Drupal, drupalSettings);;
/**
 * @file
 * Bootstrap Popovers.
 */

var Drupal = Drupal || {};

(function ($, Drupal, Bootstrap) {
  "use strict";

  var $document = $(document);

  /**
   * Extend the Bootstrap Popover plugin constructor class.
   */
  Bootstrap.extendPlugin('popover', function (settings) {
    return {
      DEFAULTS: {
        animation: !!settings.popover_animation,
        autoClose: !!settings.popover_auto_close,
        enabled: settings.popover_enabled,
        html: !!settings.popover_html,
        placement: settings.popover_placement,
        selector: settings.popover_selector,
        trigger: settings.popover_trigger,
        title: settings.popover_title,
        content: settings.popover_content,
        delay: parseInt(settings.popover_delay, 10),
        container: settings.popover_container
      }
    };
  });

  /**
   * Bootstrap Popovers.
   *
   * @todo This should really be properly delegated if selector option is set.
   */
  Drupal.behaviors.bootstrapPopovers = {
    $activePopover: null,
    attach: function (context) {
      // Immediately return if popovers are not available.
      if (!$.fn.popover || !$.fn.popover.Constructor.DEFAULTS.enabled) {
        return;
      }

      var _this = this;

      $document
        .on('show.bs.popover', '[data-toggle=popover]', function () {
          var $trigger = $(this);
          var popover = $trigger.data('bs.popover');

          // Only keep track of clicked triggers that we're manually handling.
          if (popover.options.originalTrigger === 'click') {
            if (_this.$activePopover && _this.getOption('autoClose') && !_this.$activePopover.is($trigger)) {
              _this.$activePopover.popover('hide');
            }
            _this.$activePopover = $trigger;
          }
        })
        .on('focus.bs.popover', ':focusable', function (e) {
          var $target = $(e.target);
          if (_this.$activePopover && _this.getOption('autoClose') && !_this.$activePopover.is($target) && !$target.closest('.popover.in')[0]) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
        .on('click.bs.popover', function (e) {
          var $target = $(e.target);
          if (_this.$activePopover && _this.getOption('autoClose') && !$target.is('[data-toggle=popover]') && !$target.closest('.popover.in')[0]) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
        .on('keyup.bs.popover', function (e) {
          if (_this.$activePopover && _this.getOption('autoClose') && e.which === 27) {
            _this.$activePopover.popover('hide');
            _this.$activePopover = null;
          }
        })
      ;

      var elements = $(context).find('[data-toggle=popover]').toArray();
      for (var i = 0; i < elements.length; i++) {
        var $element = $(elements[i]);
        var options = $.extend({}, $.fn.popover.Constructor.DEFAULTS, $element.data());

        // Store the original trigger.
        options.originalTrigger = options.trigger;

        // If the trigger is "click", then we'll handle it manually here.
        if (options.trigger === 'click') {
          options.trigger = 'manual';
        }

        // Retrieve content from a target element.
        var target = options.target || $element.is('a[href^="#"]') && $element.attr('href');
        var $target = $document.find(target).clone();
        if (!options.content && $target[0]) {
          $target.removeClass('visually-hidden hidden').removeAttr('aria-hidden');
          options.content = $target.wrap('<div/>').parent()[options.html ? 'html' : 'text']() || '';
        }

        // Initialize the popover.
        $element.popover(options);

        // Handle clicks manually.
        if (options.originalTrigger === 'click') {
          // To ensure the element is bound multiple times, remove any
          // previously set event handler before adding another one.
          $element
            .off('click.drupal.bootstrap.popover')
            .on('click.drupal.bootstrap.popover', function (e) {
              $(this).popover('toggle');
              e.preventDefault();
              e.stopPropagation();
            })
          ;
        }
      }
    },
    detach: function (context) {
      // Immediately return if popovers are not available.
      if (!$.fn.popover || !$.fn.popover.Constructor.DEFAULTS.enabled) {
        return;
      }

      // Destroy all popovers.
      $(context).find('[data-toggle="popover"]')
        .off('click.drupal.bootstrap.popover')
        .popover('destroy')
      ;
    },
    getOption: function(name, defaultValue, element) {
      var $element = element ? $(element) : this.$activePopover;
      var options = $.extend(true, {}, $.fn.popover.Constructor.DEFAULTS, (($element && $element.data('bs.popover')).options || {}).options);
      if (options[name] !== void 0) {
        return options[name];
      }
      return defaultValue !== void 0 ? defaultValue : void 0;
    }
  };

})(window.jQuery, window.Drupal, window.Drupal.bootstrap);
;
/**
 * @file
 * Bootstrap Tooltips.
 */

var Drupal = Drupal || {};

(function ($, Drupal, Bootstrap) {
  "use strict";

  /**
   * Extend the Bootstrap Tooltip plugin constructor class.
   */
  Bootstrap.extendPlugin('tooltip', function (settings) {
    return {
      DEFAULTS: {
        animation: !!settings.tooltip_animation,
        html: !!settings.tooltip_html,
        placement: settings.tooltip_placement,
        selector: settings.tooltip_selector,
        trigger: settings.tooltip_trigger,
        delay: parseInt(settings.tooltip_delay, 10),
        container: settings.tooltip_container
      }
    };
  });

  /**
   * Bootstrap Tooltips.
   *
   * @todo This should really be properly delegated if selector option is set.
   */
  Drupal.behaviors.bootstrapTooltips = {
    attach: function (context) {
      var elements = $(context).find('[data-toggle="tooltip"]').toArray();
      for (var i = 0; i < elements.length; i++) {
        var $element = $(elements[i]);
        var options = $.extend({}, $.fn.tooltip.Constructor.DEFAULTS, $element.data());
        $element.tooltip(options);
      }
    },
    detach: function (context) {
      // Destroy all tooltips.
      $(context).find('[data-toggle="tooltip"]').tooltip('destroy');
    }
  };

})(window.jQuery, window.Drupal, window.Drupal.bootstrap);
;
/**
 * @file
 * JavaScript integration between Google and Drupal.
 */

(function ($) {
  'use strict';

  Drupal.googleCharts = Drupal.googleCharts || {charts: []};

  /**
   * Behavior to initialize Google Charts.
   *
   * @type {{attach: Drupal.behaviors.chartsGooglecharts.attach}}
   */
  Drupal.behaviors.chartsGooglecharts = {
    attach: function (context, settings) {
      // Load Google Charts API.
      google.charts.load('current', {packages: ['corechart', 'gauge']});

      $(context).find('body').once('load-google-charts').each(function () {
        // Re-draw charts if viewport size has been changed.
        $(window).on('resize', function () {
          Drupal.googleCharts.waitForFinalEvent(function () {
            // Re-draw Google Charts.
            Drupal.googleCharts.drawCharts(true);
          }, 200, 'reload-google-charts');
        });
      });

      // Draw Google Charts.
      Drupal.googleCharts.drawCharts();
    }
  };

  /**
   * Helper function to draw Google Charts.
   *
   * @param {boolean} reload - Reload.
   */
  Drupal.googleCharts.drawCharts = function (reload) {
    $('.charts-google').each(function () {
      var chartId = $(this).attr('id');
      var $charts;

      if (reload === true) {
        $charts = $('#' + chartId);
      }
      else {
        $charts = $('#' + chartId).once('draw-google-charts');
      }

      $charts.each(function () {
        var $chart = $(this);

        if ($chart.attr('data-chart')) {
          var data = $chart.attr('data-chart');
          var options = $chart.attr('google-options');
          var type = $chart.attr('google-chart-type');

          google.charts.setOnLoadCallback(Drupal.googleCharts.drawChart(chartId, type, data, options));
        }
      });
    });
  };

  /**
   * Helper function to draw a Google Chart.
   *
   * @param {string} chartId - Chart Id.
   * @param {string} chartType - Chart Type.
   * @param {string} dataTable - Data.
   * @param {string} googleChartOptions - Options.
   *
   * @return {function} Draw Chart.
   */
  Drupal.googleCharts.drawChart = function (chartId, chartType, dataTable, googleChartOptions) {
    return function () {
      var data = google.visualization.arrayToDataTable(JSON.parse(dataTable));
      var options = JSON.parse(googleChartOptions);
      var googleChartTypeObject = JSON.parse(chartType);
      var googleChartTypeFormatted = googleChartTypeObject.type;
      var chart;

      switch (googleChartTypeFormatted) {
        case 'BarChart':
          chart = new google.visualization.BarChart(document.getElementById(chartId));
          break;
        case 'ColumnChart':
          chart = new google.visualization.ColumnChart(document.getElementById(chartId));
          break;
        case 'DonutChart':
          chart = new google.visualization.PieChart(document.getElementById(chartId));
          break;
        case 'PieChart':
          chart = new google.visualization.PieChart(document.getElementById(chartId));
          break;
        case 'ScatterChart':
          chart = new google.visualization.ScatterChart(document.getElementById(chartId));
          break;
        case 'AreaChart':
          chart = new google.visualization.AreaChart(document.getElementById(chartId));
          break;
        case 'LineChart':
          chart = new google.visualization.LineChart(document.getElementById(chartId));
          break;
        case 'SplineChart':
          chart = new google.visualization.LineChart(document.getElementById(chartId));
          break;
        case 'GaugeChart':
          chart = new google.visualization.Gauge(document.getElementById(chartId));
      }
      // Fix for https://www.drupal.org/project/charts/issues/2950654.
      // Would be interested in a different approach that allowed the default
      // colors to be applied first, rather than unsetting.
      if (options['colors'].length > 10) {
        for (var i in options) {
          if (i === 'colors') {
            delete options[i];
            break;
          }
        }
      }
      chart.draw(data, options);
    };
  };

  /**
   * Helper function to run a callback function once when triggering an event
   * multiple times.
   *
   * Example usage:
   * @code
   *  $(window).resize(function () {
   *    Drupal.googleCharts.waitForFinalEvent(function(){
   *      alert('Resize...');
   *    }, 500, "some unique string");
   *  });
   * @endcode
   */
  Drupal.googleCharts.waitForFinalEvent = (function () {
    var timers = {};
    return function (callback, ms, uniqueId) {
      if (!uniqueId) {
        uniqueId = "Don't call this twice without a uniqueId";
      }
      if (timers[uniqueId]) {
        clearTimeout(timers[uniqueId]);
      }
      timers[uniqueId] = setTimeout(callback, ms);
    };
  })();

}(jQuery));
;
(function(){var a="' of type ",k="SCRIPT",n="array",p="charts-version",q="function",t="google.charts.load",u="hasOwnProperty",v="number",w="object",x="pre-45",y="propertyIsEnumerable",z="string",A="text/javascript",B="toLocaleString";function C(){return function(b){return b}}function D(){return function(){}}function E(b){return function(){return this[b]}}function F(b){return function(){return b}}var H,I=I||{};I.scope={};
I.Jq=function(b,c,d){b instanceof String&&(b=String(b));for(var e=b.length,f=0;f<e;f++){var g=b[f];if(c.call(d,g,f,b))return{Vj:f,Gl:g}}return{Vj:-1,Gl:void 0}};I.vh=!1;I.Zl=!1;I.$l=!1;I.defineProperty=I.vh||typeof Object.defineProperties==q?Object.defineProperty:function(b,c,d){b!=Array.prototype&&b!=Object.prototype&&(b[c]=d.value)};I.Dj=function(b){return"undefined"!=typeof window&&window===b?b:"undefined"!=typeof global&&null!=global?global:b};I.global=I.Dj(this);
I.Mk=function(b){if(b){for(var c=I.global,d=["Promise"],e=0;e<d.length-1;e++){var f=d[e];f in c||(c[f]={});c=c[f]}d=d[d.length-1];e=c[d];b=b(e);b!=e&&null!=b&&I.defineProperty(c,d,{configurable:!0,writable:!0,value:b})}};I.Xp=function(b,c,d){if(null==b)throw new TypeError("The 'this' value for String.prototype."+d+" must not be null or undefined");if(c instanceof RegExp)throw new TypeError("First argument to String.prototype."+d+" must not be a regular expression");return b+""};
I.Di=function(b){var c=0;return function(){return c<b.length?{done:!1,value:b[c++]}:{done:!0}}};I.Ci=function(b){return{next:I.Di(b)}};I.Gg=function(b){var c="undefined"!=typeof Symbol&&Symbol.iterator&&b[Symbol.iterator];return c?c.call(b):I.Ci(b)};I.Qh=!1;
I.Mk(function(b){function c(b){this.ba=g.ya;this.la=void 0;this.ub=[];var c=this.fd();try{b(c.resolve,c.reject)}catch(r){c.reject(r)}}function d(){this.La=null}function e(b){return b instanceof c?b:new c(function(c){c(b)})}if(b&&!I.Qh)return b;d.prototype.Xe=function(b){null==this.La&&(this.La=[],this.Hi());this.La.push(b)};d.prototype.Hi=function(){var b=this;this.Ye(function(){b.pj()})};var f=I.global.setTimeout;d.prototype.Ye=function(b){f(b,0)};d.prototype.pj=function(){for(;this.La&&this.La.length;){var b=
this.La;this.La=[];for(var c=0;c<b.length;++c){var d=b[c];b[c]=null;try{d()}catch(G){this.Ii(G)}}}this.La=null};d.prototype.Ii=function(b){this.Ye(function(){throw b;})};var g={ya:0,Ka:1,na:2};c.prototype.fd=function(){function b(b){return function(e){d||(d=!0,b.call(c,e))}}var c=this,d=!1;return{resolve:b(this.Rk),reject:b(this.Sd)}};c.prototype.Rk=function(b){if(b===this)this.Sd(new TypeError("A Promise cannot resolve to itself"));else if(b instanceof c)this.jl(b);else{a:switch(typeof b){case w:var d=
null!=b;break a;case q:d=!0;break a;default:d=!1}d?this.Qk(b):this.zf(b)}};c.prototype.Qk=function(b){var c=void 0;try{c=b.then}catch(r){this.Sd(r);return}typeof c==q?this.kl(c,b):this.zf(b)};c.prototype.Sd=function(b){this.$g(g.na,b)};c.prototype.zf=function(b){this.$g(g.Ka,b)};c.prototype.$g=function(b,c){if(this.ba!=g.ya)throw Error("Cannot settle("+b+", "+c+"): Promise already settled in state"+this.ba);this.ba=b;this.la=c;this.rj()};c.prototype.rj=function(){if(null!=this.ub){for(var b=0;b<this.ub.length;++b)h.Xe(this.ub[b]);
this.ub=null}};var h=new d;c.prototype.jl=function(b){var c=this.fd();b.dc(c.resolve,c.reject)};c.prototype.kl=function(b,c){var d=this.fd();try{b.call(c,d.resolve,d.reject)}catch(G){d.reject(G)}};c.prototype.then=function(b,d){function e(b,c){return typeof b==q?function(c){try{f(b(c))}catch(ba){g(ba)}}:c}var f,g,h=new c(function(b,c){f=b;g=c});this.dc(e(b,f),e(d,g));return h};c.prototype["catch"]=function(b){return this.then(void 0,b)};c.prototype.dc=function(b,c){function d(){switch(e.ba){case g.Ka:b(e.la);
break;case g.na:c(e.la);break;default:throw Error("Unexpected state: "+e.ba);}}var e=this;null==this.ub?h.Xe(d):this.ub.push(d)};c.resolve=e;c.reject=function(b){return new c(function(c,d){d(b)})};c.race=function(b){return new c(function(c,d){for(var f=I.Gg(b),g=f.next();!g.done;g=f.next())e(g.value).dc(c,d)})};c.all=function(b){var d=I.Gg(b),f=d.next();return f.done?e([]):new c(function(b,c){function g(c){return function(d){h[c]=d;l--;0==l&&b(h)}}var h=[],l=0;do h.push(void 0),l++,e(f.value).dc(g(h.length-
1),c),f=d.next();while(!f.done)})};return c});var J=J||{};J.global=this;J.W=function(b){return void 0!==b};J.N=function(b){return typeof b==z};J.Yj=function(b){return"boolean"==typeof b};J.Rb=function(b){return typeof b==v};J.ld=function(b,c,d){b=b.split(".");d=d||J.global;b[0]in d||"undefined"==typeof d.execScript||d.execScript("var "+b[0]);for(var e;b.length&&(e=b.shift());)!b.length&&J.W(c)?d[e]=c:d=d[e]&&d[e]!==Object.prototype[e]?d[e]:d[e]={}};J.define=function(b,c){J.ld(b,c)};J.Z=!0;J.I="en";
J.Xc=!0;J.mi=!1;J.Mh=!J.Z;J.Pm=!1;J.Os=function(b){if(J.tg())throw Error("goog.provide cannot be used within a module.");J.gf(b)};J.gf=function(b,c){J.ld(b,c)};J.$f=function(){null===J.gd&&(J.gd=J.Hj());return J.gd};J.Yh=/^[\w+/_-]+[=]{0,2}$/;J.gd=null;J.Hj=function(){var b=J.global.document;return(b=b.querySelector&&b.querySelector("script[nonce]"))&&(b=b.nonce||b.getAttribute("nonce"))&&J.Yh.test(b)?b:""};J.ui=/^[a-zA-Z_$][a-zA-Z0-9._$]*$/;
J.uc=function(b){if(!J.N(b)||!b||-1==b.search(J.ui))throw Error("Invalid module identifier");if(!J.sg())throw Error("Module "+b+" has been loaded incorrectly. Note, modules cannot be loaded as normal scripts. They require some kind of pre-processing step. You're likely trying to load a module via a script tag or as a part of a concatenated bundle without rewriting the module. For more info see: https://github.com/google/closure-library/wiki/goog.module:-an-ES6-module-like-alternative-to-goog.provide.");
if(J.ia.Sb)throw Error("goog.module may only be called once per module.");J.ia.Sb=b};J.uc.get=F(null);J.uc.kr=F(null);J.Ab={we:"es6",Vc:"goog"};J.ia=null;J.tg=function(){return J.sg()||J.ck()};J.sg=function(){return!!J.ia&&J.ia.type==J.Ab.Vc};J.ck=function(){if(J.ia&&J.ia.type==J.Ab.we)return!0;var b=J.global.$jscomp;return b?typeof b.qd!=q?!1:!!b.qd():!1};J.uc.hd=function(){J.ia.hd=!0};
J.fj=function(b){if(J.ia)J.ia.Sb=b;else{var c=J.global.$jscomp;if(!c||typeof c.qd!=q)throw Error('Module with namespace "'+b+'" has been loaded incorrectly.');c=c.Ok(c.qd());J.Fg[b]={sj:c,type:J.Ab.we,Jk:b}}};J.uc.wq=J.fj;J.It=function(b){if(J.Mh)throw b=b||"",Error("Importing test-only code into non-debug environment"+(b?": "+b:"."));};J.Pq=D();J.ob=function(b){b=b.split(".");for(var c=J.global,d=0;d<b.length;d++)if(c=c[b[d]],!J.bb(c))return null;return c};
J.wr=function(b,c){c=c||J.global;for(var d in b)c[d]=b[d]};J.jp=D();J.mu=!1;J.Qm=!0;J.zk=function(b){J.global.console&&J.global.console.error(b)};J.Ok=D();J.at=function(){return{}};J.Li="";J.cb=D();J.ip=function(){throw Error("unimplemented abstract method");};J.kp=function(b){b.Ed=void 0;b.jr=function(){if(b.Ed)return b.Ed;J.Z&&(J.lg[J.lg.length]=b);return b.Ed=new b}};J.lg=[];J.Ln=!0;J.ii=J.Z;J.Fg={};J.Bm=!1;J.Wo="detect";J.Xo="";J.oi="transpile.js";J.Cd=null;
J.El=function(){if(null==J.Cd){try{var b=!eval('"use strict";let x = 1; function f() { return typeof x; };f() == "number";')}catch(c){b=!1}J.Cd=b}return J.Cd};J.Ll=function(b){return"(function(){"+b+"\n;})();\n"};
J.ss=function(b){var c=J.ia;try{J.ia={Sb:"",hd:!1,type:J.Ab.Vc};if(J.Ba(b))var d=b.call(void 0,{});else if(J.N(b))J.El()&&(b=J.Ll(b)),d=J.wk.call(void 0,b);else throw Error("Invalid module definition");var e=J.ia.Sb;if(J.N(e)&&e)J.ia.hd?J.gf(e,d):J.ii&&Object.seal&&typeof d==w&&null!=d&&Object.seal(d),J.Fg[e]={sj:d,type:J.Ab.Vc,Jk:J.ia.Sb};else throw Error('Invalid module name "'+e+'"');}finally{J.ia=c}};J.wk=function(b){eval(b);return{}};
J.Ds=function(b){b=b.split("/");for(var c=0;c<b.length;)"."==b[c]?b.splice(c,1):c&&".."==b[c]&&b[c-1]&&".."!=b[c-1]?b.splice(--c,2):c++;return b.join("/")};J.uk=function(b){if(J.global.Gh)return J.global.Gh(b);try{var c=new J.global.XMLHttpRequest;c.open("get",b,!1);c.send();return 0==c.status||200==c.status?c.responseText:null}catch(d){return null}};
J.du=function(b,c,d){var e=J.global.$jscomp;e||(J.global.$jscomp=e={});var f=e.de;if(!f){var g=J.Li+J.oi,h=J.uk(g);if(h){(function(){eval(h+"\n//# sourceURL="+g)}).call(J.global);if(J.global.$gwtExport&&J.global.$gwtExport.$jscomp&&!J.global.$gwtExport.$jscomp.transpile)throw Error('The transpiler did not properly export the "transpile" method. $gwtExport: '+JSON.stringify(J.global.$gwtExport));J.global.$jscomp.de=J.global.$gwtExport.$jscomp.transpile;e=J.global.$jscomp;f=e.de}}if(!f){var l=" requires transpilation but no transpiler was found.";
l+=' Please add "//javascript/closure:transpiler" as a data dependency to ensure it is included.';f=e.de=function(b,c){J.zk(c+l);return b}}return f(b,c,d)};
J.ca=function(b){var c=typeof b;if(c==w)if(b){if(b instanceof Array)return n;if(b instanceof Object)return c;var d=Object.prototype.toString.call(b);if("[object Window]"==d)return w;if("[object Array]"==d||typeof b.length==v&&"undefined"!=typeof b.splice&&"undefined"!=typeof b.propertyIsEnumerable&&!b.propertyIsEnumerable("splice"))return n;if("[object Function]"==d||"undefined"!=typeof b.call&&"undefined"!=typeof b.propertyIsEnumerable&&!b.propertyIsEnumerable("call"))return q}else return"null";
else if(c==q&&"undefined"==typeof b.call)return w;return c};J.cs=function(b){return null===b};J.bb=function(b){return null!=b};J.isArray=function(b){return J.ca(b)==n};J.Nb=function(b){var c=J.ca(b);return c==n||c==w&&typeof b.length==v};J.Or=function(b){return J.ka(b)&&typeof b.getFullYear==q};J.Ba=function(b){return J.ca(b)==q};J.ka=function(b){var c=typeof b;return c==w&&null!=b||c==q};J.bg=function(b){return b[J.Va]||(b[J.Va]=++J.wl)};J.zr=function(b){return!!b[J.Va]};
J.Nk=function(b){null!==b&&"removeAttribute"in b&&b.removeAttribute(J.Va);try{delete b[J.Va]}catch(c){}};J.Va="closure_uid_"+(1E9*Math.random()>>>0);J.wl=0;J.ir=J.bg;J.Ws=J.Nk;J.Wi=function(b){var c=J.ca(b);if(c==w||c==n){if(typeof b.clone===q)return b.clone();c=c==n?[]:{};for(var d in b)c[d]=J.Wi(b[d]);return c}return b};J.Ni=function(b,c,d){return b.call.apply(b.bind,arguments)};
J.Mi=function(b,c,d){if(!b)throw Error();if(2<arguments.length){var e=Array.prototype.slice.call(arguments,2);return function(){var d=Array.prototype.slice.call(arguments);Array.prototype.unshift.apply(d,e);return b.apply(c,d)}}return function(){return b.apply(c,arguments)}};J.bind=function(b,c,d){J.bind=Function.prototype.bind&&-1!=Function.prototype.bind.toString().indexOf("native code")?J.Ni:J.Mi;return J.bind.apply(null,arguments)};
J.eb=function(b,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=d.slice();c.push.apply(c,arguments);return b.apply(this,c)}};J.ys=function(b,c){for(var d in c)b[d]=c[d]};J.now=J.Xc&&Date.now||function(){return+new Date};
J.vr=function(b){if(J.global.execScript)J.global.execScript(b,"JavaScript");else if(J.global.eval){if(null==J.ic){try{J.global.eval("var _evalTest_ = 1;")}catch(e){}if("undefined"!=typeof J.global._evalTest_){try{delete J.global._evalTest_}catch(e){}J.ic=!0}else J.ic=!1}if(J.ic)J.global.eval(b);else{var c=J.global.document,d=c.createElement(k);d.type=A;d.defer=!1;d.appendChild(c.createTextNode(b));c.head.appendChild(d);c.head.removeChild(d)}}else throw Error("goog.globalEval not available");};
J.ic=null;J.fr=function(b,c){function d(b){b=b.split("-");for(var c=[],d=0;d<b.length;d++)c.push(e(b[d]));return c.join("-")}function e(b){return J.lf[b]||b}if("."==String(b).charAt(0))throw Error('className passed in goog.getCssName must not start with ".". You passed: '+b);var f=J.lf?"BY_WHOLE"==J.ej?e:d:C();b=c?b+"-"+f(c):f(b);return J.global.Fh?J.global.Fh(b):b};J.qt=function(b,c){J.lf=b;J.ej=c};
J.lr=function(b,c){c&&(b=b.replace(/\{\$([^}]+)}/g,function(b,e){return null!=c&&e in c?c[e]:b}));return b};J.mr=C();J.rf=function(b,c){J.ld(b,c,void 0)};J.Iq=function(b,c,d){b[c]=d};J.$a=function(b,c){function d(){}d.prototype=c.prototype;b.Hc=c.prototype;b.prototype=new d;b.prototype.constructor=b;b.Ki=function(b,d,g){for(var e=Array(arguments.length-2),f=2;f<arguments.length;f++)e[f-2]=arguments[f];return c.prototype[d].apply(b,e)}};
J.Ki=function(b,c,d){var e=arguments.callee.caller;if(J.mi||J.Z&&!e)throw Error("arguments.caller not defined.  goog.base() cannot be used with strict mode code. See http://www.ecma-international.org/ecma-262/5.1/#sec-C");if("undefined"!==typeof e.Hc){for(var f=Array(arguments.length-1),g=1;g<arguments.length;g++)f[g-1]=arguments[g];return e.Hc.constructor.apply(b,f)}if(typeof c!=z&&"symbol"!=typeof c)throw Error("method names provided to goog.base must be a string or a symbol");f=Array(arguments.length-
2);for(g=2;g<arguments.length;g++)f[g-2]=arguments[g];g=!1;for(var h=b.constructor;h;h=h.Hc&&h.Hc.constructor)if(h.prototype[c]===e)g=!0;else if(g)return h.prototype[c].apply(b,f);if(b[c]===e)return b.constructor.prototype[c].apply(b,f);throw Error("goog.base called from a method of one name to a method of a different name");};J.scope=function(b){if(J.tg())throw Error("goog.scope is not supported within a module.");b.call(J.global)};
J.pa=function(b,c){var d=c.constructor,e=c.ol;d&&d!=Object.prototype.constructor||(d=function(){throw Error("cannot instantiate an interface (no constructor defined).");});d=J.pa.aj(d,b);b&&J.$a(d,b);delete c.constructor;delete c.ol;J.pa.We(d.prototype,c);null!=e&&(e instanceof Function?e(d):J.pa.We(d,e));return d};J.pa.hi=J.Z;
J.pa.aj=function(b,c){function d(){var c=b.apply(this,arguments)||this;c[J.Va]=c[J.Va];this.constructor===d&&e&&Object.seal instanceof Function&&Object.seal(c);return c}if(!J.pa.hi)return b;var e=!J.pa.nk(c);return d};J.pa.nk=function(b){return b&&b.prototype&&b.prototype[J.ri]};J.pa.He=["constructor",u,"isPrototypeOf",y,B,"toString","valueOf"];
J.pa.We=function(b,c){for(var d in c)Object.prototype.hasOwnProperty.call(c,d)&&(b[d]=c[d]);for(var e=0;e<J.pa.He.length;e++)d=J.pa.He[e],Object.prototype.hasOwnProperty.call(c,d)&&(b[d]=c[d])};J.Xt=D();J.ri="goog_defineClass_legacy_unsealable";J.debug={};J.debug.Error=function(b){if(Error.captureStackTrace)Error.captureStackTrace(this,J.debug.Error);else{var c=Error().stack;c&&(this.stack=c)}b&&(this.message=String(b))};J.$a(J.debug.Error,Error);J.debug.Error.prototype.name="CustomError";J.a={};J.a.fa={Ja:1,am:2,ac:3,pm:4,Sm:5,Rm:6,mo:7,wm:8,Sc:9,Jm:10,Nh:11,Zn:12};J.o={};J.o.ma=J.Z;J.o.Vb=function(b,c){J.debug.Error.call(this,J.o.ql(b,c))};J.$a(J.o.Vb,J.debug.Error);J.o.Vb.prototype.name="AssertionError";J.o.Kh=function(b){throw b;};J.o.jd=J.o.Kh;J.o.ql=function(b,c){b=b.split("%s");for(var d="",e=b.length-1,f=0;f<e;f++)d+=b[f]+(f<c.length?c[f]:"%s");return d+b[e]};J.o.Aa=function(b,c,d,e){var f="Assertion failed";if(d){f+=": "+d;var g=e}else b&&(f+=": "+b,g=c);b=new J.o.Vb(""+f,g||[]);J.o.jd(b)};J.o.ut=function(b){J.o.ma&&(J.o.jd=b)};
J.o.assert=function(b,c,d){J.o.ma&&!b&&J.o.Aa("",null,c,Array.prototype.slice.call(arguments,2));return b};J.o.ha=function(b,c){J.o.ma&&J.o.jd(new J.o.Vb("Failure"+(b?": "+b:""),Array.prototype.slice.call(arguments,1)))};J.o.Hp=function(b,c,d){J.o.ma&&!J.Rb(b)&&J.o.Aa("Expected number but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.Kp=function(b,c,d){J.o.ma&&!J.N(b)&&J.o.Aa("Expected string but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.tp=function(b,c,d){J.o.ma&&!J.Ba(b)&&J.o.Aa("Expected function but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.Ip=function(b,c,d){J.o.ma&&!J.ka(b)&&J.o.Aa("Expected object but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.pp=function(b,c,d){J.o.ma&&!J.isArray(b)&&J.o.Aa("Expected array but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.qp=function(b,c,d){J.o.ma&&!J.Yj(b)&&J.o.Aa("Expected boolean but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};J.o.rp=function(b,c,d){!J.o.ma||J.ka(b)&&b.nodeType==J.a.fa.Ja||J.o.Aa("Expected Element but got %s: %s.",[J.ca(b),b],c,Array.prototype.slice.call(arguments,2));return b};
J.o.up=function(b,c,d,e){!J.o.ma||b instanceof c||J.o.Aa("Expected instanceof %s but got %s.",[J.o.ag(c),J.o.ag(b)],d,Array.prototype.slice.call(arguments,3));return b};J.o.sp=function(b,c,d){!J.o.ma||typeof b==v&&isFinite(b)||J.o.Aa("Expected %s to be a finite number but it is not.",[b],c,Array.prototype.slice.call(arguments,2));return b};J.o.Jp=function(){for(var b in Object.prototype)J.o.ha(b+" should not be enumerable in Object.prototype.")};
J.o.ag=function(b){return b instanceof Function?b.displayName||b.name||"unknown type name":b instanceof Object?b.constructor.displayName||b.constructor.name||Object.prototype.toString.call(b):null===b?"null":typeof b};J.j={};J.Fa=J.Xc;J.j.Ca=!1;J.j.Lk=function(b){return b[b.length-1]};J.j.os=J.j.Lk;J.j.indexOf=J.Fa&&(J.j.Ca||Array.prototype.indexOf)?function(b,c,d){return Array.prototype.indexOf.call(b,c,d)}:function(b,c,d){d=null==d?0:0>d?Math.max(0,b.length+d):d;if(J.N(b))return J.N(c)&&1==c.length?b.indexOf(c,d):-1;for(;d<b.length;d++)if(d in b&&b[d]===c)return d;return-1};
J.j.lastIndexOf=J.Fa&&(J.j.Ca||Array.prototype.lastIndexOf)?function(b,c,d){return Array.prototype.lastIndexOf.call(b,c,null==d?b.length-1:d)}:function(b,c,d){d=null==d?b.length-1:d;0>d&&(d=Math.max(0,b.length+d));if(J.N(b))return J.N(c)&&1==c.length?b.lastIndexOf(c,d):-1;for(;0<=d;d--)if(d in b&&b[d]===c)return d;return-1};
J.j.forEach=J.Fa&&(J.j.Ca||Array.prototype.forEach)?function(b,c,d){Array.prototype.forEach.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)g in f&&c.call(d,f[g],g,b)};J.j.yf=function(b,c){for(var d=J.N(b)?b.split(""):b,e=b.length-1;0<=e;--e)e in d&&c.call(void 0,d[e],e,b)};
J.j.filter=J.Fa&&(J.j.Ca||Array.prototype.filter)?function(b,c,d){return Array.prototype.filter.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=[],g=0,h=J.N(b)?b.split(""):b,l=0;l<e;l++)if(l in h){var m=h[l];c.call(d,m,l,b)&&(f[g++]=m)}return f};J.j.map=J.Fa&&(J.j.Ca||Array.prototype.map)?function(b,c,d){return Array.prototype.map.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=Array(e),g=J.N(b)?b.split(""):b,h=0;h<e;h++)h in g&&(f[h]=c.call(d,g[h],h,b));return f};
J.j.reduce=J.Fa&&(J.j.Ca||Array.prototype.reduce)?function(b,c,d,e){e&&(c=J.bind(c,e));return Array.prototype.reduce.call(b,c,d)}:function(b,c,d,e){var f=d;J.j.forEach(b,function(d,h){f=c.call(e,f,d,h,b)});return f};J.j.reduceRight=J.Fa&&(J.j.Ca||Array.prototype.reduceRight)?function(b,c,d,e){e&&(c=J.bind(c,e));return Array.prototype.reduceRight.call(b,c,d)}:function(b,c,d,e){var f=d;J.j.yf(b,function(d,h){f=c.call(e,f,d,h,b)});return f};
J.j.some=J.Fa&&(J.j.Ca||Array.prototype.some)?function(b,c,d){return Array.prototype.some.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&c.call(d,f[g],g,b))return!0;return!1};J.j.every=J.Fa&&(J.j.Ca||Array.prototype.every)?function(b,c,d){return Array.prototype.every.call(b,c,d)}:function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&!c.call(d,f[g],g,b))return!1;return!0};
J.j.count=function(b,c,d){var e=0;J.j.forEach(b,function(b,g,h){c.call(d,b,g,h)&&++e},d);return e};J.j.find=function(b,c,d){c=J.j.findIndex(b,c,d);return 0>c?null:J.N(b)?b.charAt(c):b[c]};J.j.findIndex=function(b,c,d){for(var e=b.length,f=J.N(b)?b.split(""):b,g=0;g<e;g++)if(g in f&&c.call(d,f[g],g,b))return g;return-1};J.j.Kq=function(b,c,d){c=J.j.tj(b,c,d);return 0>c?null:J.N(b)?b.charAt(c):b[c]};
J.j.tj=function(b,c,d){for(var e=J.N(b)?b.split(""):b,f=b.length-1;0<=f;f--)if(f in e&&c.call(d,e[f],f,b))return f;return-1};J.j.contains=function(b,c){return 0<=J.j.indexOf(b,c)};J.j.Qb=function(b){return 0==b.length};J.j.clear=function(b){if(!J.isArray(b))for(var c=b.length-1;0<=c;c--)delete b[c];b.length=0};J.j.Dr=function(b,c){J.j.contains(b,c)||b.push(c)};J.j.hg=function(b,c,d){J.j.splice(b,d,0,c)};J.j.Fr=function(b,c,d){J.eb(J.j.splice,b,d,0).apply(null,c)};
J.j.insertBefore=function(b,c,d){var e;2==arguments.length||0>(e=J.j.indexOf(b,d))?b.push(c):J.j.hg(b,c,e)};J.j.remove=function(b,c){c=J.j.indexOf(b,c);var d;(d=0<=c)&&J.j.wb(b,c);return d};J.j.Ys=function(b,c){c=J.j.lastIndexOf(b,c);return 0<=c?(J.j.wb(b,c),!0):!1};J.j.wb=function(b,c){return 1==Array.prototype.splice.call(b,c,1).length};J.j.Xs=function(b,c,d){c=J.j.findIndex(b,c,d);return 0<=c?(J.j.wb(b,c),!0):!1};
J.j.Us=function(b,c,d){var e=0;J.j.yf(b,function(f,g){c.call(d,f,g,b)&&J.j.wb(b,g)&&e++});return e};J.j.concat=function(b){return Array.prototype.concat.apply([],arguments)};J.j.join=function(b){return Array.prototype.concat.apply([],arguments)};J.j.jh=function(b){var c=b.length;if(0<c){for(var d=Array(c),e=0;e<c;e++)d[e]=b[e];return d}return[]};J.j.clone=J.j.jh;
J.j.extend=function(b,c){for(var d=1;d<arguments.length;d++){var e=arguments[d];if(J.Nb(e)){var f=b.length||0,g=e.length||0;b.length=f+g;for(var h=0;h<g;h++)b[f+h]=e[h]}else b.push(e)}};J.j.splice=function(b,c,d,e){return Array.prototype.splice.apply(b,J.j.slice(arguments,1))};J.j.slice=function(b,c,d){return 2>=arguments.length?Array.prototype.slice.call(b,c):Array.prototype.slice.call(b,c,d)};
J.j.Vs=function(b,c,d){function e(b){return J.ka(b)?"o"+J.bg(b):(typeof b).charAt(0)+b}c=c||b;d=d||e;for(var f={},g=0,h=0;h<b.length;){var l=b[h++],m=d(l);Object.prototype.hasOwnProperty.call(f,m)||(f[m]=!0,c[g++]=l)}c.length=g};J.j.Ze=function(b,c,d){return J.j.$e(b,d||J.j.Oa,!1,c)};J.j.Op=function(b,c,d){return J.j.$e(b,c,!0,void 0,d)};J.j.$e=function(b,c,d,e,f){for(var g=0,h=b.length,l;g<h;){var m=g+h>>1;var r=d?c.call(f,b[m],m,b):c(e,b[m]);0<r?g=m+1:(h=m,l=!r)}return l?g:~g};
J.j.sort=function(b,c){b.sort(c||J.j.Oa)};J.j.Rt=function(b,c){for(var d=Array(b.length),e=0;e<b.length;e++)d[e]={index:e,value:b[e]};var f=c||J.j.Oa;J.j.sort(d,function(b,c){return f(b.value,c.value)||b.index-c.index});for(e=0;e<b.length;e++)b[e]=d[e].value};J.j.ml=function(b,c,d){var e=d||J.j.Oa;J.j.sort(b,function(b,d){return e(c(b),c(d))})};J.j.Ot=function(b,c,d){J.j.ml(b,function(b){return b[c]},d)};
J.j.js=function(b,c,d){c=c||J.j.Oa;for(var e=1;e<b.length;e++){var f=c(b[e-1],b[e]);if(0<f||0==f&&d)return!1}return!0};J.j.Ib=function(b,c){if(!J.Nb(b)||!J.Nb(c)||b.length!=c.length)return!1;for(var d=b.length,e=J.j.gj,f=0;f<d;f++)if(!e(b[f],c[f]))return!1;return!0};J.j.cq=function(b,c,d){d=d||J.j.Oa;for(var e=Math.min(b.length,c.length),f=0;f<e;f++){var g=d(b[f],c[f]);if(0!=g)return g}return J.j.Oa(b.length,c.length)};J.j.Oa=function(b,c){return b>c?1:b<c?-1:0};
J.j.Hr=function(b,c){return-J.j.Oa(b,c)};J.j.gj=function(b,c){return b===c};J.j.Mp=function(b,c,d){d=J.j.Ze(b,c,d);return 0>d?(J.j.hg(b,c,-(d+1)),!0):!1};J.j.Np=function(b,c,d){c=J.j.Ze(b,c,d);return 0<=c?J.j.wb(b,c):!1};J.j.Qp=function(b,c,d){for(var e={},f=0;f<b.length;f++){var g=b[f],h=c.call(d,g,f,b);J.W(h)&&(e[h]||(e[h]=[])).push(g)}return e};J.j.au=function(b,c,d){var e={};J.j.forEach(b,function(f,g){e[c.call(d,f,g,b)]=f});return e};
J.j.Qs=function(b,c,d){var e=[],f=0,g=b;d=d||1;void 0!==c&&(f=b,g=c);if(0>d*(g-f))return[];if(0<d)for(b=f;b<g;b+=d)e.push(b);else for(b=f;b>g;b+=d)e.push(b);return e};J.j.repeat=function(b,c){for(var d=[],e=0;e<c;e++)d[e]=b;return d};J.j.flatten=function(b){for(var c=[],d=0;d<arguments.length;d++){var e=arguments[d];if(J.isArray(e))for(var f=0;f<e.length;f+=8192)for(var g=J.j.flatten.apply(null,J.j.slice(e,f,f+8192)),h=0;h<g.length;h++)c.push(g[h]);else c.push(e)}return c};
J.j.rotate=function(b,c){b.length&&(c%=b.length,0<c?Array.prototype.unshift.apply(b,b.splice(-c,c)):0>c&&Array.prototype.push.apply(b,b.splice(0,-c)));return b};J.j.As=function(b,c,d){c=Array.prototype.splice.call(b,c,1);Array.prototype.splice.call(b,d,0,c[0])};
J.j.qu=function(b){if(!arguments.length)return[];for(var c=[],d=arguments[0].length,e=1;e<arguments.length;e++)arguments[e].length<d&&(d=arguments[e].length);for(e=0;e<d;e++){for(var f=[],g=0;g<arguments.length;g++)f.push(arguments[g][e]);c.push(f)}return c};J.j.Nt=function(b,c){c=c||Math.random;for(var d=b.length-1;0<d;d--){var e=Math.floor(c()*(d+1)),f=b[d];b[d]=b[e];b[e]=f}};J.j.iq=function(b,c){var d=[];J.j.forEach(c,function(c){d.push(b[c])});return d};
J.j.fq=function(b,c,d){return J.j.concat.apply([],J.j.map(b,c,d))};J.async={};J.async.Xb=function(b,c,d){this.tk=d;this.dj=b;this.Pk=c;this.vc=0;this.qc=null};J.async.Xb.prototype.get=function(){if(0<this.vc){this.vc--;var b=this.qc;this.qc=b.next;b.next=null}else b=this.dj();return b};J.async.Xb.prototype.put=function(b){this.Pk(b);this.vc<this.tk&&(this.vc++,b.next=this.qc,this.qc=b)};J.debug.aa={};J.debug.Tm=D();J.debug.aa.vb=[];J.debug.aa.Qd=[];J.debug.aa.Mg=!1;J.debug.aa.register=function(b){J.debug.aa.vb[J.debug.aa.vb.length]=b;if(J.debug.aa.Mg)for(var c=J.debug.aa.Qd,d=0;d<c.length;d++)b(J.bind(c[d].Ml,c[d]))};J.debug.aa.zs=function(b){J.debug.aa.Mg=!0;for(var c=J.bind(b.Ml,b),d=0;d<J.debug.aa.vb.length;d++)J.debug.aa.vb[d](c);J.debug.aa.Qd.push(b)};J.debug.aa.ju=function(b){var c=J.debug.aa.Qd;b=J.bind(b.s,b);for(var d=0;d<J.debug.aa.vb.length;d++)J.debug.aa.vb[d](b);c.length--};J.a.on=D();J.a.c=function(b){this.rl=b};J.a.c.prototype.toString=E("rl");J.a.c.Nl=new J.a.c("A");J.a.c.Ol=new J.a.c("ABBR");J.a.c.Ql=new J.a.c("ACRONYM");J.a.c.Rl=new J.a.c("ADDRESS");J.a.c.Vl=new J.a.c("APPLET");J.a.c.Wl=new J.a.c("AREA");J.a.c.Xl=new J.a.c("ARTICLE");J.a.c.Yl=new J.a.c("ASIDE");J.a.c.bm=new J.a.c("AUDIO");J.a.c.cm=new J.a.c("B");J.a.c.dm=new J.a.c("BASE");J.a.c.em=new J.a.c("BASEFONT");J.a.c.fm=new J.a.c("BDI");J.a.c.gm=new J.a.c("BDO");J.a.c.jm=new J.a.c("BIG");J.a.c.km=new J.a.c("BLOCKQUOTE");
J.a.c.lm=new J.a.c("BODY");J.a.c.re=new J.a.c("BR");J.a.c.mm=new J.a.c("BUTTON");J.a.c.nm=new J.a.c("CANVAS");J.a.c.om=new J.a.c("CAPTION");J.a.c.qm=new J.a.c("CENTER");J.a.c.rm=new J.a.c("CITE");J.a.c.sm=new J.a.c("CODE");J.a.c.tm=new J.a.c("COL");J.a.c.um=new J.a.c("COLGROUP");J.a.c.vm=new J.a.c("COMMAND");J.a.c.xm=new J.a.c("DATA");J.a.c.ym=new J.a.c("DATALIST");J.a.c.zm=new J.a.c("DD");J.a.c.Am=new J.a.c("DEL");J.a.c.Cm=new J.a.c("DETAILS");J.a.c.Dm=new J.a.c("DFN");J.a.c.Em=new J.a.c("DIALOG");
J.a.c.Fm=new J.a.c("DIR");J.a.c.Gm=new J.a.c("DIV");J.a.c.Hm=new J.a.c("DL");J.a.c.Km=new J.a.c("DT");J.a.c.Nm=new J.a.c("EM");J.a.c.Om=new J.a.c("EMBED");J.a.c.Vm=new J.a.c("FIELDSET");J.a.c.Wm=new J.a.c("FIGCAPTION");J.a.c.Xm=new J.a.c("FIGURE");J.a.c.Ym=new J.a.c("FONT");J.a.c.Zm=new J.a.c("FOOTER");J.a.c.$m=new J.a.c("FORM");J.a.c.an=new J.a.c("FRAME");J.a.c.bn=new J.a.c("FRAMESET");J.a.c.cn=new J.a.c("H1");J.a.c.dn=new J.a.c("H2");J.a.c.en=new J.a.c("H3");J.a.c.fn=new J.a.c("H4");J.a.c.gn=new J.a.c("H5");
J.a.c.hn=new J.a.c("H6");J.a.c.jn=new J.a.c("HEAD");J.a.c.kn=new J.a.c("HEADER");J.a.c.ln=new J.a.c("HGROUP");J.a.c.mn=new J.a.c("HR");J.a.c.nn=new J.a.c("HTML");J.a.c.pn=new J.a.c("I");J.a.c.sn=new J.a.c("IFRAME");J.a.c.tn=new J.a.c("IMG");J.a.c.un=new J.a.c("INPUT");J.a.c.vn=new J.a.c("INS");J.a.c.An=new J.a.c("ISINDEX");J.a.c.Dn=new J.a.c("KBD");J.a.c.En=new J.a.c("KEYGEN");J.a.c.Fn=new J.a.c("LABEL");J.a.c.Hn=new J.a.c("LEGEND");J.a.c.In=new J.a.c("LI");J.a.c.Jn=new J.a.c("LINK");J.a.c.Nn=new J.a.c("MAIN");
J.a.c.On=new J.a.c("MAP");J.a.c.Pn=new J.a.c("MARK");J.a.c.Qn=new J.a.c("MATH");J.a.c.Rn=new J.a.c("MENU");J.a.c.Sn=new J.a.c("MENUITEM");J.a.c.Tn=new J.a.c("META");J.a.c.Un=new J.a.c("METER");J.a.c.Wn=new J.a.c("NAV");J.a.c.Xn=new J.a.c("NOFRAMES");J.a.c.Yn=new J.a.c("NOSCRIPT");J.a.c.ao=new J.a.c("OBJECT");J.a.c.bo=new J.a.c("OL");J.a.c.co=new J.a.c("OPTGROUP");J.a.c.eo=new J.a.c("OPTION");J.a.c.fo=new J.a.c("OUTPUT");J.a.c.ho=new J.a.c("P");J.a.c.io=new J.a.c("PARAM");J.a.c.jo=new J.a.c("PICTURE");
J.a.c.lo=new J.a.c("PRE");J.a.c.no=new J.a.c("PROGRESS");J.a.c.Q=new J.a.c("Q");J.a.c.oo=new J.a.c("RP");J.a.c.po=new J.a.c("RT");J.a.c.qo=new J.a.c("RTC");J.a.c.ro=new J.a.c("RUBY");J.a.c.to=new J.a.c("S");J.a.c.wo=new J.a.c("SAMP");J.a.c.xo=new J.a.c(k);J.a.c.yo=new J.a.c("SECTION");J.a.c.zo=new J.a.c("SELECT");J.a.c.Ao=new J.a.c("SMALL");J.a.c.Bo=new J.a.c("SOURCE");J.a.c.Co=new J.a.c("SPAN");J.a.c.Do=new J.a.c("STRIKE");J.a.c.Eo=new J.a.c("STRONG");J.a.c.Fo=new J.a.c("STYLE");J.a.c.Go=new J.a.c("SUB");
J.a.c.Ho=new J.a.c("SUMMARY");J.a.c.Io=new J.a.c("SUP");J.a.c.Jo=new J.a.c("SVG");J.a.c.Ko=new J.a.c("TABLE");J.a.c.Lo=new J.a.c("TBODY");J.a.c.Mo=new J.a.c("TD");J.a.c.No=new J.a.c("TEMPLATE");J.a.c.Oo=new J.a.c("TEXTAREA");J.a.c.Po=new J.a.c("TFOOT");J.a.c.Qo=new J.a.c("TH");J.a.c.Ro=new J.a.c("THEAD");J.a.c.So=new J.a.c("TIME");J.a.c.To=new J.a.c("TITLE");J.a.c.Uo=new J.a.c("TR");J.a.c.Vo=new J.a.c("TRACK");J.a.c.Zo=new J.a.c("TT");J.a.c.ap=new J.a.c("U");J.a.c.bp=new J.a.c("UL");J.a.c.cp=new J.a.c("VAR");
J.a.c.ep=new J.a.c("VIDEO");J.a.c.fp=new J.a.c("WBR");J.M={};J.M.Xi=function(b){return function(){return b}};J.M.Um=F(!1);J.M.Yo=F(!0);J.M.$n=F(null);J.M.Wj=C();J.M.error=function(b){return function(){throw Error(b);}};J.M.ha=function(b){return function(){throw b;}};J.M.lock=function(b,c){c=c||0;return function(){return b.apply(this,Array.prototype.slice.call(arguments,0,c))}};J.M.Hs=function(b){return function(){return arguments[b]}};
J.M.Ms=function(b,c){var d=Array.prototype.slice.call(arguments,1);return function(){var c=Array.prototype.slice.call(arguments);c.push.apply(c,d);return b.apply(this,c)}};J.M.pu=function(b,c){return J.M.fl(b,J.M.Xi(c))};J.M.Gq=function(b,c){return function(d){return c?b==d:b===d}};J.M.eq=function(b,c){var d=arguments,e=d.length;return function(){var b;e&&(b=d[e-1].apply(this,arguments));for(var c=e-2;0<=c;c--)b=d[c].call(this,b);return b}};
J.M.fl=function(b){var c=arguments,d=c.length;return function(){for(var b,f=0;f<d;f++)b=c[f].apply(this,arguments);return b}};J.M.and=function(b){var c=arguments,d=c.length;return function(){for(var b=0;b<d;b++)if(!c[b].apply(this,arguments))return!1;return!0}};J.M.or=function(b){var c=arguments,d=c.length;return function(){for(var b=0;b<d;b++)if(c[b].apply(this,arguments))return!0;return!1}};J.M.Gs=function(b){return function(){return!b.apply(this,arguments)}};
J.M.create=function(b,c){function d(){}d.prototype=b.prototype;var e=new d;b.apply(e,Array.prototype.slice.call(arguments,1));return e};J.M.Bh=!0;J.M.Ri=function(b){var c=!1,d;return function(){if(!J.M.Bh)return b();c||(d=b(),c=!0);return d}};J.M.once=function(b){var c=b;return function(){if(c){var b=c;c=null;b()}}};J.M.uq=function(b,c,d){var e=0;return function(f){J.global.clearTimeout(e);var g=arguments;e=J.global.setTimeout(function(){b.apply(d,g)},c)}};
J.M.Yt=function(b,c,d){function e(){g=J.global.setTimeout(f,c);b.apply(d,l)}function f(){g=0;h&&(h=!1,e())}var g=0,h=!1,l=[];return function(b){l=arguments;g?h=!0:e()}};J.M.Rs=function(b,c,d){function e(){f=0}var f=0;return function(g){f||(f=J.global.setTimeout(e,c),b.apply(d,arguments))}};J.f={};J.f.Rc=!1;J.f.Ph=!1;J.f.Re={Fe:"\u00a0"};J.f.startsWith=function(b,c){return 0==b.lastIndexOf(c,0)};J.f.endsWith=function(b,c){var d=b.length-c.length;return 0<=d&&b.indexOf(c,d)==d};J.f.bd=function(b,c){return 0==J.f.af(c,b.substr(0,c.length))};J.f.Vp=function(b,c){return 0==J.f.af(c,b.substr(b.length-c.length,c.length))};J.f.Wp=function(b,c){return b.toLowerCase()==c.toLowerCase()};
J.f.Wt=function(b,c){for(var d=b.split("%s"),e="",f=Array.prototype.slice.call(arguments,1);f.length&&1<d.length;)e+=d.shift()+f.shift();return e+d.join("%s")};J.f.bq=function(b){return b.replace(/[\s\xa0]+/g," ").replace(/^\s+|\s+$/g,"")};J.f.Gd=function(b){return/^[\s\xa0]*$/.test(b)};J.f.Rr=function(b){return 0==b.length};J.f.Qb=J.f.Gd;J.f.$j=function(b){return J.f.Gd(J.f.Ek(b))};J.f.Qr=J.f.$j;J.f.Lr=function(b){return!/[^\t\n\r ]/.test(b)};J.f.Ir=function(b){return!/[^a-zA-Z]/.test(b)};
J.f.ds=function(b){return!/[^0-9]/.test(b)};J.f.Jr=function(b){return!/[^a-zA-Z0-9]/.test(b)};J.f.ks=function(b){return" "==b};J.f.ls=function(b){return 1==b.length&&" "<=b&&"~">=b||"\u0080"<=b&&"\ufffd">=b};J.f.Ut=function(b){return b.replace(/(\r\n|\r|\n)+/g," ")};J.f.Ui=function(b){return b.replace(/(\r\n|\r|\n)/g,"\n")};J.f.Fs=function(b){return b.replace(/\xa0|\s/g," ")};J.f.Es=function(b){return b.replace(/\xa0|[ \t]+/g," ")};
J.f.aq=function(b){return b.replace(/[\t\r\n ]+/g," ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g,"")};J.f.trim=J.Xc&&String.prototype.trim?function(b){return b.trim()}:function(b){return/^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(b)[1]};J.f.trimLeft=function(b){return b.replace(/^[\s\xa0]+/,"")};J.f.trimRight=function(b){return b.replace(/[\s\xa0]+$/,"")};J.f.af=function(b,c){b=String(b).toLowerCase();c=String(c).toLowerCase();return b<c?-1:b==c?0:1};
J.f.Og=function(b,c,d){if(b==c)return 0;if(!b)return-1;if(!c)return 1;for(var e=b.toLowerCase().match(d),f=c.toLowerCase().match(d),g=Math.min(e.length,f.length),h=0;h<g;h++){d=e[h];var l=f[h];if(d!=l)return b=parseInt(d,10),!isNaN(b)&&(c=parseInt(l,10),!isNaN(c)&&b-c)?b-c:d<l?-1:1}return e.length!=f.length?e.length-f.length:b<c?-1:1};J.f.Gr=function(b,c){return J.f.Og(b,c,/\d+|\D+/g)};J.f.vj=function(b,c){return J.f.Og(b,c,/\d+|\.\d+|\D+/g)};J.f.Is=J.f.vj;J.f.lu=function(b){return encodeURIComponent(String(b))};
J.f.ku=function(b){return decodeURIComponent(b.replace(/\+/g," "))};J.f.Ng=function(b,c){return b.replace(/(\r\n|\r|\n)/g,c?"<br />":"<br>")};
J.f.va=function(b,c){if(c)b=b.replace(J.f.fe,"&amp;").replace(J.f.Ee,"&lt;").replace(J.f.Be,"&gt;").replace(J.f.Le,"&quot;").replace(J.f.Ne,"&#39;").replace(J.f.Ge,"&#0;"),J.f.Rc&&(b=b.replace(J.f.xe,"&#101;"));else{if(!J.f.th.test(b))return b;-1!=b.indexOf("&")&&(b=b.replace(J.f.fe,"&amp;"));-1!=b.indexOf("<")&&(b=b.replace(J.f.Ee,"&lt;"));-1!=b.indexOf(">")&&(b=b.replace(J.f.Be,"&gt;"));-1!=b.indexOf('"')&&(b=b.replace(J.f.Le,"&quot;"));-1!=b.indexOf("'")&&(b=b.replace(J.f.Ne,"&#39;"));-1!=b.indexOf("\x00")&&
(b=b.replace(J.f.Ge,"&#0;"));J.f.Rc&&-1!=b.indexOf("e")&&(b=b.replace(J.f.xe,"&#101;"))}return b};J.f.fe=/&/g;J.f.Ee=/</g;J.f.Be=/>/g;J.f.Le=/"/g;J.f.Ne=/'/g;J.f.Ge=/\x00/g;J.f.xe=/e/g;J.f.th=J.f.Rc?/[\x00&<>"'e]/:/[\x00&<>"']/;J.f.lh=function(b){return J.f.contains(b,"&")?!J.f.Ph&&"document"in J.global?J.f.mh(b):J.f.zl(b):b};J.f.hu=function(b,c){return J.f.contains(b,"&")?J.f.mh(b,c):b};
J.f.mh=function(b,c){var d={"&amp;":"&","&lt;":"<","&gt;":">","&quot;":'"'};var e=c?c.createElement("div"):J.global.document.createElement("div");return b.replace(J.f.Th,function(b,c){var f=d[b];if(f)return f;"#"==c.charAt(0)&&(c=Number("0"+c.substr(1)),isNaN(c)||(f=String.fromCharCode(c)));f||(e.innerHTML=b+" ",f=e.firstChild.nodeValue.slice(0,-1));return d[b]=f})};
J.f.zl=function(b){return b.replace(/&([^;]+);/g,function(b,d){switch(d){case "amp":return"&";case "lt":return"<";case "gt":return">";case "quot":return'"';default:return"#"!=d.charAt(0)||(d=Number("0"+d.substr(1)),isNaN(d))?b:String.fromCharCode(d)}})};J.f.Th=/&([^;\s<&]+);?/g;J.f.Jl=function(b){return J.f.Ng(b.replace(/  /g," &#160;"),void 0)};J.f.Ns=function(b){return b.replace(/(^|[\n ]) /g,"$1"+J.f.Re.Fe)};
J.f.Vt=function(b,c){for(var d=c.length,e=0;e<d;e++){var f=1==d?c:c.charAt(e);if(b.charAt(0)==f&&b.charAt(b.length-1)==f)return b.substring(1,b.length-1)}return b};J.f.truncate=function(b,c,d){d&&(b=J.f.lh(b));b.length>c&&(b=b.substring(0,c-3)+"...");d&&(b=J.f.va(b));return b};J.f.fu=function(b,c,d,e){d&&(b=J.f.lh(b));e&&b.length>c?(e>c&&(e=c),b=b.substring(0,c-e)+"..."+b.substring(b.length-e)):b.length>c&&(e=Math.floor(c/2),b=b.substring(0,e+c%2)+"..."+b.substring(b.length-e));d&&(b=J.f.va(b));return b};
J.f.Zd={"\x00":"\\0","\b":"\\b","\f":"\\f","\n":"\\n","\r":"\\r","\t":"\\t","\x0B":"\\x0B",'"':'\\"',"\\":"\\\\","<":"<"};J.f.sc={"'":"\\'"};J.f.quote=function(b){b=String(b);for(var c=['"'],d=0;d<b.length;d++){var e=b.charAt(d),f=e.charCodeAt(0);c[d+1]=J.f.Zd[e]||(31<f&&127>f?e:J.f.pf(e))}c.push('"');return c.join("")};J.f.Hq=function(b){for(var c=[],d=0;d<b.length;d++)c[d]=J.f.pf(b.charAt(d));return c.join("")};
J.f.pf=function(b){if(b in J.f.sc)return J.f.sc[b];if(b in J.f.Zd)return J.f.sc[b]=J.f.Zd[b];var c=b.charCodeAt(0);if(31<c&&127>c)var d=b;else{if(256>c){if(d="\\x",16>c||256<c)d+="0"}else d="\\u",4096>c&&(d+="0");d+=c.toString(16).toUpperCase()}return J.f.sc[b]=d};J.f.contains=function(b,c){return-1!=b.indexOf(c)};J.f.bf=function(b,c){return J.f.contains(b.toLowerCase(),c.toLowerCase())};J.f.jq=function(b,c){return b&&c?b.split(c).length-1:0};J.f.wb=C();
J.f.remove=function(b,c){return b.replace(c,"")};J.f.Ts=function(b,c){c=new RegExp(J.f.Rd(c),"g");return b.replace(c,"")};J.f.Zs=function(b,c,d){c=new RegExp(J.f.Rd(c),"g");return b.replace(c,d.replace(/\$/g,"$$$$"))};J.f.Rd=function(b){return String(b).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,"\\$1").replace(/\x08/g,"\\x08")};J.f.repeat=String.prototype.repeat?function(b,c){return b.repeat(c)}:function(b,c){return Array(c+1).join(b)};
J.f.Ls=function(b,c,d){b=J.W(d)?b.toFixed(d):String(b);d=b.indexOf(".");-1==d&&(d=b.length);return J.f.repeat("0",Math.max(0,c-d))+b};J.f.Ek=function(b){return null==b?"":String(b)};J.f.Rp=function(b){return Array.prototype.join.call(arguments,"")};J.f.rr=function(){return Math.floor(2147483648*Math.random()).toString(36)+Math.abs(Math.floor(2147483648*Math.random())^J.now()).toString(36)};
J.f.Db=function(b,c){var d=0;b=J.f.trim(String(b)).split(".");c=J.f.trim(String(c)).split(".");for(var e=Math.max(b.length,c.length),f=0;0==d&&f<e;f++){var g=b[f]||"",h=c[f]||"";do{g=/(\d*)(\D*)(.*)/.exec(g)||["","","",""];h=/(\d*)(\D*)(.*)/.exec(h)||["","","",""];if(0==g[0].length&&0==h[0].length)break;d=J.f.cd(0==g[1].length?0:parseInt(g[1],10),0==h[1].length?0:parseInt(h[1],10))||J.f.cd(0==g[2].length,0==h[2].length)||J.f.cd(g[2],h[2]);g=g[3];h=h[3]}while(0==d)}return d};
J.f.cd=function(b,c){return b<c?-1:b>c?1:0};J.f.Ar=function(b){for(var c=0,d=0;d<b.length;++d)c=31*c+b.charCodeAt(d)>>>0;return c};J.f.Al=2147483648*Math.random()|0;J.f.sq=function(){return"goog_"+J.f.Al++};J.f.$t=function(b){var c=Number(b);return 0==c&&J.f.Gd(b)?NaN:c};J.f.Wr=function(b){return/^[a-z]+([A-Z][a-z]*)*$/.test(b)};J.f.ms=function(b){return/^([A-Z][a-z]*)+$/.test(b)};J.f.Zt=function(b){return String(b).replace(/\-([a-z])/g,function(b,d){return d.toUpperCase()})};
J.f.bu=function(b){return String(b).replace(/([A-Z])/g,"-$1").toLowerCase()};J.f.cu=function(b,c){c=J.N(c)?J.f.Rd(c):"\\s";return b.replace(new RegExp("(^"+(c?"|["+c+"]+":"")+")([a-z])","g"),function(b,c,f){return c+f.toUpperCase()})};J.f.Up=function(b){return String(b.charAt(0)).toUpperCase()+String(b.substr(1)).toLowerCase()};J.f.parseInt=function(b){isFinite(b)&&(b=String(b));return J.N(b)?/^\s*-?0x/i.test(b)?parseInt(b,16):parseInt(b,10):NaN};
J.f.Pt=function(b,c,d){b=b.split(c);for(var e=[];0<d&&b.length;)e.push(b.shift()),d--;b.length&&e.push(b.join(c));return e};J.f.ps=function(b,c){if(c)typeof c==z&&(c=[c]);else return b;for(var d=-1,e=0;e<c.length;e++)if(""!=c[e]){var f=b.lastIndexOf(c[e]);f>d&&(d=f)}return-1==d?b:b.slice(d+1)};
J.f.Bq=function(b,c){var d=[],e=[];if(b==c)return 0;if(!b.length||!c.length)return Math.max(b.length,c.length);for(var f=0;f<c.length+1;f++)d[f]=f;for(f=0;f<b.length;f++){e[0]=f+1;for(var g=0;g<c.length;g++)e[g+1]=Math.min(e[g]+1,d[g+1]+1,d[g]+Number(b[f]!=c[g]));for(g=0;g<d.length;g++)d[g]=e[g]}return e[c.length]};J.g={};J.g.userAgent={};J.g.userAgent.A={};J.g.userAgent.A.Of=function(){var b=J.g.userAgent.A.Fj();return b&&(b=b.userAgent)?b:""};J.g.userAgent.A.Fj=function(){return J.global.navigator};J.g.userAgent.A.nh=J.g.userAgent.A.Of();J.g.userAgent.A.Kt=function(b){J.g.userAgent.A.nh=b||J.g.userAgent.A.Of()};J.g.userAgent.A.pb=function(){return J.g.userAgent.A.nh};J.g.userAgent.A.L=function(b){return J.f.contains(J.g.userAgent.A.pb(),b)};
J.g.userAgent.A.Jg=function(b){return J.f.bf(J.g.userAgent.A.pb(),b)};J.g.userAgent.A.sf=function(b){for(var c=/(\w[\w ]+)\/([^\s]+)\s*(?:\((.*?)\))?/g,d=[],e;e=c.exec(b);)d.push([e[1],e[2],e[3]||void 0]);return d};J.object={};J.object.is=function(b,c){return b===c?0!==b||1/b===1/c:b!==b&&c!==c};J.object.forEach=function(b,c,d){for(var e in b)c.call(d,b[e],e,b)};J.object.filter=function(b,c,d){var e={},f;for(f in b)c.call(d,b[f],f,b)&&(e[f]=b[f]);return e};J.object.map=function(b,c,d){var e={},f;for(f in b)e[f]=c.call(d,b[f],f,b);return e};J.object.some=function(b,c,d){for(var e in b)if(c.call(d,b[e],e,b))return!0;return!1};J.object.every=function(b,c,d){for(var e in b)if(!c.call(d,b[e],e,b))return!1;return!0};
J.object.er=function(b){var c=0,d;for(d in b)c++;return c};J.object.cr=function(b){for(var c in b)return c};J.object.dr=function(b){for(var c in b)return b[c]};J.object.contains=function(b,c){return J.object.Zi(b,c)};J.object.ur=function(b){var c=[],d=0,e;for(e in b)c[d++]=b[e];return c};J.object.Mf=function(b){var c=[],d=0,e;for(e in b)c[d++]=e;return c};J.object.tr=function(b,c){var d=J.Nb(c),e=d?c:arguments;for(d=d?0:1;d<e.length;d++){if(null==b)return;b=b[e[d]]}return b};
J.object.Yi=function(b,c){return null!==b&&c in b};J.object.Zi=function(b,c){for(var d in b)if(b[d]==c)return!0;return!1};J.object.uj=function(b,c,d){for(var e in b)if(c.call(d,b[e],e,b))return e};J.object.Lq=function(b,c,d){return(c=J.object.uj(b,c,d))&&b[c]};J.object.Qb=function(b){for(var c in b)return!1;return!0};J.object.clear=function(b){for(var c in b)delete b[c]};J.object.remove=function(b,c){var d;(d=c in b)&&delete b[c];return d};
J.object.add=function(b,c,d){if(null!==b&&c in b)throw Error('The object already contains the key "'+c+'"');J.object.set(b,c,d)};J.object.get=function(b,c,d){return null!==b&&c in b?b[c]:d};J.object.set=function(b,c,d){b[c]=d};J.object.xt=function(b,c,d){return c in b?b[c]:b[c]=d};J.object.Mt=function(b,c,d){if(c in b)return b[c];d=d();return b[c]=d};J.object.Ib=function(b,c){for(var d in b)if(!(d in c)||b[d]!==c[d])return!1;for(d in c)if(!(d in b))return!1;return!0};
J.object.clone=function(b){var c={},d;for(d in b)c[d]=b[d];return c};J.object.Bl=function(b){var c=J.ca(b);if(c==w||c==n){if(J.Ba(b.clone))return b.clone();c=c==n?[]:{};for(var d in b)c[d]=J.object.Bl(b[d]);return c}return b};J.object.eu=function(b){var c={},d;for(d in b)c[b[d]]=d;return c};J.object.Ke=["constructor",u,"isPrototypeOf",y,B,"toString","valueOf"];
J.object.extend=function(b,c){for(var d,e,f=1;f<arguments.length;f++){e=arguments[f];for(d in e)b[d]=e[d];for(var g=0;g<J.object.Ke.length;g++)d=J.object.Ke[g],Object.prototype.hasOwnProperty.call(e,d)&&(b[d]=e[d])}};J.object.create=function(b){var c=arguments.length;if(1==c&&J.isArray(arguments[0]))return J.object.create.apply(null,arguments[0]);if(c%2)throw Error("Uneven number of arguments");for(var d={},e=0;e<c;e+=2)d[arguments[e]]=arguments[e+1];return d};
J.object.bj=function(b){var c=arguments.length;if(1==c&&J.isArray(arguments[0]))return J.object.bj.apply(null,arguments[0]);for(var d={},e=0;e<c;e++)d[arguments[e]]=!0;return d};J.object.lq=function(b){var c=b;Object.isFrozen&&!Object.isFrozen(b)&&(c=Object.create(b),Object.freeze(c));return c};J.object.Tr=function(b){return!!Object.isFrozen&&Object.isFrozen(b)};
J.object.ar=function(b,c,d){if(!b)return[];if(!Object.getOwnPropertyNames||!Object.getPrototypeOf)return J.object.Mf(b);for(var e={};b&&(b!==Object.prototype||c)&&(b!==Function.prototype||d);){for(var f=Object.getOwnPropertyNames(b),g=0;g<f.length;g++)e[f[g]]=!0;b=Object.getPrototypeOf(b)}return J.object.Mf(e)};J.g.userAgent.w={};J.g.userAgent.w.Hg=function(){return J.g.userAgent.A.L("Opera")};J.g.userAgent.w.Hk=function(){return J.g.userAgent.A.L("Trident")||J.g.userAgent.A.L("MSIE")};J.g.userAgent.w.Od=function(){return J.g.userAgent.A.L("Edge")};J.g.userAgent.w.Pd=function(){return J.g.userAgent.A.L("Firefox")||J.g.userAgent.A.L("FxiOS")};
J.g.userAgent.w.Ig=function(){return J.g.userAgent.A.L("Safari")&&!(J.g.userAgent.w.Md()||J.g.userAgent.w.Nd()||J.g.userAgent.w.Hg()||J.g.userAgent.w.Od()||J.g.userAgent.w.Pd()||J.g.userAgent.w.Ag()||J.g.userAgent.A.L("Android"))};J.g.userAgent.w.Nd=function(){return J.g.userAgent.A.L("Coast")};J.g.userAgent.w.Ik=function(){return(J.g.userAgent.A.L("iPad")||J.g.userAgent.A.L("iPhone"))&&!J.g.userAgent.w.Ig()&&!J.g.userAgent.w.Md()&&!J.g.userAgent.w.Nd()&&!J.g.userAgent.w.Pd()&&J.g.userAgent.A.L("AppleWebKit")};
J.g.userAgent.w.Md=function(){return(J.g.userAgent.A.L("Chrome")||J.g.userAgent.A.L("CriOS"))&&!J.g.userAgent.w.Od()};J.g.userAgent.w.Gk=function(){return J.g.userAgent.A.L("Android")&&!(J.g.userAgent.w.og()||J.g.userAgent.w.ak()||J.g.userAgent.w.Kd()||J.g.userAgent.w.Ag())};J.g.userAgent.w.Kd=J.g.userAgent.w.Hg;J.g.userAgent.w.rc=J.g.userAgent.w.Hk;J.g.userAgent.w.Ra=J.g.userAgent.w.Od;J.g.userAgent.w.ak=J.g.userAgent.w.Pd;J.g.userAgent.w.hs=J.g.userAgent.w.Ig;J.g.userAgent.w.Nr=J.g.userAgent.w.Nd;
J.g.userAgent.w.Vr=J.g.userAgent.w.Ik;J.g.userAgent.w.og=J.g.userAgent.w.Md;J.g.userAgent.w.Kr=J.g.userAgent.w.Gk;J.g.userAgent.w.Ag=function(){return J.g.userAgent.A.L("Silk")};
J.g.userAgent.w.Lb=function(){function b(b){b=J.j.find(b,e);return d[b]||""}var c=J.g.userAgent.A.pb();if(J.g.userAgent.w.rc())return J.g.userAgent.w.Ej(c);c=J.g.userAgent.A.sf(c);var d={};J.j.forEach(c,function(b){d[b[0]]=b[1]});var e=J.eb(J.object.Yi,d);return J.g.userAgent.w.Kd()?b(["Version","Opera"]):J.g.userAgent.w.Ra()?b(["Edge"]):J.g.userAgent.w.og()?b(["Chrome","CriOS"]):(c=c[2])&&c[1]||""};J.g.userAgent.w.xa=function(b){return 0<=J.f.Db(J.g.userAgent.w.Lb(),b)};
J.g.userAgent.w.Ej=function(b){var c=/rv: *([\d\.]*)/.exec(b);if(c&&c[1])return c[1];c="";var d=/MSIE +([\d\.]+)/.exec(b);if(d&&d[1])if(b=/Trident\/(\d.\d)/.exec(b),"7.0"==d[1])if(b&&b[1])switch(b[1]){case "4.0":c="8.0";break;case "5.0":c="9.0";break;case "6.0":c="10.0";break;case "7.0":c="11.0"}else c="7.0";else c=d[1];return c};J.g.userAgent.V={};J.g.userAgent.V.jk=function(){return J.g.userAgent.A.L("Presto")};J.g.userAgent.V.mk=function(){return J.g.userAgent.A.L("Trident")||J.g.userAgent.A.L("MSIE")};J.g.userAgent.V.Ra=function(){return J.g.userAgent.A.L("Edge")};J.g.userAgent.V.Cg=function(){return J.g.userAgent.A.Jg("WebKit")&&!J.g.userAgent.V.Ra()};J.g.userAgent.V.bk=function(){return J.g.userAgent.A.L("Gecko")&&!J.g.userAgent.V.Cg()&&!J.g.userAgent.V.mk()&&!J.g.userAgent.V.Ra()};
J.g.userAgent.V.Lb=function(){var b=J.g.userAgent.A.pb();if(b){b=J.g.userAgent.A.sf(b);var c=J.g.userAgent.V.Cj(b);if(c)return"Gecko"==c[0]?J.g.userAgent.V.Nj(b):c[1];b=b[0];var d;if(b&&(d=b[2])&&(d=/Trident\/([^\s;]+)/.exec(d)))return d[1]}return""};J.g.userAgent.V.Cj=function(b){if(!J.g.userAgent.V.Ra())return b[1];for(var c=0;c<b.length;c++){var d=b[c];if("Edge"==d[0])return d}};J.g.userAgent.V.xa=function(b){return 0<=J.f.Db(J.g.userAgent.V.Lb(),b)};
J.g.userAgent.V.Nj=function(b){return(b=J.j.find(b,function(b){return"Firefox"==b[0]}))&&b[1]||""};J.async.gh=function(b){J.global.setTimeout(function(){throw b;},0)};J.async.qa=function(b,c,d){var e=b;c&&(e=J.bind(b,c));e=J.async.qa.ph(e);J.Ba(J.global.setImmediate)&&(d||J.async.qa.Fl())?J.global.setImmediate(e):(J.async.qa.Yg||(J.async.qa.Yg=J.async.qa.Jj()),J.async.qa.Yg(e))};J.async.qa.Fl=function(){return J.global.Window&&J.global.Window.prototype&&!J.g.userAgent.w.Ra()&&J.global.Window.prototype.setImmediate==J.global.setImmediate?!1:!0};
J.async.qa.Jj=function(){var b=J.global.MessageChannel;"undefined"===typeof b&&"undefined"!==typeof window&&window.postMessage&&window.addEventListener&&!J.g.userAgent.V.jk()&&(b=function(){var b=document.createElement("IFRAME");b.style.display="none";b.src="";document.documentElement.appendChild(b);var c=b.contentWindow;b=c.document;b.open();b.write("");b.close();var d="callImmediate"+Math.random(),e="file:"==c.location.protocol?"*":c.location.protocol+"//"+c.location.host;b=J.bind(function(b){if(("*"==
e||b.origin==e)&&b.data==d)this.port1.onmessage()},this);c.addEventListener("message",b,!1);this.port1={};this.port2={postMessage:function(){c.postMessage(d,e)}}});if("undefined"!==typeof b&&!J.g.userAgent.w.rc()){var c=new b,d={},e=d;c.port1.onmessage=function(){if(J.W(d.next)){d=d.next;var b=d.cf;d.cf=null;b()}};return function(b){e.next={cf:b};e=e.next;c.port2.postMessage(0)}}return"undefined"!==typeof document&&"onreadystatechange"in document.createElement(k)?function(b){var c=document.createElement(k);
c.onreadystatechange=function(){c.onreadystatechange=null;c.parentNode.removeChild(c);c=null;b();b=null};document.documentElement.appendChild(c)}:function(b){J.global.setTimeout(b,0)}};J.async.qa.ph=J.M.Wj;J.debug.aa.register(function(b){J.async.qa.ph=b});J.async.Ga=function(){this.Lc=this.yb=null};J.async.Ga.Qc=100;J.async.Ga.Kb=new J.async.Xb(function(){return new J.async.Yc},function(b){b.reset()},J.async.Ga.Qc);J.async.Ga.prototype.add=function(b,c){var d=J.async.Ga.Kb.get();d.set(b,c);this.Lc?this.Lc.next=d:this.yb=d;this.Lc=d};J.async.Ga.prototype.remove=function(){var b=null;this.yb&&(b=this.yb,this.yb=this.yb.next,this.yb||(this.Lc=null),b.next=null);return b};J.async.Yc=function(){this.next=this.scope=this.nd=null};
J.async.Yc.prototype.set=function(b,c){this.nd=b;this.scope=c;this.next=null};J.async.Yc.prototype.reset=function(){this.next=this.scope=this.nd=null};J.xh=!1;J.async.P=function(b,c){J.async.P.Ec||J.async.P.Xj();J.async.P.Kc||(J.async.P.Ec(),J.async.P.Kc=!0);J.async.P.ee.add(b,c)};J.async.P.Xj=function(){if(J.xh||J.global.Promise&&J.global.Promise.resolve){var b=J.global.Promise.resolve(void 0);J.async.P.Ec=function(){b.then(J.async.P.Ac)}}else J.async.P.Ec=function(){J.async.qa(J.async.P.Ac)}};J.async.P.Nq=function(b){J.async.P.Ec=function(){J.async.qa(J.async.P.Ac);b&&b(J.async.P.Ac)}};J.async.P.Kc=!1;J.async.P.ee=new J.async.Ga;
J.Z&&(J.async.P.bt=function(){J.async.P.Kc=!1;J.async.P.ee=new J.async.Ga});J.async.P.Ac=function(){for(var b;b=J.async.P.ee.remove();){try{b.nd.call(b.scope)}catch(c){J.async.gh(c)}J.async.Ga.Kb.put(b)}J.async.P.Kc=!1};J.a.o={};J.a.o.Fp=D();J.a.o.Zc=C();J.a.o.vp=D();J.a.o.Ei=function(b){return J.a.o.Zc(b)};J.a.o.Bp=D();J.a.o.Ap=D();J.a.o.wp=D();J.a.o.Ep=D();J.a.o.Gi=function(b){return J.a.o.Zc(b)};J.a.o.xp=D();J.a.o.Fi=function(b){return J.a.o.Zc(b)};J.a.o.yp=D();J.a.o.zp=D();J.a.o.Cp=D();J.a.o.Dp=D();J.a.o.vq=function(b){return J.ka(b)?b.constructor.displayName||b.constructor.name||Object.prototype.toString.call(b):void 0===b?"undefined":null===b?"null":typeof b};
J.a.o.nc=function(b){return(b=b&&b.ownerDocument)&&(b.defaultView||b.parentWindow)||J.global};J.g.userAgent.platform={};J.g.userAgent.platform.ng=function(){return J.g.userAgent.A.L("Android")};J.g.userAgent.platform.xg=function(){return J.g.userAgent.A.L("iPod")};J.g.userAgent.platform.wg=function(){return J.g.userAgent.A.L("iPhone")&&!J.g.userAgent.A.L("iPod")&&!J.g.userAgent.A.L("iPad")};J.g.userAgent.platform.vg=function(){return J.g.userAgent.A.L("iPad")};J.g.userAgent.platform.ug=function(){return J.g.userAgent.platform.wg()||J.g.userAgent.platform.vg()||J.g.userAgent.platform.xg()};
J.g.userAgent.platform.yg=function(){return J.g.userAgent.A.L("Macintosh")};J.g.userAgent.platform.gk=function(){return J.g.userAgent.A.L("Linux")};J.g.userAgent.platform.Eg=function(){return J.g.userAgent.A.L("Windows")};J.g.userAgent.platform.pg=function(){return J.g.userAgent.A.L("CrOS")};J.g.userAgent.platform.Mr=function(){return J.g.userAgent.A.L("CrKey")};J.g.userAgent.platform.ek=function(){return J.g.userAgent.A.Jg("KaiOS")};
J.g.userAgent.platform.Lb=function(){var b=J.g.userAgent.A.pb(),c="";J.g.userAgent.platform.Eg()?(c=/Windows (?:NT|Phone) ([0-9.]+)/,c=(b=c.exec(b))?b[1]:"0.0"):J.g.userAgent.platform.ug()?(c=/(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/,c=(b=c.exec(b))&&b[1].replace(/_/g,".")):J.g.userAgent.platform.yg()?(c=/Mac OS X ([0-9_.]+)/,c=(b=c.exec(b))?b[1].replace(/_/g,"."):"10"):J.g.userAgent.platform.ng()?(c=/Android\s+([^\);]+)(\)|;)/,c=(b=c.exec(b))&&b[1]):J.g.userAgent.platform.pg()&&(c=/(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/,
c=(b=c.exec(b))&&b[1]);return c||""};J.g.userAgent.platform.xa=function(b){return 0<=J.f.Db(J.g.userAgent.platform.Lb(),b)};J.Ia={};J.Ia.object=function(b,c){return c};J.Ia.Yd=function(b){J.Ia.Yd[" "](b);return b};J.Ia.Yd[" "]=J.cb;J.Ia.Sp=function(b,c){try{return J.Ia.Yd(b[c]),!0}catch(d){}return!1};J.Ia.cache=function(b,c,d,e){e=e?e(c):c;return Object.prototype.hasOwnProperty.call(b,e)?b[e]:b[e]=d(c)};J.userAgent={};J.userAgent.je=!1;J.userAgent.he=!1;J.userAgent.ie=!1;J.userAgent.oe=!1;J.userAgent.Pc=!1;J.userAgent.me=!1;J.userAgent.uh=!1;J.userAgent.zb=J.userAgent.je||J.userAgent.he||J.userAgent.ie||J.userAgent.Pc||J.userAgent.oe||J.userAgent.me;J.userAgent.Mj=function(){return J.g.userAgent.A.pb()};J.userAgent.zd=function(){return J.global.navigator||null};J.userAgent.nr=function(){return J.userAgent.zd()};J.userAgent.Ie=J.userAgent.zb?J.userAgent.me:J.g.userAgent.w.Kd();
J.userAgent.$=J.userAgent.zb?J.userAgent.je:J.g.userAgent.w.rc();J.userAgent.ve=J.userAgent.zb?J.userAgent.he:J.g.userAgent.V.Ra();J.userAgent.Mm=J.userAgent.ve||J.userAgent.$;J.userAgent.Tc=J.userAgent.zb?J.userAgent.ie:J.g.userAgent.V.bk();J.userAgent.Bb=J.userAgent.zb?J.userAgent.oe||J.userAgent.Pc:J.g.userAgent.V.Cg();J.userAgent.ik=function(){return J.userAgent.Bb&&J.g.userAgent.A.L("Mobile")};J.userAgent.Vn=J.userAgent.Pc||J.userAgent.ik();J.userAgent.uo=J.userAgent.Bb;
J.userAgent.ij=function(){var b=J.userAgent.zd();return b&&b.platform||""};J.userAgent.ko=J.userAgent.ij();J.userAgent.le=!1;J.userAgent.pe=!1;J.userAgent.ke=!1;J.userAgent.qe=!1;J.userAgent.ge=!1;J.userAgent.Nc=!1;J.userAgent.Mc=!1;J.userAgent.Oc=!1;J.userAgent.wh=!1;J.userAgent.za=J.userAgent.le||J.userAgent.pe||J.userAgent.ke||J.userAgent.qe||J.userAgent.ge||J.userAgent.Nc||J.userAgent.Mc||J.userAgent.Oc;J.userAgent.Mn=J.userAgent.za?J.userAgent.le:J.g.userAgent.platform.yg();
J.userAgent.gp=J.userAgent.za?J.userAgent.pe:J.g.userAgent.platform.Eg();J.userAgent.fk=function(){return J.g.userAgent.platform.gk()||J.g.userAgent.platform.pg()};J.userAgent.Kn=J.userAgent.za?J.userAgent.ke:J.userAgent.fk();J.userAgent.rk=function(){var b=J.userAgent.zd();return!!b&&J.f.contains(b.appVersion||"","X11")};J.userAgent.hp=J.userAgent.za?J.userAgent.qe:J.userAgent.rk();J.userAgent.Ul=J.userAgent.za?J.userAgent.ge:J.g.userAgent.platform.ng();
J.userAgent.yn=J.userAgent.za?J.userAgent.Nc:J.g.userAgent.platform.wg();J.userAgent.xn=J.userAgent.za?J.userAgent.Mc:J.g.userAgent.platform.vg();J.userAgent.zn=J.userAgent.za?J.userAgent.Oc:J.g.userAgent.platform.xg();J.userAgent.wn=J.userAgent.za?J.userAgent.Nc||J.userAgent.Mc||J.userAgent.Oc:J.g.userAgent.platform.ug();J.userAgent.Cn=J.userAgent.za?J.userAgent.wh:J.g.userAgent.platform.ek();
J.userAgent.jj=function(){var b="",c=J.userAgent.Oj();c&&(b=c?c[1]:"");return J.userAgent.$&&(c=J.userAgent.Ff(),null!=c&&c>parseFloat(b))?String(c):b};J.userAgent.Oj=function(){var b=J.userAgent.Mj();if(J.userAgent.Tc)return/rv:([^\);]+)(\)|;)/.exec(b);if(J.userAgent.ve)return/Edge\/([\d\.]+)/.exec(b);if(J.userAgent.$)return/\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(b);if(J.userAgent.Bb)return/WebKit\/(\S+)/.exec(b);if(J.userAgent.Ie)return/(?:Version)[ \/]?(\S+)/.exec(b)};
J.userAgent.Ff=function(){var b=J.global.document;return b?b.documentMode:void 0};J.userAgent.VERSION=J.userAgent.jj();J.userAgent.compare=function(b,c){return J.f.Db(b,c)};J.userAgent.pk={};J.userAgent.xa=function(b){return J.userAgent.uh||J.Ia.cache(J.userAgent.pk,b,function(){return 0<=J.f.Db(J.userAgent.VERSION,b)})};J.userAgent.ns=J.userAgent.xa;J.userAgent.Pb=function(b){return Number(J.userAgent.Oh)>=b};J.userAgent.Pr=J.userAgent.Pb;var K;var L=J.global.document,aa=J.userAgent.Ff();
K=L&&J.userAgent.$?aa||("CSS1Compat"==L.compatMode?parseInt(J.userAgent.VERSION,10):5):void 0;J.userAgent.Oh=K;J.a.gb={Ch:!J.userAgent.$||J.userAgent.Pb(9),Dh:!J.userAgent.Tc&&!J.userAgent.$||J.userAgent.$&&J.userAgent.Pb(9)||J.userAgent.Tc&&J.userAgent.xa("1.9.1"),se:J.userAgent.$&&!J.userAgent.xa("9"),Eh:J.userAgent.$||J.userAgent.Ie||J.userAgent.Bb,Uh:J.userAgent.$,Gn:J.userAgent.$&&!J.userAgent.Pb(9)};J.a.tags={};J.a.tags.yi={area:!0,base:!0,br:!0,col:!0,command:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0};J.a.tags.qk=function(b){return!0===J.a.tags.yi[b]};J.f.$o=D();J.f.H=function(b,c){this.be=b===J.f.H.Ae&&c||"";this.ni=J.f.H.Pe};J.f.H.prototype.wa=!0;J.f.H.prototype.ja=E("be");J.f.H.prototype.toString=function(){return"Const{"+this.be+"}"};J.f.H.s=function(b){if(b instanceof J.f.H&&b.constructor===J.f.H&&b.ni===J.f.H.Pe)return b.be;J.o.ha("expected object of type Const, got '"+b+"'");return"type_error:Const"};J.f.H.from=function(b){return new J.f.H(J.f.H.Ae,b)};J.f.H.Pe={};J.f.H.Ae={};J.f.H.EMPTY=J.f.H.from("");J.b={};J.b.O=function(){this.wc="";this.di=J.b.O.da};J.b.O.prototype.wa=!0;J.b.O.da={};J.b.O.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.O.EMPTY:J.b.O.Eb(b)};J.b.O.Rq=function(b,c){for(var d=[],e=1;e<arguments.length;e++)d.push(J.b.O.dh(arguments[e]));return J.b.O.Eb("("+J.f.H.s(b)+")("+d.join(", ")+");")};J.b.O.Vq=function(b){return J.b.O.Eb(J.b.O.dh(b))};J.b.O.prototype.ja=E("wc");J.Z&&(J.b.O.prototype.toString=function(){return"SafeScript{"+this.wc+"}"});
J.b.O.s=function(b){if(b instanceof J.b.O&&b.constructor===J.b.O&&b.di===J.b.O.da)return b.wc;J.o.ha("expected object of type SafeScript, got '"+b+a+J.ca(b));return"type_error:SafeScript"};J.b.O.dh=function(b){return JSON.stringify(b).replace(/</g,"\\x3c")};J.b.O.Eb=function(b){return(new J.b.O).ab(b)};J.b.O.prototype.ab=function(b){this.wc=b;return this};J.b.O.EMPTY=J.b.O.Eb("");J.ua={};J.ua.url={};J.ua.url.$i=function(b){return J.ua.url.cg().createObjectURL(b)};J.ua.url.ct=function(b){J.ua.url.cg().revokeObjectURL(b)};J.ua.url.cg=function(){var b=J.ua.url.wf();if(null!=b)return b;throw Error("This browser doesn't seem to support blob URLs");};J.ua.url.wf=function(){return J.W(J.global.URL)&&J.W(J.global.URL.createObjectURL)?J.global.URL:J.W(J.global.webkitURL)&&J.W(J.global.webkitURL.createObjectURL)?J.global.webkitURL:J.W(J.global.createObjectURL)?J.global:null};
J.ua.url.Pp=function(){return null!=J.ua.url.wf()};J.h={};J.h.i={};J.h.i.Rh=!1;
J.h.i.De=J.h.i.Rh||("ar"==J.I.substring(0,2).toLowerCase()||"fa"==J.I.substring(0,2).toLowerCase()||"he"==J.I.substring(0,2).toLowerCase()||"iw"==J.I.substring(0,2).toLowerCase()||"ps"==J.I.substring(0,2).toLowerCase()||"sd"==J.I.substring(0,2).toLowerCase()||"ug"==J.I.substring(0,2).toLowerCase()||"ur"==J.I.substring(0,2).toLowerCase()||"yi"==J.I.substring(0,2).toLowerCase())&&(2==J.I.length||"-"==J.I.substring(2,3)||"_"==J.I.substring(2,3))||3<=J.I.length&&"ckb"==J.I.substring(0,3).toLowerCase()&&
(3==J.I.length||"-"==J.I.substring(3,4)||"_"==J.I.substring(3,4))||7<=J.I.length&&("-"==J.I.substring(2,3)||"_"==J.I.substring(2,3))&&("adlm"==J.I.substring(3,7).toLowerCase()||"arab"==J.I.substring(3,7).toLowerCase()||"hebr"==J.I.substring(3,7).toLowerCase()||"nkoo"==J.I.substring(3,7).toLowerCase()||"rohg"==J.I.substring(3,7).toLowerCase()||"thaa"==J.I.substring(3,7).toLowerCase())||8<=J.I.length&&("-"==J.I.substring(3,4)||"_"==J.I.substring(3,4))&&("adlm"==J.I.substring(4,8).toLowerCase()||"arab"==
J.I.substring(4,8).toLowerCase()||"hebr"==J.I.substring(4,8).toLowerCase()||"nkoo"==J.I.substring(4,8).toLowerCase()||"rohg"==J.I.substring(4,8).toLowerCase()||"thaa"==J.I.substring(4,8).toLowerCase());J.h.i.kb={Wh:"\u202a",$h:"\u202b",Je:"\u202c",Xh:"\u200e",ai:"\u200f"};J.h.i.S={Ta:1,Ua:-1,sa:0};J.h.i.$b="right";J.h.i.Yb="left";J.h.i.rn=J.h.i.De?J.h.i.Yb:J.h.i.$b;J.h.i.qn=J.h.i.De?J.h.i.$b:J.h.i.Yb;
J.h.i.ul=function(b){return typeof b==v?0<b?J.h.i.S.Ta:0>b?J.h.i.S.Ua:J.h.i.S.sa:null==b?null:b?J.h.i.S.Ua:J.h.i.S.Ta};J.h.i.sb="A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff";J.h.i.xb="\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc";J.h.i.Uj=/<[^>]*>|&[^;]+;/g;J.h.i.Sa=function(b,c){return c?b.replace(J.h.i.Uj,""):b};
J.h.i.Uk=new RegExp("["+J.h.i.xb+"]");J.h.i.Ak=new RegExp("["+J.h.i.sb+"]");J.h.i.Bd=function(b,c){return J.h.i.Uk.test(J.h.i.Sa(b,c))};J.h.i.yr=J.h.i.Bd;J.h.i.fg=function(b){return J.h.i.Ak.test(J.h.i.Sa(b,void 0))};J.h.i.Dk=new RegExp("^["+J.h.i.sb+"]");J.h.i.Zk=new RegExp("^["+J.h.i.xb+"]");J.h.i.kk=function(b){return J.h.i.Zk.test(b)};J.h.i.hk=function(b){return J.h.i.Dk.test(b)};J.h.i.$r=function(b){return!J.h.i.hk(b)&&!J.h.i.kk(b)};J.h.i.Bk=new RegExp("^[^"+J.h.i.xb+"]*["+J.h.i.sb+"]");
J.h.i.Wk=new RegExp("^[^"+J.h.i.sb+"]*["+J.h.i.xb+"]");J.h.i.ah=function(b,c){return J.h.i.Wk.test(J.h.i.Sa(b,c))};J.h.i.gs=J.h.i.ah;J.h.i.nl=function(b,c){return J.h.i.Bk.test(J.h.i.Sa(b,c))};J.h.i.Yr=J.h.i.nl;J.h.i.zg=/^http:\/\/.*/;J.h.i.bs=function(b,c){b=J.h.i.Sa(b,c);return J.h.i.zg.test(b)||!J.h.i.fg(b)&&!J.h.i.Bd(b)};J.h.i.Ck=new RegExp("["+J.h.i.sb+"][^"+J.h.i.xb+"]*$");J.h.i.Xk=new RegExp("["+J.h.i.xb+"][^"+J.h.i.sb+"]*$");J.h.i.mj=function(b,c){return J.h.i.Ck.test(J.h.i.Sa(b,c))};
J.h.i.Xr=J.h.i.mj;J.h.i.nj=function(b,c){return J.h.i.Xk.test(J.h.i.Sa(b,c))};J.h.i.es=J.h.i.nj;J.h.i.Yk=/^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;J.h.i.fs=function(b){return J.h.i.Yk.test(b)};J.h.i.Pi=/(\(.*?\)+)|(\[.*?\]+)|(\{.*?\}+)|(<.*?>+)/g;J.h.i.xr=function(b,c){c=(void 0===c?J.h.i.Bd(b):c)?J.h.i.kb.ai:J.h.i.kb.Xh;return b.replace(J.h.i.Pi,c+"$&"+c)};
J.h.i.Eq=function(b){return"<"==b.charAt(0)?b.replace(/<\w+/,"$& dir=rtl"):"\n<span dir=rtl>"+b+"</span>"};J.h.i.Fq=function(b){return J.h.i.kb.$h+b+J.h.i.kb.Je};J.h.i.Cq=function(b){return"<"==b.charAt(0)?b.replace(/<\w+/,"$& dir=ltr"):"\n<span dir=ltr>"+b+"</span>"};J.h.i.Dq=function(b){return J.h.i.kb.Wh+b+J.h.i.kb.Je};J.h.i.kj=/:\s*([.\d][.\w]*)\s+([.\d][.\w]*)\s+([.\d][.\w]*)\s+([.\d][.\w]*)/g;J.h.i.sk=/left/gi;J.h.i.Tk=/right/gi;J.h.i.sl=/%%%%/g;
J.h.i.xs=function(b){return b.replace(J.h.i.kj,":$1 $4 $3 $2").replace(J.h.i.sk,"%%%%").replace(J.h.i.Tk,J.h.i.Yb).replace(J.h.i.sl,J.h.i.$b)};J.h.i.lj=/([\u0591-\u05f2])"/g;J.h.i.ll=/([\u0591-\u05f2])'/g;J.h.i.Cs=function(b){return b.replace(J.h.i.lj,"$1\u05f4").replace(J.h.i.ll,"$1\u05f3")};J.h.i.Kl=/\s+/;J.h.i.Tj=/[\d\u06f0-\u06f9]/;J.h.i.Vk=.4;
J.h.i.qf=function(b,c){var d=0,e=0,f=!1;b=J.h.i.Sa(b,c).split(J.h.i.Kl);for(c=0;c<b.length;c++){var g=b[c];J.h.i.ah(g)?(d++,e++):J.h.i.zg.test(g)?f=!0:J.h.i.fg(g)?e++:J.h.i.Tj.test(g)&&(f=!0)}return 0==e?f?J.h.i.S.Ta:J.h.i.S.sa:d/e>J.h.i.Vk?J.h.i.S.Ua:J.h.i.S.Ta};J.h.i.xq=function(b,c){return J.h.i.qf(b,c)==J.h.i.S.Ua};J.h.i.rt=function(b,c){b&&(c=J.h.i.ul(c))&&(b.style.textAlign=c==J.h.i.S.Ua?J.h.i.$b:J.h.i.Yb,b.dir=c==J.h.i.S.Ua?"rtl":"ltr")};
J.h.i.st=function(b,c){switch(J.h.i.qf(c)){case J.h.i.S.Ta:b.dir="ltr";break;case J.h.i.S.Ua:b.dir="rtl";break;default:b.removeAttribute("dir")}};J.h.i.Lm=D();J.b.C=function(){this.zc="";this.pi=J.b.C.da};J.b.C.prototype.wa=!0;J.b.C.prototype.ja=E("zc");J.b.C.prototype.Dd=!0;J.b.C.prototype.Za=function(){return J.h.i.S.Ta};J.Z&&(J.b.C.prototype.toString=function(){return"TrustedResourceUrl{"+this.zc+"}"});J.b.C.s=function(b){if(b instanceof J.b.C&&b.constructor===J.b.C&&b.pi===J.b.C.da)return b.zc;J.o.ha("expected object of type TrustedResourceUrl, got '"+b+a+J.ca(b));return"type_error:TrustedResourceUrl"};
J.b.C.format=function(b,c){var d=J.f.H.s(b);if(!J.b.C.zh.test(d))throw Error("Invalid TrustedResourceUrl format: "+d);b=d.replace(J.b.C.Sh,function(b,f){if(!Object.prototype.hasOwnProperty.call(c,f))throw Error('Found marker, "'+f+'", in format string, "'+d+'", but no valid label mapping found in args: '+JSON.stringify(c));b=c[f];return b instanceof J.f.H?J.f.H.s(b):encodeURIComponent(String(b))});return J.b.C.Hb(b)};J.b.C.Sh=/%{(\w+)}/g;J.b.C.zh=/^((https:)?\/\/[0-9a-z.:[\]-]+\/|\/[^/\\]|[^:/\\]+\/|[^:/\\]*[?#]|about:blank#)/i;
J.b.C.ti=/^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/;J.b.C.Oq=function(b,c,d,e){b=J.b.C.format(b,c);b=J.b.C.s(b);b=J.b.C.ti.exec(b);c=b[3]||"";return J.b.C.Hb(b[1]+J.b.C.bh("?",b[2]||"",d)+J.b.C.bh("#",c,e))};J.b.C.jc=function(b){return J.b.C.Hb(J.f.H.s(b))};J.b.C.Sq=function(b){for(var c="",d=0;d<b.length;d++)c+=J.f.H.s(b[d]);return J.b.C.Hb(c)};J.b.C.da={};J.b.C.Hb=function(b){var c=new J.b.C;c.zc=b;return c};
J.b.C.bh=function(b,c,d){if(null==d)return c;if(J.N(d))return d?b+encodeURIComponent(d):"";for(var e in d){var f=d[e];f=J.isArray(f)?f:[f];for(var g=0;g<f.length;g++){var h=f[g];null!=h&&(c||(c=b),c+=(c.length>b.length?"&":"")+encodeURIComponent(e)+"="+encodeURIComponent(String(h)))}}return c};J.b.l=function(){this.Ha="";this.gi=J.b.l.da};J.b.l.ga="about:invalid#zClosurez";J.b.l.prototype.wa=!0;J.b.l.prototype.ja=E("Ha");J.b.l.prototype.Dd=!0;J.b.l.prototype.Za=function(){return J.h.i.S.Ta};J.Z&&(J.b.l.prototype.toString=function(){return"SafeUrl{"+this.Ha+"}"});J.b.l.s=function(b){if(b instanceof J.b.l&&b.constructor===J.b.l&&b.gi===J.b.l.da)return b.Ha;J.o.ha("expected object of type SafeUrl, got '"+b+a+J.ca(b));return"type_error:SafeUrl"};J.b.l.jc=function(b){return J.b.l.oa(J.f.H.s(b))};
J.b.Me=/^(?:audio\/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-wav|wav|webm)|image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp)|text\/csv|video\/(?:mpeg|mp4|ogg|webm|quicktime))$/i;J.b.l.Qq=function(b){b=J.b.Me.test(b.type)?J.ua.url.$i(b):J.b.l.ga;return J.b.l.oa(b)};J.b.Jh=/^data:([^;,]*);base64,[a-z0-9+\/]+=*$/i;J.b.l.Tq=function(b){b=b.replace(/(%0A|%0D)/g,"");var c=b.match(J.b.Jh);c=c&&J.b.Me.test(c[1]);return J.b.l.oa(c?b:J.b.l.ga)};
J.b.l.Zq=function(b){J.f.bd(b,"tel:")||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.ki=/^sip[s]?:[+a-z0-9_.!$%&'*\/=^`{|}~-]+@([a-z0-9-]+\.)+[a-z0-9]{2,63}$/i;J.b.l.Xq=function(b){J.b.ki.test(decodeURIComponent(b))||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.Uq=function(b){J.f.bd(b,"fb-messenger://share")||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.Yq=function(b){J.f.bd(b,"sms:")&&J.b.l.lk(b)||(b=J.b.l.ga);return J.b.l.oa(b)};
J.b.l.lk=function(b){var c=b.indexOf("#");0<c&&(b=b.substring(0,c));c=b.match(/[?&]body=/gi);if(!c)return!0;if(1<c.length)return!1;b=b.match(/[?&]body=([^&]*)/)[1];if(!b)return!0;try{decodeURIComponent(b)}catch(d){return!1}return/^(?:[a-z0-9\-_.~]|%[0-9a-f]{2})+$/i.test(b)};J.b.l.kt=function(b,c){return J.b.l.Ud(/^chrome-extension:\/\/([^\/]+)\//,b,c)};J.b.l.mt=function(b,c){return J.b.l.Ud(/^moz-extension:\/\/([^\/]+)\//,b,c)};
J.b.l.lt=function(b,c){return J.b.l.Ud(/^ms-browser-extension:\/\/([^\/]+)\//,b,c)};J.b.l.Ud=function(b,c,d){(b=b.exec(c))?(b=b[1],-1==(d instanceof J.f.H?[J.f.H.s(d)]:d.map(function(b){return J.f.H.s(b)})).indexOf(b)&&(c=J.b.l.ga)):c=J.b.l.ga;return J.b.l.oa(c)};J.b.l.$q=function(b){return J.b.l.oa(J.b.C.s(b))};J.b.Wc=/^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i;J.b.l.vo=J.b.Wc;
J.b.l.Dc=function(b){if(b instanceof J.b.l)return b;b=typeof b==w&&b.wa?b.ja():String(b);J.b.Wc.test(b)||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.ra=function(b){if(b instanceof J.b.l)return b;b=typeof b==w&&b.wa?b.ja():String(b);J.b.Wc.test(b)||(b=J.b.l.ga);return J.b.l.oa(b)};J.b.l.da={};J.b.l.oa=function(b){var c=new J.b.l;c.Ha=b;return c};J.b.l.Pl=J.b.l.oa("about:blank");J.b.v=function(){this.yc="";this.fi=J.b.v.da};J.b.v.prototype.wa=!0;J.b.v.da={};J.b.v.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.v.EMPTY:J.b.v.Fb(b)};J.b.v.Yp=D();J.b.v.prototype.ja=E("yc");J.Z&&(J.b.v.prototype.toString=function(){return"SafeStyle{"+this.yc+"}"});J.b.v.s=function(b){if(b instanceof J.b.v&&b.constructor===J.b.v&&b.fi===J.b.v.da)return b.yc;J.o.ha("expected object of type SafeStyle, got '"+b+a+J.ca(b));return"type_error:SafeStyle"};J.b.v.Fb=function(b){return(new J.b.v).ab(b)};
J.b.v.prototype.ab=function(b){this.yc=b;return this};J.b.v.EMPTY=J.b.v.Fb("");J.b.v.ga="zClosurez";J.b.v.create=function(b){var c="",d;for(d in b){if(!/^[-_a-zA-Z0-9]+$/.test(d))throw Error("Name allows only [-_a-zA-Z0-9], got: "+d);var e=b[d];null!=e&&(e=J.isArray(e)?J.j.map(e,J.b.v.Ug).join(" "):J.b.v.Ug(e),c+=d+":"+e+";")}return c?J.b.v.Fb(c):J.b.v.EMPTY};
J.b.v.Ug=function(b){return b instanceof J.b.l?'url("'+J.b.l.s(b).replace(/</g,"%3c").replace(/[\\"]/g,"\\$&")+'")':b instanceof J.f.H?J.f.H.s(b):J.b.v.cl(String(b))};
J.b.v.cl=function(b){var c=b.replace(J.b.v.ze,"$1").replace(J.b.v.ze,"$1").replace(J.b.v.Qe,"url");if(J.b.v.vi.test(c)){if(J.b.v.Hh.test(b))return J.o.ha("String value disallows comments, got: "+b),J.b.v.ga;if(!J.b.v.Qj(b))return J.o.ha("String value requires balanced quotes, got: "+b),J.b.v.ga;if(!J.b.v.Rj(b))return J.o.ha("String value requires balanced square brackets and one identifier per pair of brackets, got: "+b),J.b.v.ga}else return J.o.ha("String value allows only "+J.b.v.Te+" and simple functions, got: "+
b),J.b.v.ga;return J.b.v.dl(b)};J.b.v.Qj=function(b){for(var c=!0,d=!0,e=0;e<b.length;e++){var f=b.charAt(e);"'"==f&&d?c=!c:'"'==f&&c&&(d=!d)}return c&&d};J.b.v.Rj=function(b){for(var c=!0,d=/^[-_a-zA-Z0-9]$/,e=0;e<b.length;e++){var f=b.charAt(e);if("]"==f){if(c)return!1;c=!0}else if("["==f){if(!c)return!1;c=!1}else if(!c&&!d.test(f))return!1}return c};J.b.v.Te="[-,.\"'%_!# a-zA-Z0-9\\[\\]]";J.b.v.vi=new RegExp("^"+J.b.v.Te+"+$");J.b.v.Qe=/\b(url\([ \t\n]*)('[ -&(-\[\]-~]*'|"[ !#-\[\]-~]*"|[!#-&*-\[\]-~]*)([ \t\n]*\))/g;
J.b.v.ze=/\b(hsl|hsla|rgb|rgba|matrix|calc|minmax|fit-content|repeat|(rotate|scale|translate)(X|Y|Z|3d)?)\([-+*/0-9a-z.%\[\], ]+\)/g;J.b.v.Hh=/\/\*/;J.b.v.dl=function(b){return b.replace(J.b.v.Qe,function(b,d,e,f){var c="";e=e.replace(/^(['"])(.*)\1$/,function(b,d,e){c=d;return e});b=J.b.l.Dc(e).ja();return d+c+b+c+f})};J.b.v.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):d+=J.b.v.s(b)}var d="";J.j.forEach(arguments,c);return d?J.b.v.Fb(d):J.b.v.EMPTY};J.b.R=function(){this.xc="";this.ei=J.b.R.da};J.b.R.prototype.wa=!0;J.b.R.da={};
J.b.R.nq=function(b,c){if(J.f.contains(b,"<"))throw Error("Selector does not allow '<', got: "+b);var d=b.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g,"");if(!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=^$|]+$/.test(d))throw Error("Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=^$|] and strings, got: "+b);if(!J.b.R.Pj(d))throw Error("() and [] in selector must be balanced, got: "+b);c instanceof J.b.v||(c=J.b.v.create(c));b=b+"{"+J.b.v.s(c)+"}";return J.b.R.Gb(b)};
J.b.R.Pj=function(b){for(var c={"(":")","[":"]"},d=[],e=0;e<b.length;e++){var f=b[e];if(c[f])d.push(c[f]);else if(J.object.contains(c,f)&&d.pop()!=f)return!1}return 0==d.length};J.b.R.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):d+=J.b.R.s(b)}var d="";J.j.forEach(arguments,c);return J.b.R.Gb(d)};J.b.R.jc=function(b){b=J.f.H.s(b);return 0===b.length?J.b.R.EMPTY:J.b.R.Gb(b)};J.b.R.prototype.ja=E("xc");J.Z&&(J.b.R.prototype.toString=function(){return"SafeStyleSheet{"+this.xc+"}"});
J.b.R.s=function(b){if(b instanceof J.b.R&&b.constructor===J.b.R&&b.ei===J.b.R.da)return b.xc;J.o.ha("expected object of type SafeStyleSheet, got '"+b+a+J.ca(b));return"type_error:SafeStyleSheet"};J.b.R.Gb=function(b){return(new J.b.R).ab(b)};J.b.R.prototype.ab=function(b){this.xc=b;return this};J.b.R.EMPTY=J.b.R.Gb("");J.b.m=function(){this.Ha="";this.ci=J.b.m.da;this.hc=null};J.b.m.prototype.Dd=!0;J.b.m.prototype.Za=E("hc");J.b.m.prototype.wa=!0;J.b.m.prototype.ja=E("Ha");J.Z&&(J.b.m.prototype.toString=function(){return"SafeHtml{"+this.Ha+"}"});J.b.m.s=function(b){if(b instanceof J.b.m&&b.constructor===J.b.m&&b.ci===J.b.m.da)return b.Ha;J.o.ha("expected object of type SafeHtml, got '"+b+a+J.ca(b));return"type_error:SafeHtml"};
J.b.m.va=function(b){if(b instanceof J.b.m)return b;var c=typeof b==w,d=null;c&&b.Dd&&(d=b.Za());return J.b.m.ta(J.f.va(c&&b.wa?b.ja():String(b)),d)};J.b.m.Br=function(b){if(b instanceof J.b.m)return b;b=J.b.m.va(b);return J.b.m.ta(J.f.Ng(J.b.m.s(b)),b.Za())};J.b.m.Cr=function(b){if(b instanceof J.b.m)return b;b=J.b.m.va(b);return J.b.m.ta(J.f.Jl(J.b.m.s(b)),b.Za())};J.b.m.from=J.b.m.va;J.b.m.Se=/^[a-zA-Z0-9-]+$/;J.b.m.si={action:!0,cite:!0,data:!0,formaction:!0,href:!0,manifest:!0,poster:!0,src:!0};
J.b.m.Zh={APPLET:!0,BASE:!0,EMBED:!0,IFRAME:!0,LINK:!0,MATH:!0,META:!0,OBJECT:!0,SCRIPT:!0,STYLE:!0,SVG:!0,TEMPLATE:!0};J.b.m.create=function(b,c,d){J.b.m.Hl(String(b));return J.b.m.Ya(String(b),c,d)};J.b.m.Hl=function(b){if(!J.b.m.Se.test(b))throw Error("Invalid tag name <"+b+">.");if(b.toUpperCase()in J.b.m.Zh)throw Error("Tag name <"+b+"> is not allowed for SafeHtml.");};
J.b.m.kq=function(b,c,d,e){b&&J.b.C.s(b);var f={};f.src=b||null;f.srcdoc=c&&J.b.m.s(c);b=J.b.m.fc(f,{sandbox:""},d);return J.b.m.Ya("iframe",b,e)};J.b.m.oq=function(b,c,d,e){if(!J.b.m.Si())throw Error("The browser does not support sandboxed iframes.");var f={};f.src=b?J.b.l.s(J.b.l.Dc(b)):null;f.srcdoc=c||null;f.sandbox="";b=J.b.m.fc(f,{},d);return J.b.m.Ya("iframe",b,e)};J.b.m.Si=function(){return J.global.HTMLIFrameElement&&"sandbox"in J.global.HTMLIFrameElement.prototype};
J.b.m.qq=function(b,c){J.b.C.s(b);b=J.b.m.fc({src:b},{},c);return J.b.m.Ya("script",b)};J.b.m.pq=function(b,c){for(var d in c){var e=d.toLowerCase();if("language"==e||"src"==e||"text"==e||"type"==e)throw Error('Cannot set "'+e+'" attribute');}d="";b=J.j.concat(b);for(e=0;e<b.length;e++)d+=J.b.O.s(b[e]);b=J.b.m.ta(d,J.h.i.S.sa);return J.b.m.Ya("script",c,b)};
J.b.m.rq=function(b,c){c=J.b.m.fc({type:"text/css"},{},c);var d="";b=J.j.concat(b);for(var e=0;e<b.length;e++)d+=J.b.R.s(b[e]);b=J.b.m.ta(d,J.h.i.S.sa);return J.b.m.Ya("style",c,b)};J.b.m.mq=function(b,c){b=J.b.l.s(J.b.l.Dc(b));(J.g.userAgent.w.rc()||J.g.userAgent.w.Ra())&&J.f.contains(b,";")&&(b="'"+b.replace(/'/g,"%27")+"'");return J.b.m.Ya("meta",{"http-equiv":"refresh",content:(c||0)+"; url="+b})};
J.b.m.xj=function(b,c,d){if(d instanceof J.f.H)d=J.f.H.s(d);else if("style"==c.toLowerCase())d=J.b.m.Kj(d);else{if(/^on/i.test(c))throw Error('Attribute "'+c+'" requires goog.string.Const value, "'+d+'" given.');if(c.toLowerCase()in J.b.m.si)if(d instanceof J.b.C)d=J.b.C.s(d);else if(d instanceof J.b.l)d=J.b.l.s(d);else if(J.N(d))d=J.b.l.Dc(d).ja();else throw Error('Attribute "'+c+'" on tag "'+b+'" requires goog.html.SafeUrl, goog.string.Const, or string, value "'+d+'" given.');}d.wa&&(d=d.ja());
return c+'="'+J.f.va(String(d))+'"'};J.b.m.Kj=function(b){if(!J.ka(b))throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, '+typeof b+" given: "+b);b instanceof J.b.v||(b=J.b.v.create(b));return J.b.v.s(b)};J.b.m.tq=function(b,c,d,e){c=J.b.m.create(c,d,e);c.hc=b;return c};
J.b.m.concat=function(b){function c(b){J.isArray(b)?J.j.forEach(b,c):(b=J.b.m.va(b),e+=J.b.m.s(b),b=b.Za(),d==J.h.i.S.sa?d=b:b!=J.h.i.S.sa&&d!=b&&(d=null))}var d=J.h.i.S.sa,e="";J.j.forEach(arguments,c);return J.b.m.ta(e,d)};J.b.m.gq=function(b,c){var d=J.b.m.concat(J.j.slice(arguments,1));d.hc=b;return d};J.b.m.da={};J.b.m.ta=function(b,c){return(new J.b.m).ab(b,c)};J.b.m.prototype.ab=function(b,c){this.Ha=b;this.hc=c;return this};
J.b.m.Ya=function(b,c,d){var e=null;var f="<"+b+J.b.m.pl(b,c);J.bb(d)?J.isArray(d)||(d=[d]):d=[];J.a.tags.qk(b.toLowerCase())?f+=">":(e=J.b.m.concat(d),f+=">"+J.b.m.s(e)+"</"+b+">",e=e.Za());(b=c&&c.dir)&&(e=/^(ltr|rtl|auto)$/i.test(b)?J.h.i.S.sa:null);return J.b.m.ta(f,e)};J.b.m.pl=function(b,c){var d="";if(c)for(var e in c){if(!J.b.m.Se.test(e))throw Error('Invalid attribute name "'+e+'".');var f=c[e];J.bb(f)&&(d+=" "+J.b.m.xj(b,e,f))}return d};
J.b.m.fc=function(b,c,d){var e={},f;for(f in b)e[f]=b[f];for(f in c)e[f]=c[f];for(f in d){var g=f.toLowerCase();if(g in b)throw Error('Cannot override "'+g+'" attribute, got "'+f+'" with value "'+d[f]+'"');g in c&&delete e[g];e[f]=d[f]}return e};J.b.m.Im=J.b.m.ta("<!DOCTYPE html>",J.h.i.S.sa);J.b.m.EMPTY=J.b.m.ta("",J.h.i.S.sa);J.b.m.re=J.b.m.ta("<br>",J.h.i.S.sa);J.a.J={};J.a.J.Bn={Sl:"afterbegin",Tl:"afterend",hm:"beforebegin",im:"beforeend"};J.a.J.Er=function(b,c,d){b.insertAdjacentHTML(c,J.b.m.s(d))};J.a.J.ji={MATH:!0,SCRIPT:!0,STYLE:!0,SVG:!0,TEMPLATE:!0};J.a.J.dk=J.M.Ri(function(){if(J.Z&&"undefined"===typeof document)return!1;var b=document.createElement("div");b.innerHTML="<div><div></div></div>";if(J.Z&&!b.firstChild)return!1;var c=b.firstChild.firstChild;b.innerHTML="";return!c.parentElement});
J.a.J.Cl=function(b,c){if(J.a.J.dk())for(;b.lastChild;)b.removeChild(b.lastChild);b.innerHTML=c};J.a.J.Zg=function(b,c){if(J.o.ma&&J.a.J.ji[b.tagName.toUpperCase()])throw Error("goog.dom.safe.setInnerHtml cannot be used to set content of "+b.tagName+".");J.a.J.Cl(b,J.b.m.s(c))};J.a.J.Ft=function(b,c){b.outerHTML=J.b.m.s(c)};J.a.J.vt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Fi(b).action=J.b.l.s(c)};J.a.J.pt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Ei(b).formAction=J.b.l.s(c)};
J.a.J.Bt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);J.a.o.Gi(b).formAction=J.b.l.s(c)};J.a.J.Ht=function(b,c){b.style.cssText=J.b.v.s(c)};J.a.J.Aq=function(b,c){b.write(J.b.m.s(c))};J.a.J.nt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.href=J.b.l.s(c)};J.a.J.At=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};J.a.J.ot=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};J.a.J.Lt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.src=J.b.l.s(c)};
J.a.J.tt=function(b,c){b.src=J.b.C.s(c)};J.a.J.wt=function(b,c){b.src=J.b.C.s(c)};J.a.J.yt=function(b,c){b.src=J.b.C.s(c)};J.a.J.zt=function(b,c){b.srcdoc=J.b.m.s(c)};J.a.J.Ct=function(b,c,d){b.rel=d;J.f.bf(d,"stylesheet")?b.href=J.b.C.s(c):b.href=c instanceof J.b.C?J.b.C.s(c):c instanceof J.b.l?J.b.l.s(c):J.b.l.ra(c).ja()};J.a.J.Et=function(b,c){b.data=J.b.C.s(c)};J.a.J.il=function(b,c){b.src=J.b.C.s(c);(c=J.$f())&&b.setAttribute("nonce",c)};
J.a.J.Gt=function(b,c){b.text=J.b.O.s(c);(c=J.$f())&&b.setAttribute("nonce",c)};J.a.J.Dt=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.href=J.b.l.s(c)};J.a.J.Lp=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.assign(J.b.l.s(c))};J.a.J.$s=function(b,c){c=c instanceof J.b.l?c:J.b.l.ra(c);b.replace(J.b.l.s(c))};J.a.J.Ks=function(b,c,d,e,f){b=b instanceof J.b.l?b:J.b.l.ra(b);return(c||window).open(J.b.l.s(b),d?J.f.H.s(d):"",e,f)};J.b.fb={};J.b.fb.$k=function(b,c){return J.b.m.ta(c,null)};J.b.fb.gt=function(b,c){return J.b.O.Eb(c)};J.b.fb.ht=function(b,c){return J.b.v.Fb(c)};J.b.fb.it=function(b,c){return J.b.R.Gb(c)};J.b.fb.jt=function(b,c){return J.b.l.oa(c)};J.b.fb.gu=function(b,c){return J.b.C.Hb(c)};J.u={};J.u.Ps=function(b){return Math.floor(Math.random()*b)};J.u.iu=function(b,c){return b+Math.random()*(c-b)};J.u.Zp=function(b,c,d){return Math.min(Math.max(b,c),d)};J.u.Lg=function(b,c){b%=c;return 0>b*c?b+c:b};J.u.qs=function(b,c,d){return b+d*(c-b)};J.u.Bs=function(b,c,d){return Math.abs(b-c)<=(d||1E-6)};J.u.ae=function(b){return J.u.Lg(b,360)};J.u.St=function(b){return J.u.Lg(b,2*Math.PI)};J.u.kh=function(b){return b*Math.PI/180};J.u.tl=function(b){return 180*b/Math.PI};
J.u.np=function(b,c){return c*Math.cos(J.u.kh(b))};J.u.op=function(b,c){return c*Math.sin(J.u.kh(b))};J.u.angle=function(b,c,d,e){return J.u.ae(J.u.tl(Math.atan2(e-c,d-b)))};J.u.mp=function(b,c){b=J.u.ae(c)-J.u.ae(b);180<b?b-=360:-180>=b&&(b=360+b);return b};J.u.sign=function(b){return 0<b?1:0>b?-1:b};
J.u.us=function(b,c,d,e){d=d||function(b,c){return b==c};e=e||function(c){return b[c]};for(var f=b.length,g=c.length,h=[],l=0;l<f+1;l++)h[l]=[],h[l][0]=0;for(var m=0;m<g+1;m++)h[0][m]=0;for(l=1;l<=f;l++)for(m=1;m<=g;m++)d(b[l-1],c[m-1])?h[l][m]=h[l-1][m-1]+1:h[l][m]=Math.max(h[l-1][m],h[l][m-1]);var r=[];l=f;for(m=g;0<l&&0<m;)d(b[l-1],c[m-1])?(r.unshift(e(l-1,m-1)),l--,m--):h[l-1][m]>h[l][m-1]?l--:m--;return r};J.u.ce=function(b){return J.j.reduce(arguments,function(b,d){return b+d},0)};
J.u.Ji=function(b){return J.u.ce.apply(null,arguments)/arguments.length};J.u.bl=function(b){var c=arguments.length;if(2>c)return 0;var d=J.u.Ji.apply(null,arguments);return J.u.ce.apply(null,J.j.map(arguments,function(b){return Math.pow(b-d,2)}))/(c-1)};J.u.Tt=function(b){return Math.sqrt(J.u.bl.apply(null,arguments))};J.u.Ur=function(b){return isFinite(b)&&0==b%1};J.u.Sr=function(b){return isFinite(b)};J.u.Zr=function(b){return 0==b&&0>1/b};
J.u.ts=function(b){if(0<b){var c=Math.round(Math.log(b)*Math.LOG10E);return c-(parseFloat("1e"+c)>b?1:0)}return 0==b?-Infinity:NaN};J.u.et=function(b,c){return Math.floor(b+(c||2E-15))};J.u.dt=function(b,c){return Math.ceil(b-(c||2E-15))};J.u.X=function(b,c){this.x=J.W(b)?b:0;this.y=J.W(c)?c:0};J.u.X.prototype.clone=function(){return new J.u.X(this.x,this.y)};J.Z&&(J.u.X.prototype.toString=function(){return"("+this.x+", "+this.y+")"});J.u.X.prototype.Ib=function(b){return b instanceof J.u.X&&J.u.X.Ib(this,b)};J.u.X.Ib=function(b,c){return b==c?!0:b&&c?b.x==c.x&&b.y==c.y:!1};J.u.X.zq=function(b,c){var d=b.x-c.x;b=b.y-c.y;return Math.sqrt(d*d+b*b)};J.u.X.vs=function(b){return Math.sqrt(b.x*b.x+b.y*b.y)};
J.u.X.azimuth=function(b){return J.u.angle(0,0,b.x,b.y)};J.u.X.Qt=function(b,c){var d=b.x-c.x;b=b.y-c.y;return d*d+b*b};J.u.X.yq=function(b,c){return new J.u.X(b.x-c.x,b.y-c.y)};J.u.X.ce=function(b,c){return new J.u.X(b.x+c.x,b.y+c.y)};H=J.u.X.prototype;H.ceil=function(){this.x=Math.ceil(this.x);this.y=Math.ceil(this.y);return this};H.floor=function(){this.x=Math.floor(this.x);this.y=Math.floor(this.y);return this};H.round=function(){this.x=Math.round(this.x);this.y=Math.round(this.y);return this};
H.translate=function(b,c){b instanceof J.u.X?(this.x+=b.x,this.y+=b.y):(this.x+=Number(b),J.Rb(c)&&(this.y+=c));return this};H.scale=function(b,c){c=J.Rb(c)?c:b;this.x*=b;this.y*=c;return this};J.u.lb=function(b,c){this.width=b;this.height=c};J.u.lb.Ib=function(b,c){return b==c?!0:b&&c?b.width==c.width&&b.height==c.height:!1};J.u.lb.prototype.clone=function(){return new J.u.lb(this.width,this.height)};J.Z&&(J.u.lb.prototype.toString=function(){return"("+this.width+" x "+this.height+")"});H=J.u.lb.prototype;H.Ai=function(){return this.width*this.height};H.aspectRatio=function(){return this.width/this.height};H.Qb=function(){return!this.Ai()};
H.ceil=function(){this.width=Math.ceil(this.width);this.height=Math.ceil(this.height);return this};H.floor=function(){this.width=Math.floor(this.width);this.height=Math.floor(this.height);return this};H.round=function(){this.width=Math.round(this.width);this.height=Math.round(this.height);return this};H.scale=function(b,c){c=J.Rb(c)?c:b;this.width*=b;this.height*=c;return this};J.a.yh=!1;J.a.ne=!1;J.a.Ih=J.a.yh||J.a.ne;J.a.td=function(b){return b?new J.a.jb(J.a.Qa(b)):J.a.hj||(J.a.hj=new J.a.jb)};J.a.yj=function(){return document};J.a.ud=function(b){return J.a.xd(document,b)};J.a.xd=function(b,c){return J.N(c)?b.getElementById(c):c};J.a.Gj=function(b){return J.a.Zf(document,b)};J.a.Zf=function(b,c){return J.a.xd(b,c)};J.a.qh=J.a.ud;J.a.getElementsByTagName=function(b,c){return(c||document).getElementsByTagName(String(b))};
J.a.yd=function(b,c,d){return J.a.kc(document,b,c,d)};J.a.Bj=function(b,c,d){return J.a.wd(document,b,c,d)};J.a.If=function(b,c){var d=c||document;return J.a.ad(d)?d.querySelectorAll("."+b):J.a.kc(document,"*",b,c)};J.a.vd=function(b,c){var d=c||document;return(d.getElementsByClassName?d.getElementsByClassName(b)[0]:J.a.wd(document,"*",b,c))||null};J.a.Yf=function(b,c){return J.a.vd(b,c)};J.a.ad=function(b){return!(!b.querySelectorAll||!b.querySelector)};
J.a.kc=function(b,c,d,e){b=e||b;c=c&&"*"!=c?String(c).toUpperCase():"";if(J.a.ad(b)&&(c||d))return b.querySelectorAll(c+(d?"."+d:""));if(d&&b.getElementsByClassName){b=b.getElementsByClassName(d);if(c){e={};for(var f=0,g=0,h;h=b[g];g++)c==h.nodeName&&(e[f++]=h);e.length=f;return e}return b}b=b.getElementsByTagName(c||"*");if(d){e={};for(g=f=0;h=b[g];g++)c=h.className,typeof c.split==q&&J.j.contains(c.split(/\s+/),d)&&(e[f++]=h);e.length=f;return e}return b};
J.a.wd=function(b,c,d,e){var f=e||b,g=c&&"*"!=c?String(c).toUpperCase():"";return J.a.ad(f)&&(g||d)?f.querySelector(g+(d?"."+d:"")):J.a.kc(b,c,d,e)[0]||null};J.a.rh=J.a.yd;J.a.Gc=function(b,c){J.object.forEach(c,function(c,e){c&&typeof c==w&&c.wa&&(c=c.ja());"style"==e?b.style.cssText=c:"class"==e?b.className=c:"for"==e?b.htmlFor=c:J.a.ue.hasOwnProperty(e)?b.setAttribute(J.a.ue[e],c):J.f.startsWith(e,"aria-")||J.f.startsWith(e,"data-")?b.setAttribute(e,c):b[e]=c})};
J.a.ue={cellpadding:"cellPadding",cellspacing:"cellSpacing",colspan:"colSpan",frameborder:"frameBorder",height:"height",maxlength:"maxLength",nonce:"nonce",role:"role",rowspan:"rowSpan",type:"type",usemap:"useMap",valign:"vAlign",width:"width"};J.a.dg=function(b){return J.a.eg(b||window)};J.a.eg=function(b){b=b.document;b=J.a.Ob(b)?b.documentElement:b.body;return new J.u.lb(b.clientWidth,b.clientHeight)};J.a.zj=function(){return J.a.rd(window)};J.a.gr=function(b){return J.a.rd(b)};
J.a.rd=function(b){var c=b.document,d=0;if(c){d=c.body;var e=c.documentElement;if(!e||!d)return 0;b=J.a.eg(b).height;if(J.a.Ob(c)&&e.scrollHeight)d=e.scrollHeight!=b?e.scrollHeight:e.offsetHeight;else{c=e.scrollHeight;var f=e.offsetHeight;e.clientHeight!=f&&(c=d.scrollHeight,f=d.offsetHeight);d=c>b?c>f?c:f:c<f?c:f}}return d};J.a.pr=function(b){return J.a.td((b||J.global||window).document).Gf()};J.a.Gf=function(){return J.a.Hf(document)};
J.a.Hf=function(b){var c=J.a.sd(b);b=J.a.nc(b);return J.userAgent.$&&J.userAgent.xa("10")&&b.pageYOffset!=c.scrollTop?new J.u.X(c.scrollLeft,c.scrollTop):new J.u.X(b.pageXOffset||c.scrollLeft,b.pageYOffset||c.scrollTop)};J.a.Aj=function(){return J.a.sd(document)};J.a.sd=function(b){return b.scrollingElement?b.scrollingElement:!J.userAgent.Bb&&J.a.Ob(b)?b.documentElement:b.body||b.documentElement};J.a.qb=function(b){return b?J.a.nc(b):window};J.a.nc=function(b){return b.parentWindow||b.defaultView};
J.a.ed=function(b,c,d){return J.a.jf(document,arguments)};J.a.jf=function(b,c){var d=String(c[0]),e=c[1];if(!J.a.gb.Ch&&e&&(e.name||e.type)){d=["<",d];e.name&&d.push(' name="',J.f.va(e.name),'"');if(e.type){d.push(' type="',J.f.va(e.type),'"');var f={};J.object.extend(f,e);delete f.type;e=f}d.push(">");d=d.join("")}d=b.createElement(d);e&&(J.N(e)?d.className=e:J.isArray(e)?d.className=e.join(" "):J.a.Gc(d,e));2<c.length&&J.a.Ve(b,d,c,2);return d};
J.a.Ve=function(b,c,d,e){function f(d){d&&c.appendChild(J.N(d)?b.createTextNode(d):d)}for(;e<d.length;e++){var g=d[e];J.Nb(g)&&!J.a.Id(g)?J.j.forEach(J.a.Jd(g)?J.j.jh(g):g,f):f(g)}};J.a.sh=J.a.ed;J.a.createElement=function(b){return J.a.Na(document,b)};J.a.Na=function(b,c){return b.createElement(String(c))};J.a.createTextNode=function(b){return document.createTextNode(String(b))};J.a.cj=function(b,c,d){return J.a.kf(document,b,c,!!d)};
J.a.kf=function(b,c,d,e){for(var f=J.a.Na(b,"TABLE"),g=f.appendChild(J.a.Na(b,"TBODY")),h=0;h<c;h++){for(var l=J.a.Na(b,"TR"),m=0;m<d;m++){var r=J.a.Na(b,"TD");e&&J.a.Wd(r,J.f.Re.Fe);l.appendChild(r)}g.appendChild(l)}return f};J.a.hq=function(b){var c=J.j.map(arguments,J.f.H.s);c=J.b.fb.$k(J.f.H.from("Constant HTML string, that gets turned into a Node later, so it will be automatically balanced."),c.join(""));return J.a.Sg(c)};J.a.Sg=function(b){return J.a.Tg(document,b)};
J.a.Tg=function(b,c){var d=J.a.Na(b,"DIV");J.a.gb.Uh?(J.a.J.Zg(d,J.b.m.concat(J.b.m.re,c)),d.removeChild(d.firstChild)):J.a.J.Zg(d,c);return J.a.Vi(b,d)};J.a.Vi=function(b,c){if(1==c.childNodes.length)return c.removeChild(c.firstChild);for(b=b.createDocumentFragment();c.firstChild;)b.appendChild(c.firstChild);return b};J.a.Zj=function(){return J.a.Ob(document)};J.a.Ob=function(b){return J.a.Ih?J.a.ne:"CSS1Compat"==b.compatMode};J.a.canHaveChildren=function(b){if(b.nodeType!=J.a.fa.Ja)return!1;switch(b.tagName){case "APPLET":case "AREA":case "BASE":case "BR":case "COL":case "COMMAND":case "EMBED":case "FRAME":case "HR":case "IMG":case "INPUT":case "IFRAME":case "ISINDEX":case "KEYGEN":case "LINK":case "NOFRAMES":case "NOSCRIPT":case "META":case "OBJECT":case "PARAM":case k:case "SOURCE":case "STYLE":case "TRACK":case "WBR":return!1}return!0};
J.a.appendChild=function(b,c){b.appendChild(c)};J.a.append=function(b,c){J.a.Ve(J.a.Qa(b),b,arguments,1)};J.a.Td=function(b){for(var c;c=b.firstChild;)b.removeChild(c)};J.a.kg=function(b,c){c.parentNode&&c.parentNode.insertBefore(b,c)};J.a.jg=function(b,c){c.parentNode&&c.parentNode.insertBefore(b,c.nextSibling)};J.a.ig=function(b,c,d){b.insertBefore(c,b.childNodes[d]||null)};J.a.removeNode=function(b){return b&&b.parentNode?b.parentNode.removeChild(b):null};
J.a.Rg=function(b,c){var d=c.parentNode;d&&d.replaceChild(b,c)};J.a.xf=function(b){var c,d=b.parentNode;if(d&&d.nodeType!=J.a.fa.Nh){if(b.removeNode)return b.removeNode(!1);for(;c=b.firstChild;)d.insertBefore(c,b);return J.a.removeNode(b)}};J.a.Ef=function(b){return J.a.gb.Dh&&void 0!=b.children?b.children:J.j.filter(b.childNodes,function(b){return b.nodeType==J.a.fa.Ja})};J.a.Jf=function(b){return J.W(b.firstElementChild)?b.firstElementChild:J.a.lc(b.firstChild,!0)};
J.a.Nf=function(b){return J.W(b.lastElementChild)?b.lastElementChild:J.a.lc(b.lastChild,!1)};J.a.Pf=function(b){return J.W(b.nextElementSibling)?b.nextElementSibling:J.a.lc(b.nextSibling,!0)};J.a.Wf=function(b){return J.W(b.previousElementSibling)?b.previousElementSibling:J.a.lc(b.previousSibling,!1)};J.a.lc=function(b,c){for(;b&&b.nodeType!=J.a.fa.Ja;)b=c?b.nextSibling:b.previousSibling;return b};
J.a.Qf=function(b){if(!b)return null;if(b.firstChild)return b.firstChild;for(;b&&!b.nextSibling;)b=b.parentNode;return b?b.nextSibling:null};J.a.Xf=function(b){if(!b)return null;if(!b.previousSibling)return b.parentNode;for(b=b.previousSibling;b&&b.lastChild;)b=b.lastChild;return b};J.a.Id=function(b){return J.ka(b)&&0<b.nodeType};J.a.Fd=function(b){return J.ka(b)&&b.nodeType==J.a.fa.Ja};J.a.Dg=function(b){return J.ka(b)&&b.window==b};
J.a.Vf=function(b){var c;if(J.a.gb.Eh&&!(J.userAgent.$&&J.userAgent.xa("9")&&!J.userAgent.xa("10")&&J.global.SVGElement&&b instanceof J.global.SVGElement)&&(c=b.parentElement))return c;c=b.parentNode;return J.a.Fd(c)?c:null};J.a.contains=function(b,c){if(!b||!c)return!1;if(b.contains&&c.nodeType==J.a.fa.Ja)return b==c||b.contains(c);if("undefined"!=typeof b.compareDocumentPosition)return b==c||!!(b.compareDocumentPosition(c)&16);for(;c&&b!=c;)c=c.parentNode;return c==b};
J.a.df=function(b,c){if(b==c)return 0;if(b.compareDocumentPosition)return b.compareDocumentPosition(c)&2?1:-1;if(J.userAgent.$&&!J.userAgent.Pb(9)){if(b.nodeType==J.a.fa.Sc)return-1;if(c.nodeType==J.a.fa.Sc)return 1}if("sourceIndex"in b||b.parentNode&&"sourceIndex"in b.parentNode){var d=b.nodeType==J.a.fa.Ja,e=c.nodeType==J.a.fa.Ja;if(d&&e)return b.sourceIndex-c.sourceIndex;var f=b.parentNode,g=c.parentNode;return f==g?J.a.ff(b,c):!d&&J.a.contains(f,c)?-1*J.a.ef(b,c):!e&&J.a.contains(g,b)?J.a.ef(c,
b):(d?b.sourceIndex:f.sourceIndex)-(e?c.sourceIndex:g.sourceIndex)}e=J.a.Qa(b);d=e.createRange();d.selectNode(b);d.collapse(!0);b=e.createRange();b.selectNode(c);b.collapse(!0);return d.compareBoundaryPoints(J.global.Range.START_TO_END,b)};J.a.ef=function(b,c){var d=b.parentNode;if(d==c)return-1;for(;c.parentNode!=d;)c=c.parentNode;return J.a.ff(c,b)};J.a.ff=function(b,c){for(;c=c.previousSibling;)if(c==b)return-1;return 1};
J.a.tf=function(b){var c,d=arguments.length;if(!d)return null;if(1==d)return arguments[0];var e=[],f=Infinity;for(c=0;c<d;c++){for(var g=[],h=arguments[c];h;)g.unshift(h),h=h.parentNode;e.push(g);f=Math.min(f,g.length)}g=null;for(c=0;c<f;c++){h=e[0][c];for(var l=1;l<d;l++)if(h!=e[l][c])return g;g=h}return g};J.a.Qa=function(b){return b.nodeType==J.a.fa.Sc?b:b.ownerDocument||b.document};J.a.Kf=function(b){return b.contentDocument||b.contentWindow.document};
J.a.Lf=function(b){try{return b.contentWindow||(b.contentDocument?J.a.qb(b.contentDocument):null)}catch(c){}return null};J.a.Wd=function(b,c){if("textContent"in b)b.textContent=c;else if(b.nodeType==J.a.fa.ac)b.data=String(c);else if(b.firstChild&&b.firstChild.nodeType==J.a.fa.ac){for(;b.lastChild!=b.firstChild;)b.removeChild(b.lastChild);b.firstChild.data=String(c)}else{J.a.Td(b);var d=J.a.Qa(b);b.appendChild(d.createTextNode(String(c)))}};
J.a.Uf=function(b){if("outerHTML"in b)return b.outerHTML;var c=J.a.Qa(b);c=J.a.Na(c,"DIV");c.appendChild(b.cloneNode(!0));return c.innerHTML};J.a.uf=function(b,c){var d=[];return J.a.md(b,c,d,!0)?d[0]:void 0};J.a.vf=function(b,c){var d=[];J.a.md(b,c,d,!1);return d};J.a.md=function(b,c,d,e){if(null!=b)for(b=b.firstChild;b;){if(c(b)&&(d.push(b),e)||J.a.md(b,c,d,e))return!0;b=b.nextSibling}return!1};J.a.Oe={SCRIPT:1,STYLE:1,HEAD:1,IFRAME:1,OBJECT:1};J.a.Zb={IMG:" ",BR:"\n"};
J.a.Hd=function(b){return J.a.gg(b)&&J.a.Bg(b)};J.a.Xg=function(b,c){c?b.tabIndex=0:(b.tabIndex=-1,b.removeAttribute("tabIndex"))};J.a.qg=function(b){var c;return(c=J.a.Kk(b)?!b.disabled&&(!J.a.gg(b)||J.a.Bg(b)):J.a.Hd(b))&&J.userAgent.$?J.a.Sj(b):c};J.a.gg=function(b){return J.userAgent.$&&!J.userAgent.xa("9")?(b=b.getAttributeNode("tabindex"),J.bb(b)&&b.specified):b.hasAttribute("tabindex")};J.a.Bg=function(b){b=b.tabIndex;return J.Rb(b)&&0<=b&&32768>b};
J.a.Kk=function(b){return"A"==b.tagName||"INPUT"==b.tagName||"TEXTAREA"==b.tagName||"SELECT"==b.tagName||"BUTTON"==b.tagName};J.a.Sj=function(b){b=!J.Ba(b.getBoundingClientRect)||J.userAgent.$&&null==b.parentElement?{height:b.offsetHeight,width:b.offsetWidth}:b.getBoundingClientRect();return J.bb(b)&&0<b.height&&0<b.width};
J.a.mc=function(b){if(J.a.gb.se&&null!==b&&"innerText"in b)b=J.f.Ui(b.innerText);else{var c=[];J.a.Ad(b,c,!0);b=c.join("")}b=b.replace(/ \xAD /g," ").replace(/\xAD/g,"");b=b.replace(/\u200B/g,"");J.a.gb.se||(b=b.replace(/ +/g," "));" "!=b&&(b=b.replace(/^\s*/,""));return b};J.a.sr=function(b){var c=[];J.a.Ad(b,c,!1);return c.join("")};
J.a.Ad=function(b,c,d){if(!(b.nodeName in J.a.Oe))if(b.nodeType==J.a.fa.ac)d?c.push(String(b.nodeValue).replace(/(\r\n|\r|\n)/g,"")):c.push(b.nodeValue);else if(b.nodeName in J.a.Zb)c.push(J.a.Zb[b.nodeName]);else for(b=b.firstChild;b;)J.a.Ad(b,c,d),b=b.nextSibling};J.a.Sf=function(b){return J.a.mc(b).length};J.a.Tf=function(b,c){c=c||J.a.Qa(b).body;for(var d=[];b&&b!=c;){for(var e=b;e=e.previousSibling;)d.unshift(J.a.mc(e));b=b.parentNode}return J.f.trimLeft(d.join("")).replace(/ +/g," ").length};
J.a.Rf=function(b,c,d){b=[b];for(var e=0,f=null;0<b.length&&e<c;)if(f=b.pop(),!(f.nodeName in J.a.Oe))if(f.nodeType==J.a.fa.ac){var g=f.nodeValue.replace(/(\r\n|\r|\n)/g,"").replace(/ +/g," ");e+=g.length}else if(f.nodeName in J.a.Zb)e+=J.a.Zb[f.nodeName].length;else for(g=f.childNodes.length-1;0<=g;g--)b.push(f.childNodes[g]);J.ka(d)&&(d.Ss=f?f.nodeValue.length+c-e-1:0,d.node=f);return f};
J.a.Jd=function(b){if(b&&typeof b.length==v){if(J.ka(b))return typeof b.item==q||typeof b.item==z;if(J.Ba(b))return typeof b.item==q}return!1};J.a.pd=function(b,c,d,e){if(!c&&!d)return null;var f=c?String(c).toUpperCase():null;return J.a.od(b,function(b){return(!f||b.nodeName==f)&&(!d||J.N(b.className)&&J.j.contains(b.className.split(/\s+/),d))},!0,e)};J.a.Bf=function(b,c,d){return J.a.pd(b,null,c,d)};
J.a.od=function(b,c,d,e){b&&!d&&(b=b.parentNode);for(d=0;b&&(null==e||d<=e);){if(c(b))return b;b=b.parentNode;d++}return null};J.a.Af=function(b){try{var c=b&&b.activeElement;return c&&c.nodeName?c:null}catch(d){return null}};J.a.qr=function(){var b=J.a.qb();return J.W(b.devicePixelRatio)?b.devicePixelRatio:b.matchMedia?J.a.tc(3)||J.a.tc(2)||J.a.tc(1.5)||J.a.tc(1)||.75:1};
J.a.tc=function(b){return J.a.qb().matchMedia("(min-resolution: "+b+"dppx),(min--moz-device-pixel-ratio: "+b+"),(min-resolution: "+96*b+"dpi)").matches?b:0};J.a.Df=function(b){return b.getContext("2d")};J.a.jb=function(b){this.Y=b||J.global.document||document};H=J.a.jb.prototype;H.td=J.a.td;H.yj=E("Y");H.ud=function(b){return J.a.xd(this.Y,b)};H.Gj=function(b){return J.a.Zf(this.Y,b)};H.qh=J.a.jb.prototype.ud;H.getElementsByTagName=function(b,c){return(c||this.Y).getElementsByTagName(String(b))};
H.yd=function(b,c,d){return J.a.kc(this.Y,b,c,d)};H.Bj=function(b,c,d){return J.a.wd(this.Y,b,c,d)};H.If=function(b,c){return J.a.If(b,c||this.Y)};H.vd=function(b,c){return J.a.vd(b,c||this.Y)};H.Yf=function(b,c){return J.a.Yf(b,c||this.Y)};H.rh=J.a.jb.prototype.yd;H.Gc=J.a.Gc;H.dg=function(b){return J.a.dg(b||this.qb())};H.zj=function(){return J.a.rd(this.qb())};H.ed=function(b,c,d){return J.a.jf(this.Y,arguments)};H.sh=J.a.jb.prototype.ed;H.createElement=function(b){return J.a.Na(this.Y,b)};
H.createTextNode=function(b){return this.Y.createTextNode(String(b))};H.cj=function(b,c,d){return J.a.kf(this.Y,b,c,!!d)};H.Sg=function(b){return J.a.Tg(this.Y,b)};H.Zj=function(){return J.a.Ob(this.Y)};H.qb=function(){return J.a.nc(this.Y)};H.Aj=function(){return J.a.sd(this.Y)};H.Gf=function(){return J.a.Hf(this.Y)};H.Af=function(b){return J.a.Af(b||this.Y)};H.appendChild=J.a.appendChild;H.append=J.a.append;H.canHaveChildren=J.a.canHaveChildren;H.Td=J.a.Td;H.kg=J.a.kg;H.jg=J.a.jg;H.ig=J.a.ig;
H.removeNode=J.a.removeNode;H.Rg=J.a.Rg;H.xf=J.a.xf;H.Ef=J.a.Ef;H.Jf=J.a.Jf;H.Nf=J.a.Nf;H.Pf=J.a.Pf;H.Wf=J.a.Wf;H.Qf=J.a.Qf;H.Xf=J.a.Xf;H.Id=J.a.Id;H.Fd=J.a.Fd;H.Dg=J.a.Dg;H.Vf=J.a.Vf;H.contains=J.a.contains;H.df=J.a.df;H.tf=J.a.tf;H.Qa=J.a.Qa;H.Kf=J.a.Kf;H.Lf=J.a.Lf;H.Wd=J.a.Wd;H.Uf=J.a.Uf;H.uf=J.a.uf;H.vf=J.a.vf;H.Hd=J.a.Hd;H.Xg=J.a.Xg;H.qg=J.a.qg;H.mc=J.a.mc;H.Sf=J.a.Sf;H.Tf=J.a.Tf;H.Rf=J.a.Rf;H.Jd=J.a.Jd;H.pd=J.a.pd;H.Bf=J.a.Bf;H.od=J.a.od;H.Df=J.a.Df;J.Qg={};J.Qg.so=D();J.Thenable=D();J.Thenable.prototype.then=D();J.Thenable.Ce="$goog_Thenable";J.Thenable.Ue=function(b){b.prototype[J.Thenable.Ce]=!0};J.Thenable.rg=function(b){if(!b)return!1;try{return!!b[J.Thenable.Ce]}catch(c){return!1}};J.Promise=function(b,c){this.ba=J.Promise.T.ya;this.la=void 0;this.mb=this.Ma=this.ea=null;this.kd=!1;0<J.Promise.Wa?this.Jc=0:0==J.Promise.Wa&&(this.oc=!1);J.Promise.Da&&(this.$d=[],M(this,Error("created")),this.mf=0);if(b!=J.cb)try{var d=this;b.call(c,function(b){N(d,J.Promise.T.Ka,b)},function(b){if(J.Z&&!(b instanceof J.Promise.ib))try{if(b instanceof Error)throw b;throw Error("Promise rejected.");}catch(f){}N(d,J.Promise.T.na,b)})}catch(e){N(this,J.Promise.T.na,e)}};J.Promise.Da=!1;
J.Promise.Wa=0;J.Promise.T={ya:0,Ah:1,Ka:2,na:3};J.Promise.te=function(){this.next=this.context=this.tb=this.Tb=this.Xa=null;this.bc=!1};J.Promise.te.prototype.reset=function(){this.context=this.tb=this.Tb=this.Xa=null;this.bc=!1};J.Promise.Qc=100;J.Promise.Kb=new J.async.Xb(function(){return new J.Promise.te},function(b){b.reset()},J.Promise.Qc);J.Promise.Cf=function(b,c,d){var e=J.Promise.Kb.get();e.Tb=b;e.tb=c;e.context=d;return e};J.Promise.Sk=function(b){J.Promise.Kb.put(b)};
J.Promise.resolve=function(b){if(b instanceof J.Promise)return b;var c=new J.Promise(J.cb);N(c,J.Promise.T.Ka,b);return c};J.Promise.reject=function(b){return new J.Promise(function(c,d){d(b)})};J.Promise.Bc=function(b,c,d){J.Promise.Kg(b,c,d,null)||J.async.P(J.eb(c,b))};J.Promise.race=function(b){return new J.Promise(function(c,d){b.length||c(void 0);for(var e=0,f;e<b.length;e++)f=b[e],J.Promise.Bc(f,c,d)})};
J.Promise.all=function(b){return new J.Promise(function(c,d){var e=b.length,f=[];if(e)for(var g=function(b,d){e--;f[b]=d;0==e&&c(f)},h=function(b){d(b)},l=0,m;l<b.length;l++)m=b[l],J.Promise.Bc(m,J.eb(g,l),h);else c(f)})};J.Promise.lp=function(b){return new J.Promise(function(c){var d=b.length,e=[];if(d)for(var f=function(b,f,g){d--;e[b]=f?{wj:!0,value:g}:{wj:!1,reason:g};0==d&&c(e)},g=0,h;g<b.length;g++)h=b[g],J.Promise.Bc(h,J.eb(f,g,!0),J.eb(f,g,!1));else c(e)})};
J.Promise.Mq=function(b){return new J.Promise(function(c,d){var e=b.length,f=[];if(e)for(var g=function(b){c(b)},h=function(b,c){e--;f[b]=c;0==e&&d(f)},l=0,m;l<b.length;l++)m=b[l],J.Promise.Bc(m,g,J.eb(h,l));else c(void 0)})};J.Promise.ou=function(){var b,c,d=new J.Promise(function(d,f){b=d;c=f});return new J.Promise.bi(d,b,c)};J.Promise.prototype.then=function(b,c,d){J.Promise.Da&&M(this,Error("then"));return ca(this,J.Ba(b)?b:null,J.Ba(c)?c:null,d)};J.Thenable.Ue(J.Promise);
J.Promise.prototype.cancel=function(b){this.ba==J.Promise.T.ya&&J.async.P(function(){var c=new J.Promise.ib(b);O(this,c)},this)};function O(b,c){if(b.ba==J.Promise.T.ya)if(b.ea){var d=b.ea;if(d.Ma){for(var e=0,f=null,g=null,h=d.Ma;h&&(h.bc||(e++,h.Xa==b&&(f=h),!(f&&1<e)));h=h.next)f||(g=h);f&&(d.ba==J.Promise.T.ya&&1==e?O(d,c):(g?(e=g,e.next==d.mb&&(d.mb=e),e.next=e.next.next):P(d),Q(d,f,J.Promise.T.na,c)))}b.ea=null}else N(b,J.Promise.T.na,c)}
function R(b,c){b.Ma||b.ba!=J.Promise.T.Ka&&b.ba!=J.Promise.T.na||S(b);b.mb?b.mb.next=c:b.Ma=c;b.mb=c}function ca(b,c,d,e){var f=J.Promise.Cf(null,null,null);f.Xa=new J.Promise(function(b,h){f.Tb=c?function(d){try{var f=c.call(e,d);b(f)}catch(r){h(r)}}:b;f.tb=d?function(c){try{var f=d.call(e,c);!J.W(f)&&c instanceof J.Promise.ib?h(c):b(f)}catch(r){h(r)}}:h});f.Xa.ea=b;R(b,f);return f.Xa}J.Promise.prototype.xl=function(b){this.ba=J.Promise.T.ya;N(this,J.Promise.T.Ka,b)};
J.Promise.prototype.yl=function(b){this.ba=J.Promise.T.ya;N(this,J.Promise.T.na,b)};function N(b,c,d){b.ba==J.Promise.T.ya&&(b===d&&(c=J.Promise.T.na,d=new TypeError("Promise cannot resolve to itself")),b.ba=J.Promise.T.Ah,J.Promise.Kg(d,b.xl,b.yl,b)||(b.la=d,b.ba=c,b.ea=null,S(b),c!=J.Promise.T.na||d instanceof J.Promise.ib||J.Promise.zi(b,d)))}
J.Promise.Kg=function(b,c,d,e){if(b instanceof J.Promise)return J.Promise.Da&&M(b,Error("then")),R(b,J.Promise.Cf(c||J.cb,d||null,e)),!0;if(J.Thenable.rg(b))return b.then(c,d,e),!0;if(J.ka(b))try{var f=b.then;if(J.Ba(f))return J.Promise.vl(b,f,c,d,e),!0}catch(g){return d.call(e,g),!0}return!1};J.Promise.vl=function(b,c,d,e,f){function g(b){l||(l=!0,e.call(f,b))}function h(b){l||(l=!0,d.call(f,b))}var l=!1;try{c.call(b,h,g)}catch(m){g(m)}};function S(b){b.kd||(b.kd=!0,J.async.P(b.qj,b))}
function P(b){var c=null;b.Ma&&(c=b.Ma,b.Ma=c.next,c.next=null);b.Ma||(b.mb=null);return c}J.Promise.prototype.qj=function(){for(var b;b=P(this);)J.Promise.Da&&this.mf++,Q(this,b,this.ba,this.la);this.kd=!1};
function Q(b,c,d,e){if(d==J.Promise.T.na&&c.tb&&!c.bc)if(0<J.Promise.Wa)for(;b&&b.Jc;b=b.ea)J.global.clearTimeout(b.Jc),b.Jc=0;else if(0==J.Promise.Wa)for(;b&&b.oc;b=b.ea)b.oc=!1;if(c.Xa)c.Xa.ea=null,J.Promise.mg(c,d,e);else try{c.bc?c.Tb.call(c.context):J.Promise.mg(c,d,e)}catch(f){J.Promise.pc.call(null,f)}J.Promise.Sk(c)}J.Promise.mg=function(b,c,d){c==J.Promise.T.Ka?b.Tb.call(b.context,d):b.tb&&b.tb.call(b.context,d)};
function M(b,c){if(J.Promise.Da&&J.N(c.stack)){var d=c.stack.split("\n",4)[3];c=c.message;c+=Array(11-c.length).join(" ");b.$d.push(c+d)}}function T(b,c){if(J.Promise.Da&&c&&J.N(c.stack)&&b.$d.length){for(var d=["Promise trace:"],e=b;e;e=e.ea){for(var f=b.mf;0<=f;f--)d.push(e.$d[f]);d.push("Value: ["+(e.ba==J.Promise.T.na?"REJECTED":"FULFILLED")+"] <"+String(e.la)+">")}c.stack+="\n\n"+d.join("\n")}}
J.Promise.zi=function(b,c){0<J.Promise.Wa?b.Jc=J.global.setTimeout(function(){T(b,c);J.Promise.pc.call(null,c)},J.Promise.Wa):0==J.Promise.Wa&&(b.oc=!0,J.async.P(function(){b.oc&&(T(b,c),J.Promise.pc.call(null,c))}))};J.Promise.pc=J.async.gh;J.Promise.Jt=function(b){J.Promise.pc=b};J.Promise.ib=function(b){J.debug.Error.call(this,b)};J.$a(J.Promise.ib,J.debug.Error);J.Promise.ib.prototype.name="cancel";J.Promise.bi=function(b,c,d){this.Qg=b;this.resolve=c;this.reject=d};/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
J.async.B=function(b,c){this.Fc=[];this.Pg=b;this.nf=c||null;this.rb=this.nb=!1;this.la=void 0;this.Xd=this.Oi=this.$c=!1;this.Ic=0;this.ea=null;this.cc=0;J.async.B.Da&&(this.dd=null,Error.captureStackTrace&&(b={stack:""},Error.captureStackTrace(b,J.async.B),typeof b.stack==z&&(this.dd=b.stack.replace(/^[^\n]*\n/,""))))};J.async.B.li=!1;J.async.B.Da=!1;H=J.async.B.prototype;
H.cancel=function(b){if(this.nb)this.la instanceof J.async.B&&this.la.cancel();else{if(this.ea){var c=this.ea;delete this.ea;b?c.cancel(b):(c.cc--,0>=c.cc&&c.cancel())}this.Pg?this.Pg.call(this.nf,this):this.Xd=!0;this.nb||this.Pa(new J.async.B.hb(this))}};H.hf=function(b,c){this.$c=!1;U(this,b,c)};function U(b,c,d){b.nb=!0;b.la=d;b.rb=!c;V(b)}function W(b){if(b.nb){if(!b.Xd)throw new J.async.B.Ub(b);b.Xd=!1}}H.Cb=function(b){W(this);U(this,!0,b)};H.Pa=function(b){W(this);X(this,b);U(this,!1,b)};
function X(b,c){J.async.B.Da&&b.dd&&J.ka(c)&&c.stack&&/^[^\n]+(\n   [^\n]+)+/.test(c.stack)&&(c.stack=c.stack+"\nDEFERRED OPERATION:\n"+b.dd)}function Y(b,c,d){return Z(b,c,null,d)}function da(b,c){Z(b,null,c,void 0)}function Z(b,c,d,e){b.Fc.push([c,d,e]);b.nb&&V(b);return b}H.then=function(b,c,d){var e,f,g=new J.Promise(function(b,c){e=b;f=c});Z(this,e,function(b){b instanceof J.async.B.hb?g.cancel():f(b)});return g.then(b,c,d)};J.Thenable.Ue(J.async.B);
J.async.B.prototype.Qi=function(){var b=new J.async.B;Z(this,b.Cb,b.Pa,b);b.ea=this;this.cc++;return b};function ea(b){return J.j.some(b.Fc,function(b){return J.Ba(b[1])})}
function V(b){b.Ic&&b.nb&&ea(b)&&(J.async.B.Dl(b.Ic),b.Ic=0);b.ea&&(b.ea.cc--,delete b.ea);for(var c=b.la,d=!1,e=!1;b.Fc.length&&!b.$c;){var f=b.Fc.shift(),g=f[0],h=f[1];f=f[2];if(g=b.rb?h:g)try{var l=g.call(f||b.nf,c);J.W(l)&&(b.rb=b.rb&&(l==c||l instanceof Error),b.la=c=l);if(J.Thenable.rg(c)||typeof J.global.Promise===q&&c instanceof J.global.Promise)e=!0,b.$c=!0}catch(m){c=m,b.rb=!0,X(b,c),ea(b)||(d=!0)}}b.la=c;e?(e=J.bind(b.hf,b,!0),l=J.bind(b.hf,b,!1),c instanceof J.async.B?(Z(c,e,l),c.Oi=!0):
c.then(e,l)):J.async.B.li&&c instanceof Error&&!(c instanceof J.async.B.hb)&&(d=b.rb=!0);d&&(b.Ic=J.async.B.el(c))}J.async.B.eh=function(b){var c=new J.async.B;c.Cb(b);return c};J.async.B.Wq=function(b){var c=new J.async.B;b.then(function(b){c.Cb(b)},function(b){c.Pa(b)});return c};J.async.B.ha=function(b){var c=new J.async.B;c.Pa(b);return c};J.async.B.Tp=function(){var b=new J.async.B;b.cancel();return b};
J.async.B.nu=function(b,c,d){return b instanceof J.async.B?Y(b.Qi(),c,d):Y(J.async.B.eh(b),c,d)};J.async.B.Ub=function(){J.debug.Error.call(this)};J.$a(J.async.B.Ub,J.debug.Error);J.async.B.Ub.prototype.message="Deferred has already fired";J.async.B.Ub.prototype.name="AlreadyCalledError";J.async.B.hb=function(){J.debug.Error.call(this)};J.$a(J.async.B.hb,J.debug.Error);J.async.B.hb.prototype.message="Deferred was canceled";J.async.B.hb.prototype.name="CanceledError";
J.async.B.ye=function(b){this.Mb=J.global.setTimeout(J.bind(this.fh,this),0);this.oj=b};J.async.B.ye.prototype.fh=function(){delete J.async.B.Jb[this.Mb];throw this.oj;};J.async.B.Jb={};J.async.B.el=function(b){b=new J.async.B.ye(b);J.async.B.Jb[b.Mb]=b;return b.Mb};J.async.B.Dl=function(b){var c=J.async.B.Jb[b];c&&(J.global.clearTimeout(c.Mb),delete J.async.B.Jb[b])};J.async.B.Gp=function(){var b=J.async.B.Jb,c;for(c in b){var d=b[c];J.global.clearTimeout(d.Mb);d.fh()}};J.D={};J.D.F={};J.D.F.Uc="closure_verification";J.D.F.Lh=5E3;J.D.F.Vd=[];J.D.F.al=function(b,c){function d(){var e=b.shift();e=J.D.F.Cc(e,c);b.length&&Z(e,d,d,void 0);return e}if(!b.length)return J.async.B.eh(null);var e=J.D.F.Vd.length;J.j.extend(J.D.F.Vd,b);if(e)return J.D.F.Vg;b=J.D.F.Vd;J.D.F.Vg=d();return J.D.F.Vg};
J.D.F.Cc=function(b,c){var d=c||{};c=d.document||document;var e=J.b.C.s(b),f=J.a.createElement(k),g={Wg:f,ih:void 0},h=new J.async.B(J.D.F.Ti,g),l=null,m=J.bb(d.timeout)?d.timeout:J.D.F.Lh;0<m&&(l=window.setTimeout(function(){J.D.F.ec(f,!0);h.Pa(new J.D.F.Error(J.D.F.Wb.TIMEOUT,"Timeout reached for loading script "+e))},m),g.ih=l);f.onload=f.onreadystatechange=function(){f.readyState&&"loaded"!=f.readyState&&"complete"!=f.readyState||(J.D.F.ec(f,d.$p||!1,l),h.Cb(null))};f.onerror=function(){J.D.F.ec(f,
!0,l);h.Pa(new J.D.F.Error(J.D.F.Wb.Vh,"Error while loading script "+e))};g=d.attributes||{};J.object.extend(g,{type:A,charset:"UTF-8"});J.a.Gc(f,g);J.a.J.il(f,b);J.D.F.Ij(c).appendChild(f);return h};
J.D.F.ft=function(b,c,d){J.global[J.D.F.Uc]||(J.global[J.D.F.Uc]={});var e=J.global[J.D.F.Uc],f=J.b.C.s(b);if(J.W(e[c]))return J.async.B.ha(new J.D.F.Error(J.D.F.Wb.xi,"Verification object "+c+" already defined."));b=J.D.F.Cc(b,d);var g=new J.async.B(J.bind(b.cancel,b));Y(b,function(){var b=e[c];J.W(b)?(g.Cb(b),delete e[c]):g.Pa(new J.D.F.Error(J.D.F.Wb.wi,"Script "+f+" loaded, but verification object "+c+" was not defined."))});da(b,function(b){J.W(e[c])&&delete e[c];g.Pa(b)});return g};
J.D.F.Ij=function(b){var c=J.a.getElementsByTagName("HEAD",b);return!c||J.j.Qb(c)?b.documentElement:c[0]};J.D.F.Ti=function(){if(this&&this.Wg){var b=this.Wg;b&&b.tagName==k&&J.D.F.ec(b,!0,this.ih)}};J.D.F.ec=function(b,c,d){J.bb(d)&&J.global.clearTimeout(d);b.onload=J.cb;b.onerror=J.cb;b.onreadystatechange=J.cb;c&&window.setTimeout(function(){J.a.removeNode(b)},0)};J.D.F.Wb={Vh:0,TIMEOUT:1,wi:2,xi:3};
J.D.F.Error=function(b,c){var d="Jsloader error (code #"+b+")";c&&(d+=": "+c);J.debug.Error.call(this,d);this.code=b};J.$a(J.D.F.Error,J.debug.Error);var google={G:{}};google.G.K={};google.G.K.Ea={};google.G.K.Ea.hh=3E4;google.G.K.Ea.ws=function(b,c){return{format:b,Bi:c}};google.G.K.Ea.Lj=function(b){return J.b.C.format(b.format,b.Bi)};google.G.K.Ea.load=function(b,c){b=J.b.C.format(b,c);var d=J.D.F.Cc(b,{timeout:google.G.K.Ea.hh,attributes:{async:!1,defer:!1}});return new Promise(function(b){Y(d,b)})};
google.G.K.Ea.rs=function(b){b=J.j.map(b,google.G.K.Ea.Lj);if(J.j.Qb(b))return Promise.resolve();var c={timeout:google.G.K.Ea.hh,attributes:{async:!1,defer:!1}},d=[];!J.userAgent.$||J.userAgent.xa(11)?J.j.forEach(b,function(b){d.push(J.D.F.Cc(b,c))}):d.push(J.D.F.al(b,c));return Promise.all(J.j.map(d,function(b){return new Promise(function(c){return Y(b,c)})}))};google.G.K.U={};if(J.ob(t))throw Error("Google Charts loader.js can only be loaded once.");google.G.K.U.Il={1:"1.0","1.0":"current","1.1":"upcoming",41:x,42:x,43:x,44:x,46:"46.1",previous:"45.2",current:"46",upcoming:"46.2"};google.G.K.U.Fk=function(b){var c=b,d=b.match(/^testing-/);d&&(c=c.replace(/^testing-/,""));b=c;do{var e=google.G.K.U.Il[c];e&&(c=e)}while(e);d=(d?"testing-":"")+c;return{version:c==x?b:d,yk:d}};google.G.K.U.oh=null;
google.G.K.U.xk=function(b){var c=google.G.K.U.Fk(b),d=J.f.H.from("https://www.gstatic.com/charts/%{version}/loader.js");return google.G.K.Ea.load(d,{version:c.yk}).then(function(){var d=J.ob("google.charts.loader.VersionSpecific.load")||J.ob("google.charts.loader.publicLoad")||J.ob("google.charts.versionSpecific.load");if(!d)throw Error("Bad version: "+b);google.G.K.U.oh=function(b){b=d(c.version,b);if(null==b||null==b.then){var e=J.ob("google.charts.loader.publicSetOnLoadCallback")||J.ob("google.charts.versionSpecific.setOnLoadCallback");
b=new Promise(function(b){e(b)});b.then=e}return b}})};google.G.K.U.Ld=null;google.G.K.U.gc=null;google.G.K.U.vk=function(b,c){if(!google.G.K.U.Ld){if(c.getVersionFromUrl&&window.URLSearchParams)try{var d=new URLSearchParams(top.location.search);console.info("version from url",d.get(p));b=d.get(p)||b}catch(e){console.info("Failed to get charts-version from top URL",e)}google.G.K.U.Ld=google.G.K.U.xk(b)}return google.G.K.U.gc=google.G.K.U.Ld.then(function(){return google.G.K.U.oh(c)})};
google.G.K.U.hl=function(b){if(!google.G.K.U.gc)throw Error("Must call google.charts.load before google.charts.setOnLoadCallback");return b?google.G.K.U.gc.then(b):google.G.K.U.gc};google.G.load=function(b){for(var c=[],d=0;d<arguments.length;++d)c[d-0]=arguments[d];d=0;"visualization"===c[d]&&d++;var e="current";J.N(c[d])&&(e=c[d],d++);var f={};J.ka(c[d])&&(f=c[d]);return google.G.K.U.vk(e,f)};J.rf(t,google.G.load);google.G.gl=google.G.K.U.hl;J.rf("google.charts.setOnLoadCallback",google.G.gl);}).call(this);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings, storage) {
  var currentUserID = parseInt(drupalSettings.user.uid, 10);

  var secondsIn30Days = 2592000;
  var thirtyDaysAgo = Math.round(new Date().getTime() / 1000) - secondsIn30Days;

  var embeddedLastReadTimestamps = false;
  if (drupalSettings.history && drupalSettings.history.lastReadTimestamps) {
    embeddedLastReadTimestamps = drupalSettings.history.lastReadTimestamps;
  }

  Drupal.history = {
    fetchTimestamps: function fetchTimestamps(nodeIDs, callback) {
      if (embeddedLastReadTimestamps) {
        callback();
        return;
      }

      $.ajax({
        url: Drupal.url('history/get_node_read_timestamps'),
        type: 'POST',
        data: { 'node_ids[]': nodeIDs },
        dataType: 'json',
        success: function success(results) {
          Object.keys(results || {}).forEach(function (nodeID) {
            storage.setItem('Drupal.history.' + currentUserID + '.' + nodeID, results[nodeID]);
          });
          callback();
        }
      });
    },
    getLastRead: function getLastRead(nodeID) {
      if (embeddedLastReadTimestamps && embeddedLastReadTimestamps[nodeID]) {
        return parseInt(embeddedLastReadTimestamps[nodeID], 10);
      }
      return parseInt(storage.getItem('Drupal.history.' + currentUserID + '.' + nodeID) || 0, 10);
    },
    markAsRead: function markAsRead(nodeID) {
      $.ajax({
        url: Drupal.url('history/' + nodeID + '/read'),
        type: 'POST',
        dataType: 'json',
        success: function success(timestamp) {
          if (embeddedLastReadTimestamps && embeddedLastReadTimestamps[nodeID]) {
            return;
          }

          storage.setItem('Drupal.history.' + currentUserID + '.' + nodeID, timestamp);
        }
      });
    },
    needsServerCheck: function needsServerCheck(nodeID, contentTimestamp) {
      if (contentTimestamp < thirtyDaysAgo) {
        return false;
      }

      if (embeddedLastReadTimestamps && embeddedLastReadTimestamps[nodeID]) {
        return contentTimestamp > parseInt(embeddedLastReadTimestamps[nodeID], 10);
      }

      var minLastReadTimestamp = parseInt(storage.getItem('Drupal.history.' + currentUserID + '.' + nodeID) || 0, 10);
      return contentTimestamp > minLastReadTimestamp;
    }
  };
})(jQuery, Drupal, drupalSettings, window.localStorage);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (window, Drupal, drupalSettings) {
  window.addEventListener('load', function () {
    if (drupalSettings.history && drupalSettings.history.nodesToMarkAsRead) {
      Object.keys(drupalSettings.history.nodesToMarkAsRead).forEach(Drupal.history.markAsRead);
    }
  });
})(window, Drupal, drupalSettings);;
(function ($) {

  'use strict';

  /**
   * Attaches the behavior to bootstrap carousel view.
   */
  Drupal.behaviors.views_bootstrap_carousel = {
    attach: function (context, settings) {
      $('.carousel-inner').each(function() {
        if ($(this).children('div').length === 1) {
          $(this).siblings('.carousel-control, .carousel-indicators').hide();
        }
      });
    }
  }



}(jQuery));;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, debounce) {
  var liveElement = void 0;
  var announcements = [];

  Drupal.behaviors.drupalAnnounce = {
    attach: function attach(context) {
      if (!liveElement) {
        liveElement = document.createElement('div');
        liveElement.id = 'drupal-live-announce';
        liveElement.className = 'visually-hidden';
        liveElement.setAttribute('aria-live', 'polite');
        liveElement.setAttribute('aria-busy', 'false');
        document.body.appendChild(liveElement);
      }
    }
  };

  function announce() {
    var text = [];
    var priority = 'polite';
    var announcement = void 0;

    var il = announcements.length;
    for (var i = 0; i < il; i++) {
      announcement = announcements.pop();
      text.unshift(announcement.text);

      if (announcement.priority === 'assertive') {
        priority = 'assertive';
      }
    }

    if (text.length) {
      liveElement.innerHTML = '';

      liveElement.setAttribute('aria-busy', 'true');

      liveElement.setAttribute('aria-live', priority);

      liveElement.innerHTML = text.join('\n');

      liveElement.setAttribute('aria-busy', 'false');
    }
  }

  Drupal.announce = function (text, priority) {
    announcements.push({
      text: text,
      priority: priority
    });

    return debounce(announce, 200)();
  };
})(Drupal, Drupal.debounce);;
window.matchMedia||(window.matchMedia=function(){"use strict";var e=window.styleMedia||window.media;if(!e){var t=document.createElement("style"),i=document.getElementsByTagName("script")[0],n=null;t.type="text/css";t.id="matchmediajs-test";i.parentNode.insertBefore(t,i);n="getComputedStyle"in window&&window.getComputedStyle(t,null)||t.currentStyle;e={matchMedium:function(e){var i="@media "+e+"{ #matchmediajs-test { width: 1px; } }";if(t.styleSheet){t.styleSheet.cssText=i}else{t.textContent=i}return n.width==="1px"}}}return function(t){return{matches:e.matchMedium(t||"all"),media:t||"all"}}}());
;
(function(){if(window.matchMedia&&window.matchMedia("all").addListener){return false}var e=window.matchMedia,i=e("only all").matches,n=false,t=0,a=[],r=function(i){clearTimeout(t);t=setTimeout(function(){for(var i=0,n=a.length;i<n;i++){var t=a[i].mql,r=a[i].listeners||[],o=e(t.media).matches;if(o!==t.matches){t.matches=o;for(var s=0,l=r.length;s<l;s++){r[s].call(window,t)}}}},30)};window.matchMedia=function(t){var o=e(t),s=[],l=0;o.addListener=function(e){if(!i){return}if(!n){n=true;window.addEventListener("resize",r,true)}if(l===0){l=a.push({mql:o,listeners:s})}s.push(e)};o.removeListener=function(e){for(var i=0,n=s.length;i<n;i++){if(s[i]===e){s.splice(i,1)}}};return o}})();
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  var activeItem = Drupal.url(drupalSettings.path.currentPath);

  $.fn.drupalToolbarMenu = function () {
    var ui = {
      handleOpen: Drupal.t('Extend'),
      handleClose: Drupal.t('Collapse')
    };

    function toggleList($item, switcher) {
      var $toggle = $item.children('.toolbar-box').children('.toolbar-handle');
      switcher = typeof switcher !== 'undefined' ? switcher : !$item.hasClass('open');

      $item.toggleClass('open', switcher);

      $toggle.toggleClass('open', switcher);

      $toggle.find('.action').text(switcher ? ui.handleClose : ui.handleOpen);
    }

    function toggleClickHandler(event) {
      var $toggle = $(event.target);
      var $item = $toggle.closest('li');

      toggleList($item);

      var $openItems = $item.siblings().filter('.open');
      toggleList($openItems, false);
    }

    function linkClickHandler(event) {
      if (!Drupal.toolbar.models.toolbarModel.get('isFixed')) {
        Drupal.toolbar.models.toolbarModel.set('activeTab', null);
      }

      event.stopPropagation();
    }

    function initItems($menu) {
      var options = {
        class: 'toolbar-icon toolbar-handle',
        action: ui.handleOpen,
        text: ''
      };

      $menu.find('li > a').wrap('<div class="toolbar-box">');

      $menu.find('li').each(function (index, element) {
        var $item = $(element);
        if ($item.children('ul.toolbar-menu').length) {
          var $box = $item.children('.toolbar-box');
          options.text = Drupal.t('@label', {
            '@label': $box.find('a').text()
          });
          $item.children('.toolbar-box').append(Drupal.theme('toolbarMenuItemToggle', options));
        }
      });
    }

    function markListLevels($lists, level) {
      level = !level ? 1 : level;
      var $lis = $lists.children('li').addClass('level-' + level);
      $lists = $lis.children('ul');
      if ($lists.length) {
        markListLevels($lists, level + 1);
      }
    }

    function openActiveItem($menu) {
      var pathItem = $menu.find('a[href="' + window.location.pathname + '"]');
      if (pathItem.length && !activeItem) {
        activeItem = window.location.pathname;
      }
      if (activeItem) {
        var $activeItem = $menu.find('a[href="' + activeItem + '"]').addClass('menu-item--active');
        var $activeTrail = $activeItem.parentsUntil('.root', 'li').addClass('menu-item--active-trail');
        toggleList($activeTrail, true);
      }
    }

    return this.each(function (selector) {
      var $menu = $(this).once('toolbar-menu');
      if ($menu.length) {
        $menu.on('click.toolbar', '.toolbar-box', toggleClickHandler).on('click.toolbar', '.toolbar-box a', linkClickHandler);

        $menu.addClass('root');
        initItems($menu);
        markListLevels($menu);

        openActiveItem($menu);
      }
    });
  };

  Drupal.theme.toolbarMenuItemToggle = function (options) {
    return '<button class="' + options.class + '"><span class="action">' + options.action + '</span> <span class="label">' + options.text + '</span></button>';
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  var options = $.extend({
    breakpoints: {
      'toolbar.narrow': '',
      'toolbar.standard': '',
      'toolbar.wide': ''
    }
  }, drupalSettings.toolbar, {
    strings: {
      horizontal: Drupal.t('Horizontal orientation'),
      vertical: Drupal.t('Vertical orientation')
    }
  });

  Drupal.behaviors.toolbar = {
    attach: function attach(context) {
      if (!window.matchMedia('only screen').matches) {
        return;
      }

      $(context).find('#toolbar-administration').once('toolbar').each(function () {
        var model = new Drupal.toolbar.ToolbarModel({
          locked: JSON.parse(localStorage.getItem('Drupal.toolbar.trayVerticalLocked')),
          activeTab: document.getElementById(JSON.parse(localStorage.getItem('Drupal.toolbar.activeTabID'))),
          height: $('#toolbar-administration').outerHeight()
        });

        Drupal.toolbar.models.toolbarModel = model;

        Object.keys(options.breakpoints).forEach(function (label) {
          var mq = options.breakpoints[label];
          var mql = window.matchMedia(mq);
          Drupal.toolbar.mql[label] = mql;

          mql.addListener(Drupal.toolbar.mediaQueryChangeHandler.bind(null, model, label));

          Drupal.toolbar.mediaQueryChangeHandler.call(null, model, label, mql);
        });

        Drupal.toolbar.views.toolbarVisualView = new Drupal.toolbar.ToolbarVisualView({
          el: this,
          model: model,
          strings: options.strings
        });
        Drupal.toolbar.views.toolbarAuralView = new Drupal.toolbar.ToolbarAuralView({
          el: this,
          model: model,
          strings: options.strings
        });
        Drupal.toolbar.views.bodyVisualView = new Drupal.toolbar.BodyVisualView({
          el: this,
          model: model
        });

        model.trigger('change:isFixed', model, model.get('isFixed'));
        model.trigger('change:activeTray', model, model.get('activeTray'));

        var menuModel = new Drupal.toolbar.MenuModel();
        Drupal.toolbar.models.menuModel = menuModel;
        Drupal.toolbar.views.menuVisualView = new Drupal.toolbar.MenuVisualView({
          el: $(this).find('.toolbar-menu-administration').get(0),
          model: menuModel,
          strings: options.strings
        });

        Drupal.toolbar.setSubtrees.done(function (subtrees) {
          menuModel.set('subtrees', subtrees);
          var theme = drupalSettings.ajaxPageState.theme;
          localStorage.setItem('Drupal.toolbar.subtrees.' + theme, JSON.stringify(subtrees));

          model.set('areSubtreesLoaded', true);
        });

        Drupal.toolbar.views.toolbarVisualView.loadSubtrees();

        $(document).on('drupalViewportOffsetChange.toolbar', function (event, offsets) {
          model.set('offsets', offsets);
        });

        model.on('change:orientation', function (model, orientation) {
          $(document).trigger('drupalToolbarOrientationChange', orientation);
        }).on('change:activeTab', function (model, tab) {
          $(document).trigger('drupalToolbarTabChange', tab);
        }).on('change:activeTray', function (model, tray) {
          $(document).trigger('drupalToolbarTrayChange', tray);
        });

        if (Drupal.toolbar.models.toolbarModel.get('orientation') === 'horizontal' && Drupal.toolbar.models.toolbarModel.get('activeTab') === null) {
          Drupal.toolbar.models.toolbarModel.set({
            activeTab: $('.toolbar-bar .toolbar-tab:not(.home-toolbar-tab) a').get(0)
          });
        }

        $(window).on({
          'dialog:aftercreate': function dialogAftercreate(event, dialog, $element, settings) {
            var $toolbar = $('#toolbar-bar');
            $toolbar.css('margin-top', '0');

            if (settings.drupalOffCanvasPosition === 'top') {
              var height = Drupal.offCanvas.getContainer($element).outerHeight();
              $toolbar.css('margin-top', height + 'px');

              $element.on('dialogContentResize.off-canvas', function () {
                var newHeight = Drupal.offCanvas.getContainer($element).outerHeight();
                $toolbar.css('margin-top', newHeight + 'px');
              });
            }
          },
          'dialog:beforeclose': function dialogBeforeclose() {
            $('#toolbar-bar').css('margin-top', '0');
          }
        });
      });
    }
  };

  Drupal.toolbar = {
    views: {},

    models: {},

    mql: {},

    setSubtrees: new $.Deferred(),

    mediaQueryChangeHandler: function mediaQueryChangeHandler(model, label, mql) {
      switch (label) {
        case 'toolbar.narrow':
          model.set({
            isOriented: mql.matches,
            isTrayToggleVisible: false
          });

          if (!mql.matches || !model.get('orientation')) {
            model.set({ orientation: 'vertical' }, { validate: true });
          }
          break;

        case 'toolbar.standard':
          model.set({
            isFixed: mql.matches
          });
          break;

        case 'toolbar.wide':
          model.set({
            orientation: mql.matches && !model.get('locked') ? 'horizontal' : 'vertical'
          }, { validate: true });

          model.set({
            isTrayToggleVisible: mql.matches
          });
          break;

        default:
          break;
      }
    }
  };

  Drupal.theme.toolbarOrientationToggle = function () {
    return '<div class="toolbar-toggle-orientation"><div class="toolbar-lining">' + '<button class="toolbar-icon" type="button"></button>' + '</div></div>';
  };

  Drupal.AjaxCommands.prototype.setToolbarSubtrees = function (ajax, response, status) {
    Drupal.toolbar.setSubtrees.resolve(response.subtrees);
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.MenuModel = Backbone.Model.extend({
    defaults: {
      subtrees: {}
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.ToolbarModel = Backbone.Model.extend({
    defaults: {
      activeTab: null,

      activeTray: null,

      isOriented: false,

      isFixed: false,

      areSubtreesLoaded: false,

      isViewportOverflowConstrained: false,

      orientation: 'horizontal',

      locked: false,

      isTrayToggleVisible: true,

      height: null,

      offsets: {
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
      }
    },

    validate: function validate(attributes, options) {
      if (attributes.orientation === 'horizontal' && this.get('locked') && !options.override) {
        return Drupal.t('The toolbar cannot be set to a horizontal orientation when it is locked.');
      }
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, Backbone) {
  Drupal.toolbar.BodyVisualView = Backbone.View.extend({
    initialize: function initialize() {
      this.listenTo(this.model, 'change:activeTray ', this.render);
      this.listenTo(this.model, 'change:isFixed change:isViewportOverflowConstrained', this.isToolbarFixed);
    },
    isToolbarFixed: function isToolbarFixed() {
      var isViewportOverflowConstrained = this.model.get('isViewportOverflowConstrained');
      $('body').toggleClass('toolbar-fixed', isViewportOverflowConstrained || this.model.get('isFixed'));
    },
    render: function render() {
      $('body').toggleClass('toolbar-tray-open', !!this.model.get('activeTray'));
    }
  });
})(jQuery, Drupal, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal) {
  Drupal.toolbar.MenuVisualView = Backbone.View.extend({
    initialize: function initialize() {
      this.listenTo(this.model, 'change:subtrees', this.render);
    },
    render: function render() {
      var _this = this;

      var subtrees = this.model.get('subtrees');

      Object.keys(subtrees || {}).forEach(function (id) {
        _this.$el.find('#toolbar-link-' + id).once('toolbar-subtrees').after(subtrees[id]);
      });

      if ('drupalToolbarMenu' in $.fn) {
        this.$el.children('.toolbar-menu').drupalToolbarMenu();
      }
    }
  });
})(jQuery, Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Backbone, Drupal) {
  Drupal.toolbar.ToolbarAuralView = Backbone.View.extend({
    initialize: function initialize(options) {
      this.strings = options.strings;

      this.listenTo(this.model, 'change:orientation', this.onOrientationChange);
      this.listenTo(this.model, 'change:activeTray', this.onActiveTrayChange);
    },
    onOrientationChange: function onOrientationChange(model, orientation) {
      Drupal.announce(Drupal.t('Tray orientation changed to @orientation.', {
        '@orientation': orientation
      }));
    },
    onActiveTrayChange: function onActiveTrayChange(model, tray) {
      var relevantTray = tray === null ? model.previous('activeTray') : tray;

      if (!relevantTray) {
        return;
      }
      var action = tray === null ? Drupal.t('closed') : Drupal.t('opened');
      var trayNameElement = relevantTray.querySelector('.toolbar-tray-name');
      var text = void 0;
      if (trayNameElement !== null) {
        text = Drupal.t('Tray "@tray" @action.', {
          '@tray': trayNameElement.textContent,
          '@action': action
        });
      } else {
        text = Drupal.t('Tray @action.', { '@action': action });
      }
      Drupal.announce(text);
    }
  });
})(Backbone, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings, Backbone) {
  Drupal.toolbar.ToolbarVisualView = Backbone.View.extend({
    events: function events() {
      var touchEndToClick = function touchEndToClick(event) {
        event.preventDefault();
        event.target.click();
      };

      return {
        'click .toolbar-bar .toolbar-tab .trigger': 'onTabClick',
        'click .toolbar-toggle-orientation button': 'onOrientationToggleClick',
        'touchend .toolbar-bar .toolbar-tab .trigger': touchEndToClick,
        'touchend .toolbar-toggle-orientation button': touchEndToClick
      };
    },
    initialize: function initialize(options) {
      this.strings = options.strings;

      this.listenTo(this.model, 'change:activeTab change:orientation change:isOriented change:isTrayToggleVisible', this.render);
      this.listenTo(this.model, 'change:mqMatches', this.onMediaQueryChange);
      this.listenTo(this.model, 'change:offsets', this.adjustPlacement);
      this.listenTo(this.model, 'change:activeTab change:orientation change:isOriented', this.updateToolbarHeight);

      this.$el.find('.toolbar-tray .toolbar-lining').append(Drupal.theme('toolbarOrientationToggle'));

      this.model.trigger('change:activeTab');
    },
    updateToolbarHeight: function updateToolbarHeight() {
      var toolbarTabOuterHeight = $('#toolbar-bar').find('.toolbar-tab').outerHeight() || 0;
      var toolbarTrayHorizontalOuterHeight = $('.is-active.toolbar-tray-horizontal').outerHeight() || 0;
      this.model.set('height', toolbarTabOuterHeight + toolbarTrayHorizontalOuterHeight);

      $('body').css({
        'padding-top': this.model.get('height')
      });

      this.triggerDisplace();
    },
    triggerDisplace: function triggerDisplace() {
      _.defer(function () {
        Drupal.displace(true);
      });
    },
    render: function render() {
      this.updateTabs();
      this.updateTrayOrientation();
      this.updateBarAttributes();

      $('body').removeClass('toolbar-loading');

      if (this.model.changed.orientation === 'vertical' || this.model.changed.activeTab) {
        this.loadSubtrees();
      }

      return this;
    },
    onTabClick: function onTabClick(event) {
      if (event.target.hasAttribute('data-toolbar-tray')) {
        var activeTab = this.model.get('activeTab');
        var clickedTab = event.target;

        this.model.set('activeTab', !activeTab || clickedTab !== activeTab ? clickedTab : null);

        event.preventDefault();
        event.stopPropagation();
      }
    },
    onOrientationToggleClick: function onOrientationToggleClick(event) {
      var orientation = this.model.get('orientation');

      var antiOrientation = orientation === 'vertical' ? 'horizontal' : 'vertical';
      var locked = antiOrientation === 'vertical';

      if (locked) {
        localStorage.setItem('Drupal.toolbar.trayVerticalLocked', 'true');
      } else {
        localStorage.removeItem('Drupal.toolbar.trayVerticalLocked');
      }

      this.model.set({
        locked: locked,
        orientation: antiOrientation
      }, {
        validate: true,
        override: true
      });

      event.preventDefault();
      event.stopPropagation();
    },
    updateTabs: function updateTabs() {
      var $tab = $(this.model.get('activeTab'));

      $(this.model.previous('activeTab')).removeClass('is-active').prop('aria-pressed', false);

      $(this.model.previous('activeTray')).removeClass('is-active');

      if ($tab.length > 0) {
        $tab.addClass('is-active').prop('aria-pressed', true);
        var name = $tab.attr('data-toolbar-tray');

        var id = $tab.get(0).id;
        if (id) {
          localStorage.setItem('Drupal.toolbar.activeTabID', JSON.stringify(id));
        }

        var $tray = this.$el.find('[data-toolbar-tray="' + name + '"].toolbar-tray');
        if ($tray.length) {
          $tray.addClass('is-active');
          this.model.set('activeTray', $tray.get(0));
        } else {
          this.model.set('activeTray', null);
        }
      } else {
        this.model.set('activeTray', null);
        localStorage.removeItem('Drupal.toolbar.activeTabID');
      }
    },
    updateBarAttributes: function updateBarAttributes() {
      var isOriented = this.model.get('isOriented');
      if (isOriented) {
        this.$el.find('.toolbar-bar').attr('data-offset-top', '');
      } else {
        this.$el.find('.toolbar-bar').removeAttr('data-offset-top');
      }

      this.$el.toggleClass('toolbar-oriented', isOriented);
    },
    updateTrayOrientation: function updateTrayOrientation() {
      var orientation = this.model.get('orientation');

      var antiOrientation = orientation === 'vertical' ? 'horizontal' : 'vertical';

      $('body').toggleClass('toolbar-vertical', orientation === 'vertical').toggleClass('toolbar-horizontal', orientation === 'horizontal');

      var removeClass = antiOrientation === 'horizontal' ? 'toolbar-tray-horizontal' : 'toolbar-tray-vertical';
      var $trays = this.$el.find('.toolbar-tray').removeClass(removeClass).addClass('toolbar-tray-' + orientation);

      var iconClass = 'toolbar-icon-toggle-' + orientation;
      var iconAntiClass = 'toolbar-icon-toggle-' + antiOrientation;
      var $orientationToggle = this.$el.find('.toolbar-toggle-orientation').toggle(this.model.get('isTrayToggleVisible'));
      $orientationToggle.find('button').val(antiOrientation).attr('title', this.strings[antiOrientation]).text(this.strings[antiOrientation]).removeClass(iconClass).addClass(iconAntiClass);

      var dir = document.documentElement.dir;
      var edge = dir === 'rtl' ? 'right' : 'left';

      $trays.removeAttr('data-offset-left data-offset-right data-offset-top');

      $trays.filter('.toolbar-tray-vertical.is-active').attr('data-offset-' + edge, '');

      $trays.filter('.toolbar-tray-horizontal.is-active').attr('data-offset-top', '');
    },
    adjustPlacement: function adjustPlacement() {
      var $trays = this.$el.find('.toolbar-tray');
      if (!this.model.get('isOriented')) {
        $trays.removeClass('toolbar-tray-horizontal').addClass('toolbar-tray-vertical');
      }
    },
    loadSubtrees: function loadSubtrees() {
      var $activeTab = $(this.model.get('activeTab'));
      var orientation = this.model.get('orientation');

      if (!this.model.get('areSubtreesLoaded') && typeof $activeTab.data('drupal-subtrees') !== 'undefined' && orientation === 'vertical') {
        var subtreesHash = drupalSettings.toolbar.subtreesHash;
        var theme = drupalSettings.ajaxPageState.theme;
        var endpoint = Drupal.url('toolbar/subtrees/' + subtreesHash);
        var cachedSubtreesHash = localStorage.getItem('Drupal.toolbar.subtreesHash.' + theme);
        var cachedSubtrees = JSON.parse(localStorage.getItem('Drupal.toolbar.subtrees.' + theme));
        var isVertical = this.model.get('orientation') === 'vertical';

        if (isVertical && subtreesHash === cachedSubtreesHash && cachedSubtrees) {
          Drupal.toolbar.setSubtrees.resolve(cachedSubtrees);
        } else if (isVertical) {
            localStorage.removeItem('Drupal.toolbar.subtreesHash.' + theme);
            localStorage.removeItem('Drupal.toolbar.subtrees.' + theme);

            Drupal.ajax({ url: endpoint }).execute();

            localStorage.setItem('Drupal.toolbar.subtreesHash.' + theme, subtreesHash);
          }
      }
    }
  });
})(jQuery, Drupal, drupalSettings, Backbone);;
  /*
 * jQuery Foundation Joyride Plugin 2.1
 * http://foundation.zurb.com
 * Copyright 2013, ZURB
 * Free to use under the MIT license.
 * http://www.opensource.org/licenses/mit-license.php
*/

/*jslint unparam: true, browser: true, indent: 2 */

;(function ($, window, undefined) {
  'use strict';

  var defaults = {
      'version'              : '2.1',
      'tipLocation'          : 'bottom',  // 'top' or 'bottom' in relation to parent
      'nubPosition'          : 'auto',    // override on a per tooltip bases
      'scroll'               : true,      // whether to scroll to tips
      'scrollSpeed'          : 300,       // Page scrolling speed in milliseconds
      'timer'                : 0,         // 0 = no timer , all other numbers = timer in milliseconds
      'autoStart'            : false,     // true or false - false tour starts when restart called
      'startTimerOnClick'    : true,      // true or false - true requires clicking the first button start the timer
      'startOffset'          : 0,         // the index of the tooltip you want to start on (index of the li)
      'nextButton'           : true,      // true or false to control whether a next button is used
      'tipAnimation'         : 'fade',    // 'pop' or 'fade' in each tip
      'pauseAfter'           : [],        // array of indexes where to pause the tour after
      'tipAnimationFadeSpeed': 300,       // when tipAnimation = 'fade' this is speed in milliseconds for the transition
      'cookieMonster'        : false,     // true or false to control whether cookies are used
      'cookieName'           : 'joyride', // Name the cookie you'll use
      'cookieDomain'         : false,     // Will this cookie be attached to a domain, ie. '.notableapp.com'
      'cookiePath'           : false,     // Set to '/' if you want the cookie for the whole website
      'localStorage'         : false,     // true or false to control whether localstorage is used
      'localStorageKey'      : 'joyride', // Keyname in localstorage
      'tipContainer'         : 'body',    // Where will the tip be attached
      'modal'                : false,     // Whether to cover page with modal during the tour
      'expose'               : false,     // Whether to expose the elements at each step in the tour (requires modal:true)
      'postExposeCallback'   : $.noop,    // A method to call after an element has been exposed
      'preRideCallback'      : $.noop,    // A method to call before the tour starts (passed index, tip, and cloned exposed element)
      'postRideCallback'     : $.noop,    // A method to call once the tour closes (canceled or complete)
      'preStepCallback'      : $.noop,    // A method to call before each step
      'postStepCallback'     : $.noop,    // A method to call after each step
      'template' : { // HTML segments for tip layout
        'link'    : '<a href="#close" class="joyride-close-tip">X</a>',
        'timer'   : '<div class="joyride-timer-indicator-wrap"><span class="joyride-timer-indicator"></span></div>',
        'tip'     : '<div class="joyride-tip-guide"><span class="joyride-nub"></span></div>',
        'wrapper' : '<div class="joyride-content-wrapper" role="dialog"></div>',
        'button'  : '<a href="#" class="joyride-next-tip"></a>',
        'modal'   : '<div class="joyride-modal-bg"></div>',
        'expose'  : '<div class="joyride-expose-wrapper"></div>',
        'exposeCover': '<div class="joyride-expose-cover"></div>'
      }
    },

    Modernizr = Modernizr || false,

    settings = {},

    methods = {

      init : function (opts) {
        return this.each(function () {

          if ($.isEmptyObject(settings)) {
            settings = $.extend(true, defaults, opts);

            // non configurable settings
            settings.document = window.document;
            settings.$document = $(settings.document);
            settings.$window = $(window);
            settings.$content_el = $(this);
            settings.$body = $(settings.tipContainer);
            settings.body_offset = $(settings.tipContainer).position();
            settings.$tip_content = $('> li', settings.$content_el);
            settings.paused = false;
            settings.attempts = 0;

            settings.tipLocationPatterns = {
              top: ['bottom'],
              bottom: [], // bottom should not need to be repositioned
              left: ['right', 'top', 'bottom'],
              right: ['left', 'top', 'bottom']
            };

            // are we using jQuery 1.7+
            methods.jquery_check();

            // can we create cookies?
            if (!$.isFunction($.cookie)) {
              settings.cookieMonster = false;
            }

            // generate the tips and insert into dom.
            if ( (!settings.cookieMonster || !$.cookie(settings.cookieName) ) &&
              (!settings.localStorage || !methods.support_localstorage() || !localStorage.getItem(settings.localStorageKey) ) ) {

              settings.$tip_content.each(function (index) {
                methods.create({$li : $(this), index : index});
              });

              // show first tip
              if(settings.autoStart)
              {
                if (!settings.startTimerOnClick && settings.timer > 0) {
                  methods.show('init');
                  methods.startTimer();
                } else {
                  methods.show('init');
                }
              }

            }

            settings.$document.on('click.joyride', '.joyride-next-tip, .joyride-modal-bg', function (e) {
              e.preventDefault();

              if (settings.$li.next().length < 1) {
                methods.end();
              } else if (settings.timer > 0) {
                clearTimeout(settings.automate);
                methods.hide();
                methods.show();
                methods.startTimer();
              } else {
                methods.hide();
                methods.show();
              }

            });

            settings.$document.on('click.joyride', '.joyride-close-tip', function (e) {
              e.preventDefault();
              methods.end(true /* isAborted */);
            });

            settings.$window.on('resize.joyride', function (e) {
              if(settings.$li){
              if(settings.exposed && settings.exposed.length>0){
                var $els = $(settings.exposed);
                $els.each(function(){
                  var $this = $(this);
                  methods.un_expose($this);
                  methods.expose($this);
                });
              }
              if (methods.is_phone()) {
                methods.pos_phone();
              } else {
                methods.pos_default();
              }
              }
            });
          } else {
            methods.restart();
          }

        });
      },

      // call this method when you want to resume the tour
      resume : function () {
        methods.set_li();
        methods.show();
      },

      nextTip: function(){
            if (settings.$li.next().length < 1) {
            methods.end();
            } else if (settings.timer > 0) {
            clearTimeout(settings.automate);
            methods.hide();
            methods.show();
            methods.startTimer();
            } else {
            methods.hide();
            methods.show();
            }
      },

      tip_template : function (opts) {
        var $blank, content, $wrapper;

        opts.tip_class = opts.tip_class || '';

        $blank = $(settings.template.tip).addClass(opts.tip_class);
        content = $.trim($(opts.li).html()) +
          methods.button_text(opts.button_text) +
          settings.template.link +
          methods.timer_instance(opts.index);

        $wrapper = $(settings.template.wrapper);
        if (opts.li.attr('data-aria-labelledby')) {
          $wrapper.attr('aria-labelledby', opts.li.attr('data-aria-labelledby'))
        }
        if (opts.li.attr('data-aria-describedby')) {
          $wrapper.attr('aria-describedby', opts.li.attr('data-aria-describedby'))
        }
        $blank.append($wrapper);
        $blank.first().attr('data-index', opts.index);
        $('.joyride-content-wrapper', $blank).append(content);

        return $blank[0];
      },

      timer_instance : function (index) {
        var txt;

        if ((index === 0 && settings.startTimerOnClick && settings.timer > 0) || settings.timer === 0) {
          txt = '';
        } else {
          txt = methods.outerHTML($(settings.template.timer)[0]);
        }
        return txt;
      },

      button_text : function (txt) {
        if (settings.nextButton) {
          txt = $.trim(txt) || 'Next';
          txt = methods.outerHTML($(settings.template.button).append(txt)[0]);
        } else {
          txt = '';
        }
        return txt;
      },

      create : function (opts) {
        // backwards compatibility with data-text attribute
        var buttonText = opts.$li.attr('data-button') || opts.$li.attr('data-text'),
          tipClass = opts.$li.attr('class'),
          $tip_content = $(methods.tip_template({
            tip_class : tipClass,
            index : opts.index,
            button_text : buttonText,
            li : opts.$li
          }));

        $(settings.tipContainer).append($tip_content);
      },

      show : function (init) {
        var opts = {}, ii, opts_arr = [], opts_len = 0, p,
            $timer = null;

        // are we paused?
        if (settings.$li === undefined || ($.inArray(settings.$li.index(), settings.pauseAfter) === -1)) {

          // don't go to the next li if the tour was paused
          if (settings.paused) {
            settings.paused = false;
          } else {
            methods.set_li(init);
          }

          settings.attempts = 0;

          if (settings.$li.length && settings.$target.length > 0) {
            if(init){ //run when we first start
                settings.preRideCallback(settings.$li.index(), settings.$next_tip );
                if(settings.modal){
                    methods.show_modal();
                }
            }
            settings.preStepCallback(settings.$li.index(), settings.$next_tip );

            // parse options
            opts_arr = (settings.$li.data('options') || ':').split(';');
            opts_len = opts_arr.length;
            for (ii = opts_len - 1; ii >= 0; ii--) {
              p = opts_arr[ii].split(':');

              if (p.length === 2) {
                opts[$.trim(p[0])] = $.trim(p[1]);
              }
            }
            settings.tipSettings = $.extend({}, settings, opts);
            settings.tipSettings.tipLocationPattern = settings.tipLocationPatterns[settings.tipSettings.tipLocation];

            if(settings.modal && settings.expose){
              methods.expose();
            }

            // scroll if not modal
            if (!settings.$target.is("body") && settings.scroll) {
              methods.scroll_to();
            }

            if (methods.is_phone()) {
              methods.pos_phone(true);
            } else {
              methods.pos_default(true);
            }

            $timer = $('.joyride-timer-indicator', settings.$next_tip);

            if (/pop/i.test(settings.tipAnimation)) {

              $timer.outerWidth(0);

              if (settings.timer > 0) {

                settings.$next_tip.show();
                $timer.animate({
                  width: $('.joyride-timer-indicator-wrap', settings.$next_tip).outerWidth()
                }, settings.timer);

              } else {

                settings.$next_tip.show();

              }


            } else if (/fade/i.test(settings.tipAnimation)) {

              $timer.outerWidth(0);

              if (settings.timer > 0) {

                settings.$next_tip.fadeIn(settings.tipAnimationFadeSpeed);

                settings.$next_tip.show();
                $timer.animate({
                  width: $('.joyride-timer-indicator-wrap', settings.$next_tip).outerWidth()
                }, settings.timer);

              } else {

                settings.$next_tip.fadeIn(settings.tipAnimationFadeSpeed);

              }
            }

            settings.$current_tip = settings.$next_tip;
            // Focus next button for keyboard users.
            $('.joyride-next-tip', settings.$current_tip).focus();
            methods.tabbable(settings.$current_tip);
          // skip non-existent targets
          } else if (settings.$li && settings.$target.length < 1) {

            methods.show();

          } else {

            methods.end();

          }
        } else {

          settings.paused = true;

        }

      },

      // detect phones with media queries if supported.
      is_phone : function () {
        if (Modernizr) {
          return Modernizr.mq('only screen and (max-width: 767px)');
        }

        return (settings.$window.width() < 767) ? true : false;
      },

      support_localstorage : function () {
        if (Modernizr) {
          return Modernizr.localstorage;
        } else {
          return !!window.localStorage;
        }
      },

      hide : function () {
        if(settings.modal && settings.expose){
          methods.un_expose();
        }
        if(!settings.modal){
        $('.joyride-modal-bg').hide();
        }
        settings.$current_tip.hide();
        settings.postStepCallback(settings.$li.index(), settings.$current_tip);
      },

      set_li : function (init) {
        if (init) {
          settings.$li = settings.$tip_content.eq(settings.startOffset);
          methods.set_next_tip();
          settings.$current_tip = settings.$next_tip;
        } else {
          settings.$li = settings.$li.next();
          methods.set_next_tip();
        }

        methods.set_target();
      },

      set_next_tip : function () {
        settings.$next_tip = $('.joyride-tip-guide[data-index=' + settings.$li.index() + ']');
      },

      set_target : function () {
        var cl = settings.$li.attr('data-class'),
            id = settings.$li.attr('data-id'),
            $sel = function () {
              if (id) {
                return $(settings.document.getElementById(id));
              } else if (cl) {
                return $('.' + cl).filter(":visible").first();
              } else {
                return $('body');
              }
            };

        settings.$target = $sel();
      },

      scroll_to : function () {
        var window_half, tipOffset;

        window_half = settings.$window.height() / 2;
        tipOffset = Math.ceil(settings.$target.offset().top - window_half + settings.$next_tip.outerHeight());

        $("html, body").stop().animate({
          scrollTop: tipOffset
        }, settings.scrollSpeed);
      },

      paused : function () {
        if (($.inArray((settings.$li.index() + 1), settings.pauseAfter) === -1)) {
          return true;
        }

        return false;
      },

      destroy : function () {
        if(!$.isEmptyObject(settings)){
        settings.$document.off('.joyride');
        }

        $(window).off('.joyride');
        $('.joyride-close-tip, .joyride-next-tip, .joyride-modal-bg').off('.joyride');
        $('.joyride-tip-guide, .joyride-modal-bg').remove();
        clearTimeout(settings.automate);
        settings = {};
      },

      restart : function () {
        if(!settings.autoStart)
        {
          if (!settings.startTimerOnClick && settings.timer > 0) {
            methods.show('init');
            methods.startTimer();
          } else {
            methods.show('init');
          }
          settings.autoStart = true;
        }
        else
        {
        methods.hide();
        settings.$li = undefined;
        methods.show('init');
        }
      },

      pos_default : function (init) {
        var half_fold = Math.ceil(settings.$window.height() / 2),
            tip_position = settings.$next_tip.offset(),
            $nub = $('.joyride-nub', settings.$next_tip),
            nub_width = Math.ceil($nub.outerWidth() / 2),
            nub_height = Math.ceil($nub.outerHeight() / 2),
            toggle = init || false;

        // tip must not be "display: none" to calculate position
        if (toggle) {
          settings.$next_tip.css('visibility', 'hidden');
          settings.$next_tip.show();
        }

        if (!settings.$target.is("body")) {
            var
              topAdjustment = settings.tipSettings.tipAdjustmentY ? parseInt(settings.tipSettings.tipAdjustmentY) : 0,
              leftAdjustment = settings.tipSettings.tipAdjustmentX ? parseInt(settings.tipSettings.tipAdjustmentX) : 0;

            if (methods.bottom()) {
              settings.$next_tip.css({
                top: (settings.$target.offset().top + nub_height + settings.$target.outerHeight() + topAdjustment),
                left: settings.$target.offset().left + leftAdjustment});

              if (/right/i.test(settings.tipSettings.nubPosition)) {
                settings.$next_tip.css('left', settings.$target.offset().left - settings.$next_tip.outerWidth() + settings.$target.outerWidth());
              }

              methods.nub_position($nub, settings.tipSettings.nubPosition, 'top');

            } else if (methods.top()) {

              settings.$next_tip.css({
                top: (settings.$target.offset().top - settings.$next_tip.outerHeight() - nub_height + topAdjustment),
                left: settings.$target.offset().left + leftAdjustment});

              methods.nub_position($nub, settings.tipSettings.nubPosition, 'bottom');

            } else if (methods.right()) {

              settings.$next_tip.css({
                top: settings.$target.offset().top + topAdjustment,
                left: (settings.$target.outerWidth() + settings.$target.offset().left + nub_width) + leftAdjustment});

              methods.nub_position($nub, settings.tipSettings.nubPosition, 'left');

            } else if (methods.left()) {

              settings.$next_tip.css({
                top: settings.$target.offset().top + topAdjustment,
                left: (settings.$target.offset().left - settings.$next_tip.outerWidth() - nub_width) + leftAdjustment});

              methods.nub_position($nub, settings.tipSettings.nubPosition, 'right');

            }

            if (!methods.visible(methods.corners(settings.$next_tip)) && settings.attempts < settings.tipSettings.tipLocationPattern.length) {

              $nub.removeClass('bottom')
                .removeClass('top')
                .removeClass('right')
                .removeClass('left');

              settings.tipSettings.tipLocation = settings.tipSettings.tipLocationPattern[settings.attempts];

              settings.attempts++;

              methods.pos_default(true);

            }

        } else if (settings.$li.length) {

          methods.pos_modal($nub);

        }

        if (toggle) {
          settings.$next_tip.hide();
          settings.$next_tip.css('visibility', 'visible');
        }

      },

      pos_phone : function (init) {
        var tip_height = settings.$next_tip.outerHeight(),
            tip_offset = settings.$next_tip.offset(),
            target_height = settings.$target.outerHeight(),
            $nub = $('.joyride-nub', settings.$next_tip),
            nub_height = Math.ceil($nub.outerHeight() / 2),
            toggle = init || false;

        $nub.removeClass('bottom')
          .removeClass('top')
          .removeClass('right')
          .removeClass('left');

        if (toggle) {
          settings.$next_tip.css('visibility', 'hidden');
          settings.$next_tip.show();
        }

        if (!settings.$target.is("body")) {

          if (methods.top()) {

              settings.$next_tip.offset({top: settings.$target.offset().top - tip_height - nub_height});
              $nub.addClass('bottom');

          } else {

            settings.$next_tip.offset({top: settings.$target.offset().top + target_height + nub_height});
            $nub.addClass('top');

          }

        } else if (settings.$li.length) {

          methods.pos_modal($nub);

        }

        if (toggle) {
          settings.$next_tip.hide();
          settings.$next_tip.css('visibility', 'visible');
        }
      },

      pos_modal : function ($nub) {
        methods.center();
        $nub.hide();

        methods.show_modal();

      },

      show_modal : function() {
        if ($('.joyride-modal-bg').length < 1) {
            $('body').append(settings.template.modal).show();
        }

        if (/pop/i.test(settings.tipAnimation)) {
          $('.joyride-modal-bg').show();
        } else {
          $('.joyride-modal-bg').fadeIn(settings.tipAnimationFadeSpeed);
        }
      },

      expose: function(){
        var expose,
          exposeCover,
          el,
          origCSS,
          randId = 'expose-'+Math.floor(Math.random()*10000);
        if (arguments.length>0 && arguments[0] instanceof $){
          el = arguments[0];
        } else if(settings.$target && !settings.$target.is("body")){
          el = settings.$target;
        }  else {
          return false;
        }
        if(el.length < 1){
          if(window.console){
            console.error('element not valid', el);
          }
          return false;
        }
        expose = $(settings.template.expose);
        settings.$body.append(expose);
        expose.css({
          top: el.offset().top,
          left: el.offset().left,
          width: el.outerWidth(true),
          height: el.outerHeight(true)
        });
        exposeCover = $(settings.template.exposeCover);
        origCSS = {
                  zIndex: el.css('z-index'),
                  position: el.css('position')
                  };
        el.css('z-index',expose.css('z-index')*1+1);
        if(origCSS.position == 'static'){
          el.css('position','relative');
        }
        el.data('expose-css',origCSS);
        exposeCover.css({
          top: el.offset().top,
          left: el.offset().left,
          width: el.outerWidth(true),
          height: el.outerHeight(true)
        });
        settings.$body.append(exposeCover);
        expose.addClass(randId);
        exposeCover.addClass(randId);
        if(settings.tipSettings['exposeClass']){
          expose.addClass(settings.tipSettings['exposeClass']);
          exposeCover.addClass(settings.tipSettings['exposeClass']);
        }
        el.data('expose', randId);
        settings.postExposeCallback(settings.$li.index(), settings.$next_tip, el);
        methods.add_exposed(el);
      },

      un_expose: function(){
        var exposeId,
          el,
          expose ,
          origCSS,
          clearAll = false;
        if (arguments.length>0 && arguments[0] instanceof $){
          el = arguments[0];
        } else if(settings.$target && !settings.$target.is("body")){
          el = settings.$target;
        }  else {
          return false;
        }
        if(el.length < 1){
          if(window.console){
            console.error('element not valid', el);
          }
          return false;
        }
        exposeId = el.data('expose');
        expose = $('.'+exposeId);
        if(arguments.length>1){
          clearAll = arguments[1];
        }
        if(clearAll === true){
          $('.joyride-expose-wrapper,.joyride-expose-cover').remove();
        } else {
          expose.remove();
        }
        origCSS = el.data('expose-css');
        if(origCSS.zIndex == 'auto'){
          el.css('z-index', '');
        } else {
          el.css('z-index',origCSS.zIndex);
        }
        if(origCSS.position != el.css('position')){
          if(origCSS.position == 'static'){// this is default, no need to set it.
            el.css('position', '');
          } else {
            el.css('position',origCSS.position);
          }
        }
        el.removeData('expose');
        el.removeData('expose-z-index');
        methods.remove_exposed(el);
      },

      add_exposed: function(el){
        settings.exposed = settings.exposed || [];
        if(el instanceof $){
          settings.exposed.push(el[0]);
        } else if(typeof el == 'string'){
          settings.exposed.push(el);
        }
      },

      remove_exposed: function(el){
        var search;
        if(el instanceof $){
          search = el[0]
        } else if (typeof el == 'string'){
          search = el;
        }
        settings.exposed = settings.exposed || [];
        for(var i=0; i<settings.exposed.length; i++){
          if(settings.exposed[i] == search){
            settings.exposed.splice(i,1);
            return;
          }
        }
      },

      center : function () {
        var $w = settings.$window;

        settings.$next_tip.css({
          top : ((($w.height() - settings.$next_tip.outerHeight()) / 2) + $w.scrollTop()),
          left : ((($w.width() - settings.$next_tip.outerWidth()) / 2) + $w.scrollLeft())
        });

        return true;
      },

      bottom : function () {
        return /bottom/i.test(settings.tipSettings.tipLocation);
      },

      top : function () {
        return /top/i.test(settings.tipSettings.tipLocation);
      },

      right : function () {
        return /right/i.test(settings.tipSettings.tipLocation);
      },

      left : function () {
        return /left/i.test(settings.tipSettings.tipLocation);
      },

      corners : function (el) {
        var w = settings.$window,
            window_half = w.height() / 2,
            tipOffset = Math.ceil(settings.$target.offset().top - window_half + settings.$next_tip.outerHeight()),//using this to calculate since scroll may not have finished yet.
            right = w.width() + w.scrollLeft(),
            offsetBottom =  w.height() + tipOffset,
            bottom = w.height() + w.scrollTop(),
            top = w.scrollTop();

            if(tipOffset < top){
              if (tipOffset <0 ){
                top = 0;
              } else {
                top = tipOffset;
              }
            }

            if(offsetBottom > bottom){
              bottom = offsetBottom;
            }

        return [
          el.offset().top < top,
          right < el.offset().left + el.outerWidth(),
          bottom < el.offset().top + el.outerHeight(),
          w.scrollLeft() > el.offset().left
        ];
      },

      visible : function (hidden_corners) {
        var i = hidden_corners.length;

        while (i--) {
          if (hidden_corners[i]) return false;
        }

        return true;
      },

      nub_position : function (nub, pos, def) {
        if (pos === 'auto') {
          nub.addClass(def);
        } else {
          nub.addClass(pos);
        }
      },

      startTimer : function () {
        if (settings.$li.length) {
          settings.automate = setTimeout(function () {
            methods.hide();
            methods.show();
            methods.startTimer();
          }, settings.timer);
        } else {
          clearTimeout(settings.automate);
        }
      },

      end : function (isAborted) {
        isAborted = isAborted || false;

        // Unbind resize events.
        if (isAborted) {
          settings.$window.off('resize.joyride');
        }

        if (settings.cookieMonster) {
          $.cookie(settings.cookieName, 'ridden', { expires: 365, domain: settings.cookieDomain, path: settings.cookiePath });
        }

        if (settings.localStorage) {
          localStorage.setItem(settings.localStorageKey, true);
        }

        if (settings.timer > 0) {
          clearTimeout(settings.automate);
        }
        if(settings.modal && settings.expose){
          methods.un_expose();
        }
        if (settings.$current_tip) {
          settings.$current_tip.hide();
        }
        if (settings.$li) {
          settings.postStepCallback(settings.$li.index(), settings.$current_tip, isAborted);
          settings.postRideCallback(settings.$li.index(), settings.$current_tip, isAborted);
        }
        $('.joyride-modal-bg').hide();
      },

      jquery_check : function () {
        // define on() and off() for older jQuery
        if (!$.isFunction($.fn.on)) {

          $.fn.on = function (types, sel, fn) {

            return this.delegate(sel, types, fn);

          };

          $.fn.off = function (types, sel, fn) {

            return this.undelegate(sel, types, fn);

          };

          return false;
        }

        return true;
      },

      outerHTML : function (el) {
        // support FireFox < 11
        return el.outerHTML || new XMLSerializer().serializeToString(el);
      },

      version : function () {
        return settings.version;
      },

      tabbable : function (el) {
        $(el).on('keydown', function( event ) {
          if (!event.isDefaultPrevented() && event.keyCode &&
              // Escape key.
              event.keyCode === 27 ) {
            event.preventDefault();
            methods.end(true /* isAborted */);
            return;
          }

          // Prevent tabbing out of tour items.
          if ( event.keyCode !== 9 ) {
            return;
          }
          var tabbables = $(el).find(":tabbable"),
            first = tabbables.filter(":first"),
            last  = tabbables.filter(":last");
          if ( event.target === last[0] && !event.shiftKey ) {
            first.focus( 1 );
            event.preventDefault();
          } else if ( event.target === first[0] && event.shiftKey ) {
            last.focus( 1 );
            event.preventDefault();
          }
        });
      }

    };

  $.fn.joyride = function (method) {
    if (methods[method]) {
      return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
    } else if (typeof method === 'object' || !method) {
      return methods.init.apply(this, arguments);
    } else {
      $.error('Method ' +  method + ' does not exist on jQuery.joyride');
    }
  };

}(jQuery, this));
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Backbone, Drupal, document) {
  var queryString = decodeURI(window.location.search);

  Drupal.behaviors.tour = {
    attach: function attach(context) {
      $('body').once('tour').each(function () {
        var model = new Drupal.tour.models.StateModel();
        new Drupal.tour.views.ToggleTourView({
          el: $(context).find('#toolbar-tab-tour'),
          model: model
        });

        model.on('change:isActive', function (model, isActive) {
          $(document).trigger(isActive ? 'drupalTourStarted' : 'drupalTourStopped');
        }).set('tour', $(context).find('ol#tour'));

        if (/tour=?/i.test(queryString)) {
          model.set('isActive', true);
        }
      });
    }
  };

  Drupal.tour = Drupal.tour || {
    models: {},

    views: {}
  };

  Drupal.tour.models.StateModel = Backbone.Model.extend({
    defaults: {
      tour: [],

      isActive: false,

      activeTour: []
    }
  });

  Drupal.tour.views.ToggleTourView = Backbone.View.extend({
    events: { click: 'onClick' },

    initialize: function initialize() {
      this.listenTo(this.model, 'change:tour change:isActive', this.render);
      this.listenTo(this.model, 'change:isActive', this.toggleTour);
    },
    render: function render() {
      this.$el.toggleClass('hidden', this._getTour().length === 0);

      var isActive = this.model.get('isActive');
      this.$el.find('button').toggleClass('is-active', isActive).prop('aria-pressed', isActive);
      return this;
    },
    toggleTour: function toggleTour() {
      if (this.model.get('isActive')) {
        var $tour = this._getTour();
        this._removeIrrelevantTourItems($tour, this._getDocument());
        var that = this;
        var close = Drupal.t('Close');
        if ($tour.find('li').length) {
          $tour.joyride({
            autoStart: true,
            postRideCallback: function postRideCallback() {
              that.model.set('isActive', false);
            },

            template: {
              link: '<a href="#close" class="joyride-close-tip" aria-label="' + close + '">&times;</a>',
              button: '<a href="#" class="button button--primary joyride-next-tip"></a>'
            }
          });
          this.model.set({ isActive: true, activeTour: $tour });
        }
      } else {
        this.model.get('activeTour').joyride('destroy');
        this.model.set({ isActive: false, activeTour: [] });
      }
    },
    onClick: function onClick(event) {
      this.model.set('isActive', !this.model.get('isActive'));
      event.preventDefault();
      event.stopPropagation();
    },
    _getTour: function _getTour() {
      return this.model.get('tour');
    },
    _getDocument: function _getDocument() {
      return $(document);
    },
    _removeIrrelevantTourItems: function _removeIrrelevantTourItems($tour, $document) {
      var removals = false;
      var tips = /tips=([^&]+)/.exec(queryString);
      $tour.find('li').each(function () {
        var $this = $(this);
        var itemId = $this.attr('data-id');
        var itemClass = $this.attr('data-class');

        if (tips && !$(this).hasClass(tips[1])) {
          removals = true;
          $this.remove();
          return;
        }

        if (!itemId && !itemClass || itemId && $document.find('#' + itemId).length || itemClass && $document.find('.' + itemClass).length) {
          return;
        }
        removals = true;
        $this.remove();
      });

      if (removals) {
        var total = $tour.find('li').length;
        if (!total) {
          this.model.set({ tour: [] });
        }

        $tour.find('li').each(function (index) {
          var progress = Drupal.t('!tour_item of !total', {
            '!tour_item': index + 1,
            '!total': total
          });
          $(this).find('.tour-progress').text(progress);
        }).eq(-1).attr('data-text', Drupal.t('End tour'));
      }
    }
  });
})(jQuery, Backbone, Drupal, document);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal) {
  function TabbingManager() {
    this.stack = [];
  }

  function TabbingContext(options) {
    $.extend(this, {
      level: null,

      $tabbableElements: $(),

      $disabledElements: $(),

      released: false,

      active: false
    }, options);
  }

  $.extend(TabbingManager.prototype, {
    constrain: function constrain(elements) {
      var il = this.stack.length;
      for (var i = 0; i < il; i++) {
        this.stack[i].deactivate();
      }

      var $elements = $(elements).find(':tabbable').addBack(':tabbable');

      var tabbingContext = new TabbingContext({
        level: this.stack.length,
        $tabbableElements: $elements
      });

      this.stack.push(tabbingContext);

      tabbingContext.activate();

      $(document).trigger('drupalTabbingConstrained', tabbingContext);

      return tabbingContext;
    },
    release: function release() {
      var toActivate = this.stack.length - 1;
      while (toActivate >= 0 && this.stack[toActivate].released) {
        toActivate--;
      }

      this.stack.splice(toActivate + 1);

      if (toActivate >= 0) {
        this.stack[toActivate].activate();
      }
    },
    activate: function activate(tabbingContext) {
      var $set = tabbingContext.$tabbableElements;
      var level = tabbingContext.level;

      var $disabledSet = $(':tabbable').not($set);

      tabbingContext.$disabledElements = $disabledSet;

      var il = $disabledSet.length;
      for (var i = 0; i < il; i++) {
        this.recordTabindex($disabledSet.eq(i), level);
      }

      $disabledSet.prop('tabindex', -1).prop('autofocus', false);

      var $hasFocus = $set.filter('[autofocus]').eq(-1);

      if ($hasFocus.length === 0) {
        $hasFocus = $set.eq(0);
      }
      $hasFocus.trigger('focus');
    },
    deactivate: function deactivate(tabbingContext) {
      var $set = tabbingContext.$disabledElements;
      var level = tabbingContext.level;
      var il = $set.length;
      for (var i = 0; i < il; i++) {
        this.restoreTabindex($set.eq(i), level);
      }
    },
    recordTabindex: function recordTabindex($el, level) {
      var tabInfo = $el.data('drupalOriginalTabIndices') || {};
      tabInfo[level] = {
        tabindex: $el[0].getAttribute('tabindex'),
        autofocus: $el[0].hasAttribute('autofocus')
      };
      $el.data('drupalOriginalTabIndices', tabInfo);
    },
    restoreTabindex: function restoreTabindex($el, level) {
      var tabInfo = $el.data('drupalOriginalTabIndices');
      if (tabInfo && tabInfo[level]) {
        var data = tabInfo[level];
        if (data.tabindex) {
          $el[0].setAttribute('tabindex', data.tabindex);
        } else {
            $el[0].removeAttribute('tabindex');
          }
        if (data.autofocus) {
          $el[0].setAttribute('autofocus', 'autofocus');
        }

        if (level === 0) {
          $el.removeData('drupalOriginalTabIndices');
        } else {
          var levelToDelete = level;
          while (tabInfo.hasOwnProperty(levelToDelete)) {
            delete tabInfo[levelToDelete];
            levelToDelete++;
          }
          $el.data('drupalOriginalTabIndices', tabInfo);
        }
      }
    }
  });

  $.extend(TabbingContext.prototype, {
    release: function release() {
      if (!this.released) {
        this.deactivate();
        this.released = true;
        Drupal.tabbingManager.release(this);

        $(document).trigger('drupalTabbingContextReleased', this);
      }
    },
    activate: function activate() {
      if (!this.active && !this.released) {
        this.active = true;
        Drupal.tabbingManager.activate(this);

        $(document).trigger('drupalTabbingContextActivated', this);
      }
    },
    deactivate: function deactivate() {
      if (this.active) {
        this.active = false;
        Drupal.tabbingManager.deactivate(this);

        $(document).trigger('drupalTabbingContextDeactivated', this);
      }
    }
  });

  if (Drupal.tabbingManager) {
    return;
  }

  Drupal.tabbingManager = new TabbingManager();
})(jQuery, Drupal);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, Backbone) {
  var strings = {
    tabbingReleased: Drupal.t('Tabbing is no longer constrained by the Contextual module.'),
    tabbingConstrained: Drupal.t('Tabbing is constrained to a set of @contextualsCount and the edit mode toggle.'),
    pressEsc: Drupal.t('Press the esc key to exit.')
  };

  function initContextualToolbar(context) {
    if (!Drupal.contextual || !Drupal.contextual.collection) {
      return;
    }

    var contextualToolbar = Drupal.contextualToolbar;
    contextualToolbar.model = new contextualToolbar.StateModel({
      isViewing: localStorage.getItem('Drupal.contextualToolbar.isViewing') !== 'false'
    }, {
      contextualCollection: Drupal.contextual.collection
    });

    var viewOptions = {
      el: $('.toolbar .toolbar-bar .contextual-toolbar-tab'),
      model: contextualToolbar.model,
      strings: strings
    };
    new contextualToolbar.VisualView(viewOptions);
    new contextualToolbar.AuralView(viewOptions);
  }

  Drupal.behaviors.contextualToolbar = {
    attach: function attach(context) {
      if ($('body').once('contextualToolbar-init').length) {
        initContextualToolbar(context);
      }
    }
  };

  Drupal.contextualToolbar = {
    model: null
  };
})(jQuery, Drupal, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, Backbone) {
  Drupal.contextualToolbar.StateModel = Backbone.Model.extend({
    defaults: {
      isViewing: true,

      isVisible: false,

      contextualCount: 0,

      tabbingContext: null
    },

    initialize: function initialize(attrs, options) {
      this.listenTo(options.contextualCollection, 'reset remove add', this.countContextualLinks);
      this.listenTo(options.contextualCollection, 'add', this.lockNewContextualLinks);

      this.listenTo(this, 'change:contextualCount', this.updateVisibility);

      this.listenTo(this, 'change:isViewing', function (model, isViewing) {
        options.contextualCollection.each(function (contextualModel) {
          contextualModel.set('isLocked', !isViewing);
        });
      });
    },
    countContextualLinks: function countContextualLinks(contextualModel, contextualCollection) {
      this.set('contextualCount', contextualCollection.length);
    },
    lockNewContextualLinks: function lockNewContextualLinks(contextualModel, contextualCollection) {
      if (!this.get('isViewing')) {
        contextualModel.set('isLocked', true);
      }
    },
    updateVisibility: function updateVisibility() {
      this.set('isVisible', this.get('contextualCount') > 0);
    }
  });
})(Drupal, Backbone);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, Backbone, _) {
  Drupal.contextualToolbar.AuralView = Backbone.View.extend({
    announcedOnce: false,

    initialize: function initialize(options) {
      this.options = options;

      this.listenTo(this.model, 'change', this.render);
      this.listenTo(this.model, 'change:isViewing', this.manageTabbing);

      $(document).on('keyup', _.bind(this.onKeypress, this));
      this.manageTabbing();
    },
    render: function render() {
      this.$el.find('button').attr('aria-pressed', !this.model.get('isViewing'));

      return this;
    },
    manageTabbing: function manageTabbing() {
      var tabbingContext = this.model.get('tabbingContext');

      if (tabbingContext) {
        if (tabbingContext.active) {
          Drupal.announce(this.options.strings.tabbingReleased);
        }
        tabbingContext.release();
      }

      if (!this.model.get('isViewing')) {
        tabbingContext = Drupal.tabbingManager.constrain($('.contextual-toolbar-tab, .contextual'));
        this.model.set('tabbingContext', tabbingContext);
        this.announceTabbingConstraint();
        this.announcedOnce = true;
      }
    },
    announceTabbingConstraint: function announceTabbingConstraint() {
      var strings = this.options.strings;
      Drupal.announce(Drupal.formatString(strings.tabbingConstrained, {
        '@contextualsCount': Drupal.formatPlural(Drupal.contextual.collection.length, '@count contextual link', '@count contextual links')
      }));
      Drupal.announce(strings.pressEsc);
    },
    onKeypress: function onKeypress(event) {
      if (!this.announcedOnce && event.keyCode === 9 && !this.model.get('isViewing')) {
        this.announceTabbingConstraint();

        this.announcedOnce = true;
      }

      if (event.keyCode === 27) {
        this.model.set('isViewing', true);
      }
    }
  });
})(jQuery, Drupal, Backbone, _);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function (Drupal, Backbone) {
  Drupal.contextualToolbar.VisualView = Backbone.View.extend({
    events: function events() {
      var touchEndToClick = function touchEndToClick(event) {
        event.preventDefault();
        event.target.click();
      };

      return {
        click: function click() {
          this.model.set('isViewing', !this.model.get('isViewing'));
        },

        touchend: touchEndToClick
      };
    },
    initialize: function initialize() {
      this.listenTo(this.model, 'change', this.render);
      this.listenTo(this.model, 'change:isViewing', this.persist);
    },
    render: function render() {
      this.$el.toggleClass('hidden', !this.model.get('isVisible'));

      this.$el.find('button').toggleClass('is-active', !this.model.get('isViewing'));

      return this;
    },
    persist: function persist(model, isViewing) {
      if (!isViewing) {
        localStorage.setItem('Drupal.contextualToolbar.isViewing', 'false');
      } else {
        localStorage.removeItem('Drupal.contextualToolbar.isViewing');
      }
    }
  });
})(Drupal, Backbone);;
/*!
 * hoverIntent v1.8.1 // 2014.08.11 // jQuery v1.9.1+
 * http://briancherne.github.io/jquery-hoverIntent/
 *
 * You may use hoverIntent under the terms of the MIT license. Basically that
 * means you are free to use hoverIntent as long as this header is left intact.
 * Copyright 2007, 2014 Brian Cherne
 */

/* hoverIntent is similar to jQuery's built-in "hover" method except that
 * instead of firing the handlerIn function immediately, hoverIntent checks
 * to see if the user's mouse has slowed down (beneath the sensitivity
 * threshold) before firing the event. The handlerOut function is only
 * called after a matching handlerIn.
 *
 * // basic usage ... just like .hover()
 * .hoverIntent( handlerIn, handlerOut )
 * .hoverIntent( handlerInOut )
 *
 * // basic usage ... with event delegation!
 * .hoverIntent( handlerIn, handlerOut, selector )
 * .hoverIntent( handlerInOut, selector )
 *
 * // using a basic configuration object
 * .hoverIntent( config )
 *
 * @param  handlerIn   function OR configuration object
 * @param  handlerOut  function OR selector for delegation OR undefined
 * @param  selector    selector OR undefined
 * @author Brian Cherne <brian(at)cherne(dot)net>
 */

;(function(factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define(['jquery'], factory);
  } else if (jQuery && !jQuery.fn.hoverIntent) {
    factory(jQuery);
  }
})(function($) {
  'use strict';

  // default configuration values
  var _cfg = {
    interval: 100,
    sensitivity: 6,
    timeout: 0
  };

  // counter used to generate an ID for each instance
  var INSTANCE_COUNT = 0;

  // current X and Y position of mouse, updated during mousemove tracking (shared across instances)
  var cX, cY;

  // saves the current pointer position coordinates based on the given mousemove event
  var track = function(ev) {
    cX = ev.pageX;
    cY = ev.pageY;
  };

  // compares current and previous mouse positions
  var compare = function(ev,$el,s,cfg) {
    // compare mouse positions to see if pointer has slowed enough to trigger `over` function
    if ( Math.sqrt( (s.pX-cX)*(s.pX-cX) + (s.pY-cY)*(s.pY-cY) ) < cfg.sensitivity ) {
      $el.off(s.event,track);
      delete s.timeoutId;
      // set hoverIntent state as active for this element (permits `out` handler to trigger)
      s.isActive = true;
      // overwrite old mouseenter event coordinates with most recent pointer position
      ev.pageX = cX; ev.pageY = cY;
      // clear coordinate data from state object
      delete s.pX; delete s.pY;
      return cfg.over.apply($el[0],[ev]);
    } else {
      // set previous coordinates for next comparison
      s.pX = cX; s.pY = cY;
      // use self-calling timeout, guarantees intervals are spaced out properly (avoids JavaScript timer bugs)
      s.timeoutId = setTimeout( function(){compare(ev, $el, s, cfg);} , cfg.interval );
    }
  };

  // triggers given `out` function at configured `timeout` after a mouseleave and clears state
  var delay = function(ev,$el,s,out) {
    delete $el.data('hoverIntent')[s.id];
    return out.apply($el[0],[ev]);
  };

  $.fn.hoverIntent = function(handlerIn,handlerOut,selector) {
    // instance ID, used as a key to store and retrieve state information on an element
    var instanceId = INSTANCE_COUNT++;

    // extend the default configuration and parse parameters
    var cfg = $.extend({}, _cfg);
    if ( $.isPlainObject(handlerIn) ) {
      cfg = $.extend(cfg, handlerIn);
      if ( !$.isFunction(cfg.out) ) {
        cfg.out = cfg.over;
      }
    } else if ( $.isFunction(handlerOut) ) {
      cfg = $.extend(cfg, { over: handlerIn, out: handlerOut, selector: selector } );
    } else {
      cfg = $.extend(cfg, { over: handlerIn, out: handlerIn, selector: handlerOut } );
    }

    // A private function for handling mouse 'hovering'
    var handleHover = function(e) {
      // cloned event to pass to handlers (copy required for event object to be passed in IE)
      var ev = $.extend({},e);

      // the current target of the mouse event, wrapped in a jQuery object
      var $el = $(this);

      // read hoverIntent data from element (or initialize if not present)
      var hoverIntentData = $el.data('hoverIntent');
      if (!hoverIntentData) { $el.data('hoverIntent', (hoverIntentData = {})); }

      // read per-instance state from element (or initialize if not present)
      var state = hoverIntentData[instanceId];
      if (!state) { hoverIntentData[instanceId] = state = { id: instanceId }; }

      // state properties:
      // id = instance ID, used to clean up data
      // timeoutId = timeout ID, reused for tracking mouse position and delaying "out" handler
      // isActive = plugin state, true after `over` is called just until `out` is called
      // pX, pY = previously-measured pointer coordinates, updated at each polling interval
      // event = string representing the namespaced event used for mouse tracking

      // clear any existing timeout
      if (state.timeoutId) { state.timeoutId = clearTimeout(state.timeoutId); }

      // namespaced event used to register and unregister mousemove tracking
      var mousemove = state.event = 'mousemove.hoverIntent.hoverIntent'+instanceId;

      // handle the event, based on its type
      if (e.type === 'mouseenter') {
        // do nothing if already active
        if (state.isActive) { return; }
        // set "previous" X and Y position based on initial entry point
        state.pX = ev.pageX; state.pY = ev.pageY;
        // update "current" X and Y position based on mousemove
        $el.off(mousemove,track).on(mousemove,track);
        // start polling interval (self-calling timeout) to compare mouse coordinates over time
        state.timeoutId = setTimeout( function(){compare(ev,$el,state,cfg);} , cfg.interval );
      } else { // "mouseleave"
        // do nothing if not already active
        if (!state.isActive) { return; }
        // unbind expensive mousemove event
        $el.off(mousemove,track);
        // if hoverIntent state is true, then call the mouseOut function after the specified delay
        state.timeoutId = setTimeout( function(){delay(ev,$el,state,cfg.out);} , cfg.timeout );
      }
    };

    // listen for mouseenter and mouseleave
    return this.on({'mouseenter.hoverIntent':handleHover,'mouseleave.hoverIntent':handleHover}, cfg.selector);
  };
});
;
(function ($, Drupal) {
  Drupal.behaviors.adminToolbar = {
    attach: function (context, settings) {

      $('a.toolbar-icon', context).removeAttr('title');

      $('.toolbar-tray li.menu-item--expanded, .toolbar-tray ul li.menu-item--expanded .menu-item', context).hoverIntent({
        over: function () {
          // At the current depth, we should delete all "hover-intent" classes.
          // Other wise we get unwanted behaviour where menu items are expanded while already in hovering other ones.
          $(this).parent().find('li').removeClass('hover-intent');
          $(this).addClass('hover-intent');
        },
        out: function () {
          $(this).removeClass('hover-intent');
        },
        timeout: 250
      });

      // Make the toolbar menu navigable with keyboard.
      $('ul.toolbar-menu li.menu-item--expanded a', context).on('focusin', function () {
        $('li.menu-item--expanded', context).removeClass('hover-intent');
        $(this).parents('li.menu-item--expanded').addClass('hover-intent');
      });

      $('ul.toolbar-menu li.menu-item a', context).keydown(function (e) {
        if ((e.shiftKey && (e.keyCode || e.which) == 9)) {
          if ($(this).parent('.menu-item').prev().hasClass('menu-item--expanded')) {
            $(this).parent('.menu-item').prev().addClass('hover-intent');
          }
        }
      });

      $('.toolbar-menu:first-child > .menu-item:not(.menu-item--expanded) a, .toolbar-tab > a', context).on('focusin', function () {
        $('.menu-item--expanded').removeClass('hover-intent');
      });

      $('.toolbar-menu:first-child > .menu-item', context).on('hover', function () {
        $(this, 'a').css("background: #fff;");
      });

      $('ul:not(.toolbar-menu)', context).on({
        mousemove: function () {
          $('li.menu-item--expanded').removeClass('hover-intent');
        },
        hover: function () {
          $('li.menu-item--expanded').removeClass('hover-intent');
        }
      });

    }
  };
})(jQuery, Drupal);
;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  var pathInfo = drupalSettings.path;
  var escapeAdminPath = sessionStorage.getItem('escapeAdminPath');
  var windowLocation = window.location;

  if (!pathInfo.currentPathIsAdmin && !/destination=/.test(windowLocation.search)) {
    sessionStorage.setItem('escapeAdminPath', windowLocation);
  }

  Drupal.behaviors.escapeAdmin = {
    attach: function attach() {
      var $toolbarEscape = $('[data-toolbar-escape-admin]').once('escapeAdmin');
      if ($toolbarEscape.length && pathInfo.currentPathIsAdmin) {
        if (escapeAdminPath !== null) {
          $toolbarEscape.attr('href', escapeAdminPath);
        } else {
          $toolbarEscape.text(Drupal.t('Home'));
        }
      }
    }
  };
})(jQuery, Drupal, drupalSettings);;
/**
* DO NOT EDIT THIS FILE.
* See the following change record for more information,
* https://www.drupal.org/node/2815083
* @preserve
**/

(function ($, Drupal, drupalSettings) {
  function mapTextContentToAjaxResponse(content) {
    if (content === '') {
      return false;
    }

    try {
      return JSON.parse(content);
    } catch (e) {
      return false;
    }
  }

  function bigPipeProcessPlaceholderReplacement(index, placeholderReplacement) {
    var placeholderId = placeholderReplacement.getAttribute('data-big-pipe-replacement-for-placeholder-with-id');
    var content = this.textContent.trim();

    if (typeof drupalSettings.bigPipePlaceholderIds[placeholderId] !== 'undefined') {
      var response = mapTextContentToAjaxResponse(content);

      if (response === false) {
        $(this).removeOnce('big-pipe');
      } else {
        var ajaxObject = Drupal.ajax({
          url: '',
          base: false,
          element: false,
          progress: false
        });

        ajaxObject.success(response, 'success');
      }
    }
  }

  var interval = drupalSettings.bigPipeInterval || 50;

  var timeoutID = void 0;

  function bigPipeProcessDocument(context) {
    if (!context.querySelector('script[data-big-pipe-event="start"]')) {
      return false;
    }

    $(context).find('script[data-big-pipe-replacement-for-placeholder-with-id]').once('big-pipe').each(bigPipeProcessPlaceholderReplacement);

    if (context.querySelector('script[data-big-pipe-event="stop"]')) {
      if (timeoutID) {
        clearTimeout(timeoutID);
      }
      return true;
    }

    return false;
  }

  function bigPipeProcess() {
    timeoutID = setTimeout(function () {
      if (!bigPipeProcessDocument(document)) {
        bigPipeProcess();
      }
    }, interval);
  }

  bigPipeProcess();

  $(window).on('load', function () {
    if (timeoutID) {
      clearTimeout(timeoutID);
    }
    bigPipeProcessDocument(document);
  });
})(jQuery, Drupal, drupalSettings);;
